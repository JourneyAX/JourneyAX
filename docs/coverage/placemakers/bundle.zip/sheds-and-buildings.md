---
description: 'Sheds & Buildings: 571 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Sheds & Buildings
type: department
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/sheds-and-buildings
  contentHash: 12e9a7e2a1f28e8c54e9e49c8e6456adf59778ce200ea68aeabbe5ce9d8ed0ce
  customerPhrases: []
  description: 'Sheds & Buildings: 571 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-754e457a9eba
    - src-doc-1bce1b2e6a9d
    - src-doc-ca01664495fc
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Sheds & Buildings
          path:
            - Sheds & Buildings
          products: 571
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Sheds & Buildings
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Sheds & Buildings
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - building
    - buildings
    - shed
    - sheds
  tenantId: placemakers
  type: department
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - building
  - buildings
  - shed
  - sheds
---
# Sheds & Buildings

Sheds & Buildings: 571 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
