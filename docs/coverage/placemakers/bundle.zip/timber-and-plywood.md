---
description: 'Timber & Plywood: 1,550 products across 11 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Timber & Plywood
type: department
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/timber-and-plywood/plywood
      - concept://placemakers/timber-and-plywood/engineered-timber
      - concept://placemakers/timber-and-plywood/timber-fencing
      - concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_timber_and_plywood
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood
  contentHash: 82010121c2b40c742fe9b2a90b845a6d76374924bccd9ab06ea5d74ee4a54349
  customerPhrases:
    - radiata pine post
    - h5 treated post
    - trellis alternative
    - dressed four sides
    - h3 2 treated timber
    - h4 treated posts
    - fence rail timber
    - treated fence rail
  description: 'Timber & Plywood: 1,550 products across 11 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_timber_and_plywood
      questionRef: q.nav_timber_and_plywood
      valueMap:
        decking: concept://placemakers/timber-and-plywood/decking
        engineered-timber: concept://placemakers/timber-and-plywood/engineered-timber
        non-structural-timber-all-grades: concept://placemakers/timber-and-plywood/non-structural-timber-all-grades
        panels: concept://placemakers/timber-and-plywood/panels
        plywood: concept://placemakers/timber-and-plywood/plywood
        poles-posts-and-piles: concept://placemakers/timber-and-plywood/poles-posts-and-piles
        square-dressed-boards-and-mouldings: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings
        structural-grade-timber-kiln-dried: concept://placemakers/timber-and-plywood/structural-grade-timber-kiln-dried
        structural-grade-timber-wet: concept://placemakers/timber-and-plywood/structural-grade-timber-wet
        timber-fencing: concept://placemakers/timber-and-plywood/timber-fencing
        timber-retaining: concept://placemakers/timber-and-plywood/timber-retaining
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-4046586ec77d
    - src-doc-a2b936992c9a
    - src-doc-0c626cfa5b69
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Timber & Plywood
          path:
            - Timber & Plywood
          products: 1550
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Timber & Plywood
  requiredFacts:
    - factKey: nav_timber_and_plywood
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - plywoods
    - timber
    - timbers
    - treated
    - treateds
  tenantId: placemakers
  type: department
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - plywoods
  - timber
  - timbers
  - treated
  - treateds
---
# Timber & Plywood

Timber & Plywood: 1,550 products across 11 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
