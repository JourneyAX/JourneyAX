# references

* [manifest.json](manifest.json) - Knowledge artifact
