---
description: 'Kitchen Appliances: 199 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Kitchen Appliances
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/kitchens-and-laundry/kitchens/kitchen-appliances
  contentHash: a8eab4838103eedeb1a47be5dc401a474ae0eb0afeb0eab1897ff30815384ba3
  customerPhrases:
    - rangehood
    - wall oven
    - ceramic glass hob
    - garbage disposal
    - dishwasher 60cm
    - cooktop oven combo
    - warming drawer insert
    - convection oven microwave
    - rangehoods
    - range hood
    - oven
    - ovens
    - cooktop
    - cooktops
    - hob
    - dishwasher
    - dishwashers
  description: 'Kitchen Appliances: 199 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-b5806b88a9ae
    - src-doc-6d4b4768be86
    - src-doc-c826facb532c
  extensions:
    x-journeyax-provenance:
      alias_rangehood:
        detail:
          alias: rangehood
          reason: Rangehood, oven and cooktop are kitchen appliances.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:48.301Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Kitchen Appliances
          path:
            - Kitchens & Laundry
            - Kitchens
            - Kitchen Appliances
          products: 199
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Kitchen Appliances
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Kitchens & Laundry
        - Kitchens
        - Kitchen Appliances
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - kitchen appliance
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 80733c65e9f9bcb22b336dd311cc6312c09aab0f326b1303eaae3da9decaaf56
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/kitchens-and-laundry/kitchens/kitchen-appliances
    relationshipId: rel-kitchens-and-laundry--kitchens--kitchen-appliances-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/kitchens-and-laundry/kitchens
    type: child_of
x-journeyax-synonyms:
  - kitchen appliance
---
# Kitchen Appliances

Kitchen Appliances: 199 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Kitchens](../kitchens.md)
