---
description: 'Kitchen Benchtops: 35 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Kitchen Benchtops
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/kitchens-and-laundry/kitchens/kitchen-benchtops
  contentHash: e9b09a49ea988ca3960668e7319cad8950f371c99aa90c2d67b53afaf779f9cc
  customerPhrases:
    - laminate benchtop blank
    - hpl benchtop blank
    - formica panel
    - prelaminated board
    - benchtop blank 3600x900
    - 30mm benchtop blank
    - 36mm prefinished benchtop
    - worktop blank
    - bench top
    - bench tops
    - benchtops
    - countertop
    - countertops
    - kitchen bench
  description: 'Kitchen Benchtops: 35 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_benchtops:
        detail:
          alias: benchtops
          reason: Bench top and countertop are the same thing.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:04.114Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Kitchen Benchtops
          path:
            - Kitchens & Laundry
            - Kitchens
            - Kitchen Benchtops
          products: 35
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Kitchen Benchtops
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Kitchens & Laundry
        - Kitchens
        - Kitchen Benchtops
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - benchtop
    - benchtops
    - kitchen benchtop
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 768c10aa22bea911b1a10c5e126ea4d11cdf77535dc01a8ab697fd9f5f6771de
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/kitchens-and-laundry/kitchens/kitchen-benchtops
    relationshipId: rel-kitchens-and-laundry--kitchens--kitchen-benchtops-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/kitchens-and-laundry/kitchens
    type: child_of
x-journeyax-synonyms:
  - benchtop
  - benchtops
  - kitchen benchtop
---
# Kitchen Benchtops

Kitchen Benchtops: 35 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Kitchens](../kitchens.md)
