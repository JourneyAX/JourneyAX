---
description: 'Kitchen Tapware: 421 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Kitchen Tapware
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/kitchens-and-laundry/kitchens/kitchen-tapware
  contentHash: faaae896d5ee01d772d32ee3e9ed7cc3aadd215e1c1ce006ac9694a4fd3191b2
  customerPhrases:
    - pull out faucet
    - high neck tap
    - gooseneck tap
    - sink set wall mounted
    - kitchen mixer tap
    - pull down mixer
    - high spout tap
    - sink mixer tap
  description: 'Kitchen Tapware: 421 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-d6a7fca9a4a7
    - src-doc-9fc484a5e984
    - src-doc-c89a24837ca3
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:23.646Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Kitchen Tapware
          path:
            - Kitchens & Laundry
            - Kitchens
            - Kitchen Tapware
          products: 421
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Kitchen Tapware
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Kitchens & Laundry
        - Kitchens
        - Kitchen Tapware
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - kitchen tapwares
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 01fa952b5c91183fdd19b0bd92ebc4dc8c7db50c6e2776cc489059c2d8e4bb93
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/kitchens-and-laundry/kitchens/kitchen-tapware
    relationshipId: rel-kitchens-and-laundry--kitchens--kitchen-tapware-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/kitchens-and-laundry/kitchens
    type: child_of
x-journeyax-synonyms:
  - kitchen tapwares
---
# Kitchen Tapware

Kitchen Tapware: 421 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Kitchens](../kitchens.md)
