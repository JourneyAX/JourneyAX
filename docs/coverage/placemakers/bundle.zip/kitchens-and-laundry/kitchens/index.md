# kitchens-and-laundry/kitchens

* [Kitchen Appliances](kitchen-appliances.md) - Kitchen Appliances: 199 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Kitchen Benchtops](kitchen-benchtops.md) - Kitchen Benchtops: 35 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Kitchen Hardware & Accessories](kitchen-hardware-and-accessories.md) - Kitchen Hardware & Accessories: 488 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Kitchen Sinks](kitchen-sinks.md) - Kitchen Sinks: 170 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Kitchen Splashbacks](kitchen-splashbacks.md) - Kitchen Splashbacks: 58 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Kitchen Tapware](kitchen-tapware.md) - Kitchen Tapware: 421 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
