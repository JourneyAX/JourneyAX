---
description: 'Kitchen Sinks: 170 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Kitchen Sinks
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/kitchens-and-laundry/kitchens/kitchen-sinks
  contentHash: d2b08970d1f679a30f48e482cd3bd06ce8abf307e82378a2247ba4ec767c64c3
  customerPhrases:
    - undermount sink
    - granite composite sink
    - drainer tray
    - double bowl sink
    - topmount sink
    - granitex sink
    - sink drainer
    - single bowl sink
  description: 'Kitchen Sinks: 170 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-71146b248a9c
    - src-doc-e702cbe4ead6
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:04.255Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Kitchen Sinks
          path:
            - Kitchens & Laundry
            - Kitchens
            - Kitchen Sinks
          products: 170
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Kitchen Sinks
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Kitchens & Laundry
        - Kitchens
        - Kitchen Sinks
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - kitchen sink
    - sink
    - sinks
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 7d723aafb6fd3d72af108d9ecb0fa658ebe192a742118e85031171f1d06930f0
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/kitchens-and-laundry/kitchens/kitchen-sinks
    relationshipId: rel-kitchens-and-laundry--kitchens--kitchen-sinks-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/kitchens-and-laundry/kitchens
    type: child_of
  - claimClasses: []
    confidence: low
    contentHash: 6f323daf48a04098a38b52c037b1e3cc5624e2888e3a29ce9d61bb60ceb2915d
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/kitchens-and-laundry/kitchens/kitchen-sinks
    relationshipId: rel-xs-kitchen_sink_extras-1
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/kitchens-and-laundry/kitchens/kitchen-tapware
    type: cross_sell
x-journeyax-synonyms:
  - kitchen sink
  - sink
  - sinks
---
# Kitchen Sinks

Kitchen Sinks: 170 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Kitchens](../kitchens.md)
* cross sell: [Kitchen Tapware](kitchen-tapware.md)
