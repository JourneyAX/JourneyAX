---
description: 'Kitchen Splashbacks: 58 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Kitchen Splashbacks
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/kitchens-and-laundry/kitchens/kitchen-splashbacks
  contentHash: e520c3740c80b4afa7aa77e9119fae2301b8e4f84debe72dfe9919d25634a1d8
  customerPhrases:
    - aluminium composite panel
    - glass splashback panel
    - acp splashback
    - kitchen splash panel
    - fire retardant splashback
    - backsplash glass
    - high gloss panel
    - tempered glass splashback
  description: 'Kitchen Splashbacks: 58 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-bf09d96d9e2f
    - src-doc-c9763ad83fbb
    - src-doc-9784be10b629
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:24.087Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Kitchen Splashbacks
          path:
            - Kitchens & Laundry
            - Kitchens
            - Kitchen Splashbacks
          products: 58
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Kitchen Splashbacks
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Kitchens & Laundry
        - Kitchens
        - Kitchen Splashbacks
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - kitchen splashback
    - splashback
    - splashbacks
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: f7970b2bf6847ee87fa4538bc66a5853c18e4aee71c06b366778c7bc45a1cd6a
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/kitchens-and-laundry/kitchens/kitchen-splashbacks
    relationshipId: rel-kitchens-and-laundry--kitchens--kitchen-splashbacks-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/kitchens-and-laundry/kitchens
    type: child_of
x-journeyax-synonyms:
  - kitchen splashback
  - splashback
  - splashbacks
---
# Kitchen Splashbacks

Kitchen Splashbacks: 58 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Kitchens](../kitchens.md)
