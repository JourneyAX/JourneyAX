---
description: 'Kitchens: 1,371 products across 6 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Kitchens
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/kitchens-and-laundry/kitchens/kitchen-hardware-and-accessories
      - concept://placemakers/kitchens-and-laundry/kitchens/kitchen-tapware
      - concept://placemakers/kitchens-and-laundry/kitchens/kitchen-appliances
      - concept://placemakers/kitchens-and-laundry/kitchens/kitchen-sinks
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_kitchens_and_laundry_kitchens
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/kitchens-and-laundry/kitchens
  contentHash: d2eda0f5daf5adf6db6045c297050910205b17c21040454086d20a97d3e493df
  customerPhrases: []
  description: 'Kitchens: 1,371 products across 6 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_kitchens_and_laundry_kitchens
      questionRef: q.nav_kitchens_and_laundry_kitchens
      valueMap:
        kitchen-appliances: concept://placemakers/kitchens-and-laundry/kitchens/kitchen-appliances
        kitchen-benchtops: concept://placemakers/kitchens-and-laundry/kitchens/kitchen-benchtops
        kitchen-hardware-and-accessories: concept://placemakers/kitchens-and-laundry/kitchens/kitchen-hardware-and-accessories
        kitchen-sinks: concept://placemakers/kitchens-and-laundry/kitchens/kitchen-sinks
        kitchen-splashbacks: concept://placemakers/kitchens-and-laundry/kitchens/kitchen-splashbacks
        kitchen-tapware: concept://placemakers/kitchens-and-laundry/kitchens/kitchen-tapware
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-d6a7fca9a4a7
    - src-doc-9fc484a5e984
    - src-doc-c89a24837ca3
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Kitchens
          path:
            - Kitchens & Laundry
            - Kitchens
          products: 1371
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Kitchens
  requiredFacts:
    - factKey: nav_kitchens_and_laundry_kitchens
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Kitchens & Laundry
        - Kitchens
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 1574662d636d9aceb7bf6b732b10b5b79243817a0150cfe0fe96252febf383cd
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/kitchens-and-laundry/kitchens
    relationshipId: rel-kitchens-and-laundry--kitchens-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/kitchens-and-laundry
    type: child_of
---
# Kitchens

Kitchens: 1,371 products across 6 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Kitchens & Laundry](../kitchens-and-laundry.md)
