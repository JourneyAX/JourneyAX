# kitchens-and-laundry

* [Kitchens](kitchens.md) - Kitchens: 1,371 products across 6 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Laundry](laundry.md) - Laundry: 196 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [kitchens](kitchens/) - Knowledge and references
* [laundry](laundry/) - Knowledge and references
