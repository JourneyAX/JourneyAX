# kitchens-and-laundry/laundry

* [Laundry Appliances & Accessories](laundry-appliances-and-accessories.md) - Laundry Appliances & Accessories: 37 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Laundry Cabinetry](laundry-cabinetry.md) - Laundry Cabinetry: 126 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Laundry Sinkware](laundry-sinkware.md) - Laundry Sinkware: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Laundry Tubs](laundry-tubs.md) - Laundry Tubs: 29 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
