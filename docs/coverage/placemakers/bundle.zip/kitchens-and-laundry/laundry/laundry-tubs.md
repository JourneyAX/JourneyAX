---
description: 'Laundry Tubs: 29 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Laundry Tubs
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/kitchens-and-laundry/laundry/laundry-tubs
  contentHash: 13eef3d0595b5c01802dca5f1eb6de28571d7f0e7e7e3d7526a26c5514d7aec3
  customerPhrases:
    - laundry cabinet tub
    - stainless laundry sink
    - gooseneck laundry tap
    - slim laundry unit
    - built in sink cupboard
    - metal laundry vanity
    - laundry trough cabinet
    - compact wash tub
  description: 'Laundry Tubs: 29 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-de07a3ccaa86
    - src-doc-76691a251799
    - src-doc-65bc7068bd54
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:28.613Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Laundry Tubs
            - Kitchens & Laundry > Laundry > Laundry Tubs
          path:
            - Kitchens & Laundry
            - Laundry
            - Laundry Tubs
          products: 29
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Laundry Tubs
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Kitchens & Laundry
        - Laundry
        - Laundry Tubs
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - laundry tub
    - tub
    - tubs
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 52a50b7f562ed76d473aa07899aded4a16d7cfc5eaa98dc2e3e8a204230a945c
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/kitchens-and-laundry/laundry/laundry-tubs
    relationshipId: rel-kitchens-and-laundry--laundry--laundry-tubs-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/kitchens-and-laundry/laundry
    type: child_of
x-journeyax-synonyms:
  - laundry tub
  - tub
  - tubs
---
# Laundry Tubs

Laundry Tubs: 29 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Laundry](../laundry.md)
