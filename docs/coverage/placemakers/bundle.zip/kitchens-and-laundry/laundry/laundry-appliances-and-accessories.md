---
description: 'Laundry Appliances & Accessories: 37 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Laundry Appliances & Accessories
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/kitchens-and-laundry/laundry/laundry-appliances-and-accessories
  contentHash: f73dceba05c198b4db04441c9f2c65d7077516a9ee9e460b414cdec60fd2ddda
  customerPhrases:
    - floating shelf for laundry
    - washer dryer combo
    - front loader washing machine
    - clothes dryer
    - wall mounted laundry shelf
    - laundry combo
    - 10kg washer
    - condenser tumble dryer
    - washing machine
    - washing machines
    - tumble dryer
    - dryer
    - dryers
    - washer
  description: 'Laundry Appliances & Accessories: 37 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_washing_machine:
        detail:
          alias: washing_machine
          reason: Washing machine and dryer are laundry appliances.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:06:23.685Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Laundry Appliances & Accessories
          path:
            - Kitchens & Laundry
            - Laundry
            - Laundry Appliances & Accessories
          products: 37
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Laundry Appliances & Accessories
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Kitchens & Laundry
        - Laundry
        - Laundry Appliances & Accessories
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - laundry appliance
    - laundry appliances
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: ab5a0edae87e5468fe8b871d9688232e8cbe8e1a089e6f98a6ccc0ed0b937320
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/kitchens-and-laundry/laundry/laundry-appliances-and-accessories
    relationshipId: rel-kitchens-and-laundry--laundry--laundry-appliances-and-accessories-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/kitchens-and-laundry/laundry
    type: child_of
x-journeyax-synonyms:
  - laundry appliance
  - laundry appliances
---
# Laundry Appliances & Accessories

Laundry Appliances & Accessories: 37 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Laundry](../laundry.md)
