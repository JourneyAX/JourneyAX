---
description: 'Laundry Sinkware: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Laundry Sinkware
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/kitchens-and-laundry/laundry/laundry-sinkware
  contentHash: 9f8013de427cc49a4bb00703d1525cb8cdffcb59eb427a786f87af902835c0f7
  customerPhrases:
    - stainless sink undermount
    - topmount kitchen sink
    - 15mm radius sink
    - 90mm waste hole
    - round basket strainer
    - stainless utility tub
    - compact laundry bowl
    - 450 x 400 sink
  description: 'Laundry Sinkware: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:05:12.428Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Laundry Sinkware
          path:
            - Kitchens & Laundry
            - Laundry
            - Laundry Sinkware
          products: 4
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Laundry Sinkware
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Kitchens & Laundry
        - Laundry
        - Laundry Sinkware
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - laundry sinkwares
    - sinkware
    - sinkwares
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: dea41b60c67d2b015e3e5961200cc6ce508bbe7ff18fd45df365197c02a012a4
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/kitchens-and-laundry/laundry/laundry-sinkware
    relationshipId: rel-kitchens-and-laundry--laundry--laundry-sinkware-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/kitchens-and-laundry/laundry
    type: child_of
x-journeyax-synonyms:
  - laundry sinkwares
  - sinkware
  - sinkwares
---
# Laundry Sinkware

Laundry Sinkware: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Laundry](../laundry.md)
