---
description: 'Laundry Cabinetry: 126 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Laundry Cabinetry
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/kitchens-and-laundry/laundry/laundry-cabinetry
  contentHash: 51c598af17f2e8b99172554064be5baa63005344d925b646282296a920d1e4bf
  customerPhrases:
    - laundry base unit
    - laundry sink top mount
    - laundry sink cabinet
    - stainless steel laundry tub
    - pull out hamper
    - double laundry basket
    - laundry trough 500x400
    - washer dryer cabinet
  description: 'Laundry Cabinetry: 126 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:29.776Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Laundry Cabinetry
            - Kitchens & Laundry > Laundry > Cabinetry
          path:
            - Kitchens & Laundry
            - Laundry
            - Laundry Cabinetry
          products: 126
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Laundry Cabinetry
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Kitchens & Laundry
        - Laundry
        - Laundry Cabinetry
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - cabinetries
    - cabinetry
    - laundry cabinetries
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 071e72a6175cc94a8e46dacf2451000071e6164b00a1245a7de24efa4b5ab8c4
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/kitchens-and-laundry/laundry/laundry-cabinetry
    relationshipId: rel-kitchens-and-laundry--laundry--laundry-cabinetry-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/kitchens-and-laundry/laundry
    type: child_of
x-journeyax-synonyms:
  - cabinetries
  - cabinetry
  - laundry cabinetries
---
# Laundry Cabinetry

Laundry Cabinetry: 126 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Laundry](../laundry.md)
