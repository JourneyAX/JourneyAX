---
description: 'Laundry: 196 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Laundry
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/kitchens-and-laundry/laundry/laundry-cabinetry
      - concept://placemakers/kitchens-and-laundry/laundry/laundry-appliances-and-accessories
      - concept://placemakers/kitchens-and-laundry/laundry/laundry-tubs
      - concept://placemakers/kitchens-and-laundry/laundry/laundry-sinkware
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_kitchens_and_laundry_laundry
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/kitchens-and-laundry/laundry
  contentHash: 78f7ee1aed360ff88524cfb79f3edc201f9c377ecc28e1ad22410dd6fa107905
  customerPhrases:
    - single bowl laundry sink
  description: 'Laundry: 196 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_kitchens_and_laundry_laundry
      questionRef: q.nav_kitchens_and_laundry_laundry
      valueMap:
        laundry-appliances-and-accessories: concept://placemakers/kitchens-and-laundry/laundry/laundry-appliances-and-accessories
        laundry-cabinetry: concept://placemakers/kitchens-and-laundry/laundry/laundry-cabinetry
        laundry-sinkware: concept://placemakers/kitchens-and-laundry/laundry/laundry-sinkware
        laundry-tubs: concept://placemakers/kitchens-and-laundry/laundry/laundry-tubs
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-de07a3ccaa86
    - src-doc-76691a251799
    - src-doc-65bc7068bd54
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Laundry
          path:
            - Kitchens & Laundry
            - Laundry
          products: 196
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Laundry
  requiredFacts:
    - factKey: nav_kitchens_and_laundry_laundry
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Kitchens & Laundry
        - Laundry
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: def85846ab7f54d80c8e471cd9c288f67eeaf9b573c173af603022203a789046
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/kitchens-and-laundry/laundry
    relationshipId: rel-kitchens-and-laundry--laundry-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/kitchens-and-laundry
    type: child_of
---
# Laundry

Laundry: 196 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Kitchens & Laundry](../kitchens-and-laundry.md)
