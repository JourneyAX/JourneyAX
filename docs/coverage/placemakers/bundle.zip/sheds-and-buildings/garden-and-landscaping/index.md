# sheds-and-buildings/garden-and-landscaping

* [Garden Sheds](garden-sheds.md) - Garden Sheds: 571 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
