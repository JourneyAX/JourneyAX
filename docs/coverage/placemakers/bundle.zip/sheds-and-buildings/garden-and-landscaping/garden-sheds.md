---
description: 'Garden Sheds: 571 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Garden Sheds
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/sheds-and-buildings/garden-and-landscaping/garden-sheds
  contentHash: 0286078673b073436a2af02af63cbe7f950e4e4c495ce44cd899a9a4dbf93686
  customerPhrases:
    - louvre vent
    - kitset shed
    - shed base floor
    - metal kitset shed
    - deck box
    - pine shed kitset
    - metal garden shed
    - timber floor kit
  description: 'Garden Sheds: 571 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-754e457a9eba
    - src-doc-1bce1b2e6a9d
    - src-doc-ca01664495fc
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:16.432Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Garden Sheds
          path:
            - Sheds & Buildings
            - Garden & Landscaping
            - Garden Sheds
          products: 571
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Garden Sheds
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Sheds & Buildings
        - Garden & Landscaping
        - Garden Sheds
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - garden shed
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: cc3ea1f7663c859d3676dd5b5760d1019d0a441fc8c4a5159afb09beaed12806
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/sheds-and-buildings/garden-and-landscaping/garden-sheds
    relationshipId: rel-sheds-and-buildings--garden-and-landscaping--garden-sheds-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/sheds-and-buildings/garden-and-landscaping
    type: child_of
x-journeyax-synonyms:
  - garden shed
---
# Garden Sheds

Garden Sheds: 571 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Garden & Landscaping (Sheds & Buildings)](../garden-and-landscaping.md)
