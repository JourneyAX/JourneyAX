# sheds-and-buildings

* [Garden & Landscaping (Sheds & Buildings)](garden-and-landscaping.md) - Garden & Landscaping: 571 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [garden-and-landscaping](garden-and-landscaping/) - Knowledge and references
