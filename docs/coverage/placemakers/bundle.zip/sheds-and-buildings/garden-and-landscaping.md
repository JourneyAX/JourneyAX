---
description: 'Garden & Landscaping: 571 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Garden & Landscaping (Sheds & Buildings)
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/sheds-and-buildings/garden-and-landscaping
  contentHash: c691ccc0bfaa2b404b51bcd1c48aeccdd0ce292a361ea7134fd7f436204f73a9
  customerPhrases: []
  description: 'Garden & Landscaping: 571 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-754e457a9eba
    - src-doc-1bce1b2e6a9d
    - src-doc-ca01664495fc
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Garden & Landscaping
          path:
            - Sheds & Buildings
            - Garden & Landscaping
          products: 571
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Garden & Landscaping (Sheds & Buildings)
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Sheds & Buildings
        - Garden & Landscaping
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 9611c30b0ebe2f60c4928887259525215def1915b0683a68a66acfa5c32b1db3
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/sheds-and-buildings/garden-and-landscaping
    relationshipId: rel-sheds-and-buildings--garden-and-landscaping-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/sheds-and-buildings
    type: child_of
---
# Garden & Landscaping (Sheds & Buildings)

Garden & Landscaping: 571 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Sheds & Buildings](../sheds-and-buildings.md)
