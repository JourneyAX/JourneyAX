---
description: 'Furniture: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Furniture
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/bbqs-furniture-and-sun-shade/furniture
  contentHash: 98fc3d8460b7be8d06cc3af2792ed3f6ca8275afe1865e842420c27b4b7951f1
  customerPhrases:
    - wicker protector
    - texteline protector
    - outdoor furniture spray
    - patio furniture care
    - rattan furniture treatment
    - garden furniture protector
    - furniture stain protector
    - synthetic wicker sealer
  description: 'Furniture: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:07:29.468Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Furniture
          path:
            - Outdoor & Landscaping
            - BBQs, Furniture & Sun Shade
            - Furniture
          products: 1
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Furniture
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - BBQs, Furniture & Sun Shade
        - Furniture
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 0490491c5e015f0661bd420b7b8a3aff0263fb2a2b321b7e083725ba961ee1e3
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/bbqs-furniture-and-sun-shade/furniture
    relationshipId: rel-outdoor-and-landscaping--bbqs-furniture-and-sun-shade--furniture-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping/bbqs-furniture-and-sun-shade
    type: child_of
---
# Furniture

Furniture: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [BBQs, Furniture & Sun Shade](../bbqs-furniture-and-sun-shade.md)
