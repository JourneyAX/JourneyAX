---
description: 'Barbecues: 48 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Barbecues
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/bbqs-furniture-and-sun-shade/barbecues
  contentHash: 9ef210e0c02a5b9f7d62f446af4d4f37bb313c332e09bb750814b0f568ecace2
  customerPhrases:
    - butane cartridge
    - bbq cleaner
    - camping gas canister
    - outdoor fireplace
    - grill cleaner
    - concrete bbq
    - barbecue wipes
    - lpg bottle
  description: 'Barbecues: 48 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:00.030Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Barbecues
          path:
            - Outdoor & Landscaping
            - BBQs, Furniture & Sun Shade
            - Barbecues
          products: 48
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Barbecues
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - BBQs, Furniture & Sun Shade
        - Barbecues
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - barbecue
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 2a6c3c0d2070051314c30a68e9c63db317cbedf01780bb0d6eecffae1306c75c
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/bbqs-furniture-and-sun-shade/barbecues
    relationshipId: rel-outdoor-and-landscaping--bbqs-furniture-and-sun-shade--barbecues-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping/bbqs-furniture-and-sun-shade
    type: child_of
x-journeyax-synonyms:
  - barbecue
---
# Barbecues

Barbecues: 48 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [BBQs, Furniture & Sun Shade](../bbqs-furniture-and-sun-shade.md)
