# outdoor-and-landscaping/bbqs-furniture-and-sun-shade

* [Barbecues](barbecues.md) - Barbecues: 48 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Furniture](furniture.md) - Furniture: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
