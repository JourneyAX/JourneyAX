---
description: 'Translucent Roofing: 145 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Translucent Roofing
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/outdoor-and-landscaping/translucent-roofing/polycarb-roofing
      - concept://placemakers/outdoor-and-landscaping/translucent-roofing/translucent-roofing-accessories
      - concept://placemakers/outdoor-and-landscaping/translucent-roofing/pvc-roofing
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_outdoor_and_landscaping_translucent_roofing
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/translucent-roofing
  contentHash: f30c4bc79b8ccc332a99fd25051861b6eb1fae1a27472e64f5622cba236f29de
  customerPhrases:
    - corrugated plastic roofing
    - corrugated roof sheeting
  description: 'Translucent Roofing: 145 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_outdoor_and_landscaping_translucent_roofing
      questionRef: q.nav_outdoor_and_landscaping_translucent_roofing
      valueMap:
        polycarb-roofing: concept://placemakers/outdoor-and-landscaping/translucent-roofing/polycarb-roofing
        pvc-roofing: concept://placemakers/outdoor-and-landscaping/translucent-roofing/pvc-roofing
        translucent-roofing-accessories: concept://placemakers/outdoor-and-landscaping/translucent-roofing/translucent-roofing-accessories
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-b83b1c4883cb
    - src-doc-46503bda042f
    - src-doc-0fc2f6761b95
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Translucent Roofing
          path:
            - Outdoor & Landscaping
            - Translucent Roofing
          products: 145
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Translucent Roofing
  requiredFacts:
    - factKey: nav_outdoor_and_landscaping_translucent_roofing
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - Translucent Roofing
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - roofings
    - translucent roofings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 1f9075bfba038a1d1e2ae6cf00daa4d4e286cb55cfdf8d6e598a98f76e71dc3d
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/translucent-roofing
    relationshipId: rel-outdoor-and-landscaping--translucent-roofing-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping
    type: child_of
x-journeyax-synonyms:
  - roofings
  - translucent roofings
---
# Translucent Roofing

Translucent Roofing: 145 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Outdoor & Landscaping](../outdoor-and-landscaping.md)
