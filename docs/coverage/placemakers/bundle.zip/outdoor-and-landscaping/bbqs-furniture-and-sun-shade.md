---
description: 'BBQs, Furniture & Sun Shade: 49 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: BBQs, Furniture & Sun Shade
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/outdoor-and-landscaping/bbqs-furniture-and-sun-shade/barbecues
      - concept://placemakers/outdoor-and-landscaping/bbqs-furniture-and-sun-shade/furniture
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_outdoor_and_landscaping_bbqs_furniture_and_sun_shade
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/bbqs-furniture-and-sun-shade
  contentHash: 9c68a8ca5f2d8abf38ad0dd5ee2ff9e86faba7a911a1314ea7896ce73fe0fe56
  customerPhrases: []
  description: 'BBQs, Furniture & Sun Shade: 49 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_outdoor_and_landscaping_bbqs_furniture_and_sun_shade
      questionRef: q.nav_outdoor_and_landscaping_bbqs_furniture_and_sun_shade
      valueMap:
        barbecues: concept://placemakers/outdoor-and-landscaping/bbqs-furniture-and-sun-shade/barbecues
        furniture: concept://placemakers/outdoor-and-landscaping/bbqs-furniture-and-sun-shade/furniture
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - BBQs, Furniture & Sun Shade
          path:
            - Outdoor & Landscaping
            - BBQs, Furniture & Sun Shade
          products: 49
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: BBQs, Furniture & Sun Shade
  requiredFacts:
    - factKey: nav_outdoor_and_landscaping_bbqs_furniture_and_sun_shade
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - BBQs, Furniture & Sun Shade
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - bbq
    - bbqs
    - shade
    - shades
    - sun shade
    - sun shades
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: dfe088853d256d1a31b9c628a3121a5838cbde1dac61e2ea499a42cfc6d9565c
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/bbqs-furniture-and-sun-shade
    relationshipId: rel-outdoor-and-landscaping--bbqs-furniture-and-sun-shade-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping
    type: child_of
x-journeyax-synonyms:
  - bbq
  - bbqs
  - shade
  - shades
  - sun shade
  - sun shades
---
# BBQs, Furniture & Sun Shade

BBQs, Furniture & Sun Shade: 49 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Outdoor & Landscaping](../outdoor-and-landscaping.md)
