---
description: 'Fencing & Netting (Non Timber): 1,252 products across 6 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Fencing & Netting (Non Timber)
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/fence-panels
      - concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/fencing-accessories
      - concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/metal-gates
      - concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/posts
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_outdoor_and_landscaping_fencing_and_netting_non_timber
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber
  contentHash: 826df196cdc0d6c565eec3acd8267a422fbce5e5b9080dbcd611f7aca7128d97
  customerPhrases:
    - aluminium fence posts
  description: 'Fencing & Netting (Non Timber): 1,252 products across 6 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_outdoor_and_landscaping_fencing_and_netting_non_timber
      questionRef: q.nav_outdoor_and_landscaping_fencing_and_netting_non_timber
      valueMap:
        fence-panels: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/fence-panels
        fencing-accessories: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/fencing-accessories
        fencing-wire: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/fencing-wire
        metal-gates: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/metal-gates
        netting-and-mesh: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/netting-and-mesh
        posts: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/posts
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-a6d1bcc5762b
    - src-doc-911c73171979
    - src-doc-79e46cedc401
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Fencing & Netting (Non Timber)
          path:
            - Outdoor & Landscaping
            - Fencing & Netting (Non Timber)
          products: 1252
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Fencing & Netting (Non Timber)
  requiredFacts:
    - factKey: nav_outdoor_and_landscaping_fencing_and_netting_non_timber
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - Fencing & Netting (Non Timber)
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - fencing
    - fencings
    - netting non timber
    - netting non timbers
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 94a1b71577f7ecf52160a5636f1d6041eb5edafe2bfe42844191b4f3a67f6eee
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber
    relationshipId: rel-outdoor-and-landscaping--fencing-and-netting-non-timber-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping
    type: child_of
x-journeyax-synonyms:
  - fencing
  - fencings
  - netting non timber
  - netting non timbers
---
# Fencing & Netting (Non Timber)

Fencing & Netting (Non Timber): 1,252 products across 6 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Outdoor & Landscaping](../outdoor-and-landscaping.md)
