---
description: 'PVC Roofing: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: PVC Roofing
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/translucent-roofing/pvc-roofing
  contentHash: 1f3ed7193a3ab3317ba3179a3d88c4a0fcbeb5fe28991fcb8260bb946c26bdf4
  customerPhrases:
    - corrugated pvc roofing
    - patio roofing sheets
    - awnning roofing sheets
    - corrugated roof panels
    - plastic corrugate sheet
    - pvc corrugated sheets
    - light blue roofing sheet
    - 0 8mm roofing sheet
  description: 'PVC Roofing: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-b83b1c4883cb
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:05:19.995Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - PVC Roofing
          path:
            - Outdoor & Landscaping
            - Translucent Roofing
            - PVC Roofing
          products: 4
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: PVC Roofing
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - Translucent Roofing
        - PVC Roofing
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - pvc roofings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 5e686f6ed0866290f59ea64069819b82dcd464d0c9500726af3c2c5f5b555d46
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/translucent-roofing/pvc-roofing
    relationshipId: rel-outdoor-and-landscaping--translucent-roofing--pvc-roofing-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping/translucent-roofing
    type: child_of
x-journeyax-synonyms:
  - pvc roofings
---
# PVC Roofing

PVC Roofing: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Translucent Roofing](../translucent-roofing.md)
