# outdoor-and-landscaping/translucent-roofing

* [PVC Roofing](pvc-roofing.md) - PVC Roofing: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Polycarb Roofing](polycarb-roofing.md) - Polycarb Roofing: 128 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Translucent Roofing Accessories](translucent-roofing-accessories.md) - Translucent Roofing Accessories: 13 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
