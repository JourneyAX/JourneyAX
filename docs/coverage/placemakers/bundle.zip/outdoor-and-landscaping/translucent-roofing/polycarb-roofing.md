---
description: 'Polycarb Roofing: 128 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Polycarb Roofing
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/translucent-roofing/polycarb-roofing
  contentHash: 196c1e33cf84a656ba5d67e945041eb2417dde8dfd27878e577c24d05476673f
  customerPhrases:
    - corrugated polycarbonate
    - polycarbonate flat sheet
    - polycarb panel
    - clear corrugate sheets
    - clear roofing panels
    - polycarb corrugate
    - grey roofing sheet
    - corrugated skylight panels
    - clear roofing
    - suntuf
    - polycarbonate sheets
    - clear roof sheets
  description: 'Polycarb Roofing: 128 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-46503bda042f
    - src-doc-0fc2f6761b95
    - src-doc-856d869da3bc
  extensions:
    x-journeyax-provenance:
      alias_clear_roofing:
        detail:
          alias: clear_roofing
          reason: Suntuf and clear roofing are polycarbonate roofing.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:31.788Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Polycarb Roofing
          path:
            - Outdoor & Landscaping
            - Translucent Roofing
            - Polycarb Roofing
          products: 128
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Polycarb Roofing
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - Translucent Roofing
        - Polycarb Roofing
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - polycarb roofings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 8689a19bec4cbf99ca0dd790e618e792acc8fd187a5dba9e087e9542fd28acc0
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/translucent-roofing/polycarb-roofing
    relationshipId: rel-outdoor-and-landscaping--translucent-roofing--polycarb-roofing-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping/translucent-roofing
    type: child_of
x-journeyax-synonyms:
  - polycarb roofings
---
# Polycarb Roofing

Polycarb Roofing: 128 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Translucent Roofing](../translucent-roofing.md)
