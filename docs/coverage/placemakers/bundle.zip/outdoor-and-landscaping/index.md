# outdoor-and-landscaping

* [BBQs, Furniture & Sun Shade](bbqs-furniture-and-sun-shade.md) - BBQs, Furniture & Sun Shade: 49 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Fencing & Netting (Non Timber)](fencing-and-netting-non-timber.md) - Fencing & Netting (Non Timber): 1,252 products across 6 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Garden & Landscaping (Outdoor & Landscaping)](garden-and-landscaping.md) - Garden & Landscaping: 1,303 products across 15 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Leisure Products](leisure-products.md) - Leisure Products: 14 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Translucent Roofing](translucent-roofing.md) - Translucent Roofing: 145 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [bbqs-furniture-and-sun-shade](bbqs-furniture-and-sun-shade/) - Knowledge and references
* [fencing-and-netting-non-timber](fencing-and-netting-non-timber/) - Knowledge and references
* [garden-and-landscaping](garden-and-landscaping/) - Knowledge and references
* [leisure-products](leisure-products/) - Knowledge and references
* [translucent-roofing](translucent-roofing/) - Knowledge and references
