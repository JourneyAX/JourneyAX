# outdoor-and-landscaping/garden-and-landscaping

* [Clotheslines](clotheslines.md) - Clotheslines: 44 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Decorative Aggregates](decorative-aggregates.md) - Decorative Aggregates: 34 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Garden Containers](garden-containers.md) - Garden Containers: 55 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Garden Sprayers](garden-sprayers.md) - Garden Sprayers: 36 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Kerbs & Edging](kerbs-and-edging.md) - Kerbs & Edging: 6 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Letterboxes](letterboxes.md) - Letterboxes: 191 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Non-Timber Retaining Walls](non-timber-retaining-walls.md) - Non-Timber Retaining Walls: 32 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Paving](paving.md) - Paving: 320 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Plant & Garden Care](plant-and-garden-care.md) - Plant & Garden Care: 53 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Plant & Pest Control](plant-and-pest-control.md) - Plant & Pest Control: 94 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Plants & Seeds](plants-and-seeds.md) - Plants & Seeds: 19 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Underlay & Textiles](underlay-and-textiles.md) - Underlay & Textiles: 87 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Waste](waste.md) - Waste: 5 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Watering Systems](watering-systems.md) - Watering Systems: 291 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Wheelbarrows & Trolleys](wheelbarrows-and-trolleys.md) - Wheelbarrows & Trolleys: 36 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
