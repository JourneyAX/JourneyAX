---
description: 'Letterboxes: 191 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Letterboxes
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/letterboxes
  contentHash: f3285ffe22a4daf5fbcfe35d9b3f712eccbe650601bf100c79210cf27caa8b8b
  customerPhrases:
    - house letters
    - pillar box insert
    - plastic letterbox
    - concrete pillar letterbox
    - mailbox letters
    - wall mounted mail slot
    - polyethylene mailbox
    - grc letterbox
  description: 'Letterboxes: 191 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:31.146Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Letterboxes
          path:
            - Outdoor & Landscaping
            - Garden & Landscaping
            - Letterboxes
          products: 191
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Letterboxes
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - Garden & Landscaping
        - Letterboxes
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - letterbox
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 5138bd4eda55a234020adacee282e0b2df0aa4f971aecd079cf5aa4185a30789
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/letterboxes
    relationshipId: rel-outdoor-and-landscaping--garden-and-landscaping--letterboxes-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping
    type: child_of
x-journeyax-synonyms:
  - letterbox
---
# Letterboxes

Letterboxes: 191 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Garden & Landscaping (Outdoor & Landscaping)](../garden-and-landscaping.md)
