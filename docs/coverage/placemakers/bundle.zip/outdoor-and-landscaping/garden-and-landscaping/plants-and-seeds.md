---
description: 'Plants & Seeds: 19 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Plants & Seeds
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/plants-and-seeds
  contentHash: e54ef74366b32aee740c6014bba4fcb3708e14b950bc91eb8d5ce15f2fdda1f8
  customerPhrases:
    - flower seeds
    - grass seed mix
    - annual seeds
    - patch repair seed
    - cut flower seed mix
    - resealable seed bag
    - compact bedding plants
    - coated lawn seed
  description: 'Plants & Seeds: 19 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-bf2511138d43
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:02:37.274Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Plants & Seeds
          path:
            - Outdoor & Landscaping
            - Garden & Landscaping
            - Plants & Seeds
          products: 19
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Plants & Seeds
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - Garden & Landscaping
        - Plants & Seeds
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - seed
    - seeds
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: e1af41e6ee96c760a8f5ad747684169caadc7e3657f6d042896df1c41a0aa3cf
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/plants-and-seeds
    relationshipId: rel-outdoor-and-landscaping--garden-and-landscaping--plants-and-seeds-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping
    type: child_of
x-journeyax-synonyms:
  - seed
  - seeds
---
# Plants & Seeds

Plants & Seeds: 19 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Garden & Landscaping (Outdoor & Landscaping)](../garden-and-landscaping.md)
