---
description: 'Watering Systems: 291 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Watering Systems
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/watering-systems
  contentHash: cbd7bba65fe4940f024f94ca6b32b5778931959236362e125b1c4c31302f49ca
  customerPhrases:
    - hose joiner
    - spray head
    - underground cable for electric fence
    - hose clip
    - recoil hose
    - hose reel cart
    - garden sprinkler
    - spray nozzle
    - hose
    - hoses
    - garden hose
    - sprinkler
    - sprinklers
    - hose reel
    - tap timer
    - irrigation
    - soaker hose
  description: 'Watering Systems: 291 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-55b82d4d4e23
    - src-doc-a62b9fff3e7a
    - src-doc-fa786b266d4d
  extensions:
    x-journeyax-provenance:
      alias_garden_hose:
        detail:
          alias: garden_hose
          reason: Customers ask for a hose, a sprinkler or a tap timer.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:40.095Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Watering Systems
          path:
            - Outdoor & Landscaping
            - Garden & Landscaping
            - Watering Systems
          products: 291
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Watering Systems
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - Garden & Landscaping
        - Watering Systems
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - watering system
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: acfd2804b00191f762e469b70241d683d6502795cd2a455130e40b2875de1cf9
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/watering-systems
    relationshipId: rel-outdoor-and-landscaping--garden-and-landscaping--watering-systems-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping
    type: child_of
x-journeyax-synonyms:
  - watering system
---
# Watering Systems

Watering Systems: 291 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Garden & Landscaping (Outdoor & Landscaping)](../garden-and-landscaping.md)
