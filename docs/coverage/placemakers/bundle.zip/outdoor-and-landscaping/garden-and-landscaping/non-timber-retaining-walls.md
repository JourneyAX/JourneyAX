---
description: 'Non-Timber Retaining Walls: 32 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Non-Timber Retaining Walls
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/non-timber-retaining-walls
  contentHash: 6d22a13740691a6947ba3cb316a915d8e6ffcab57fd639f7ddbd59f329523e7c
  customerPhrases:
    - segmental blocks
    - slide together wall system
    - segmental wall cap
    - interlocking blocks
    - interlocking retaining posts
    - retaining wall topper
    - garden wall blocks
    - modular garden wall
  description: 'Non-Timber Retaining Walls: 32 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:02:22.154Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Non-Timber Retaining Walls
          path:
            - Outdoor & Landscaping
            - Garden & Landscaping
            - Non-Timber Retaining Walls
          products: 32
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Non-Timber Retaining Walls
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - Garden & Landscaping
        - Non-Timber Retaining Walls
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - non timber retaining wall
    - wall
    - walls
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 15079ea635dab2e5a34f8069e56bf3a665e4d1c74a65ca58c46cfabc92ecc678
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/non-timber-retaining-walls
    relationshipId: rel-outdoor-and-landscaping--garden-and-landscaping--non-timber-retaining-walls-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping
    type: child_of
x-journeyax-synonyms:
  - non timber retaining wall
  - wall
  - walls
---
# Non-Timber Retaining Walls

Non-Timber Retaining Walls: 32 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Garden & Landscaping (Outdoor & Landscaping)](../garden-and-landscaping.md)
