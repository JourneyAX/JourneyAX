---
description: 'Plant & Garden Care: 53 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Plant & Garden Care
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/plant-and-garden-care
  contentHash: 1fbced98745f40c55c0ebfda9d79f34f888d6c350dd049f61cb34ad3187186ca
  customerPhrases:
    - garden feed
    - seaweed fertiliser
    - garden soil mix
    - topsoil mix
    - garden compost
    - slow release fertiliser
    - fish emulsion
    - seed raising mix
  description: 'Plant & Garden Care: 53 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-4d975b663aec
    - src-doc-49d655c4ee1b
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:30.245Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Plant & Garden Care
          path:
            - Outdoor & Landscaping
            - Garden & Landscaping
            - Plant & Garden Care
          products: 53
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Plant & Garden Care
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - Garden & Landscaping
        - Plant & Garden Care
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - care
    - cares
    - garden care
    - garden cares
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: cf1e609b6780f64dff925a9f25acfc37ee8cea0a328c6418a711a1d9dfe3379d
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/plant-and-garden-care
    relationshipId: rel-outdoor-and-landscaping--garden-and-landscaping--plant-and-garden-care-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping
    type: child_of
x-journeyax-synonyms:
  - care
  - cares
  - garden care
  - garden cares
---
# Plant & Garden Care

Plant & Garden Care: 53 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Garden & Landscaping (Outdoor & Landscaping)](../garden-and-landscaping.md)
