---
description: 'Clotheslines: 44 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Clotheslines
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/clotheslines
  contentHash: 0d97c744be74d187e133196996ddc83acfdcab2d6a3f02c02466ac7d7846cab8
  customerPhrases:
    - rotary clothesline
    - clothesline wire pvc coated
    - hilltop hoist
    - washing line wire
    - fold down line
    - line wire for rotary dryer
    - wall mounted folding line
    - clothesline replacement wire
    - washing line
    - washing lines
    - rotary line
    - hills hoist
    - clothes line
    - clothes lines
  description: 'Clotheslines: 44 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-68f0a6e32c6a
    - src-doc-6d4ca31be1b4
    - src-doc-3c2bce582e68
  extensions:
    x-journeyax-provenance:
      alias_washing_line:
        detail:
          alias: washing_line
          reason: Washing line and Hills Hoist are clotheslines.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:15.104Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Clotheslines
          path:
            - Outdoor & Landscaping
            - Garden & Landscaping
            - Clotheslines
          products: 44
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Clotheslines
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - Garden & Landscaping
        - Clotheslines
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - clothesline
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: e7eef95e7582c78a83daa0669b6c630044cfdaac0d97e680668290e2c56cdd9a
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/clotheslines
    relationshipId: rel-outdoor-and-landscaping--garden-and-landscaping--clotheslines-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping
    type: child_of
x-journeyax-synonyms:
  - clothesline
---
# Clotheslines

Clotheslines: 44 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Garden & Landscaping (Outdoor & Landscaping)](../garden-and-landscaping.md)
