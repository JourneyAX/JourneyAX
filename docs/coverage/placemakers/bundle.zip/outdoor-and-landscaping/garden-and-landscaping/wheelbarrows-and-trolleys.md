---
description: 'Wheelbarrows & Trolleys: 36 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Wheelbarrows & Trolleys
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/wheelbarrows-and-trolleys
  contentHash: 791d0a0cb6af383035ac0accc2ce7e829c49f08a657b13cd73040cceb6af476a
  customerPhrases:
    - wheelbarrow tray replacement
    - 63 litre wheelbarrow
    - hand trolley
    - wheelbarrow component pack
    - pourer wheelbarrow
    - garden trolley
    - replacement wheelbarrow tyre
    - bolt free tray
  description: 'Wheelbarrows & Trolleys: 36 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:57.108Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Wheelbarrows & Trolleys
          path:
            - Outdoor & Landscaping
            - Garden & Landscaping
            - Wheelbarrows & Trolleys
          products: 36
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Wheelbarrows & Trolleys
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - Garden & Landscaping
        - Wheelbarrows & Trolleys
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - trolley
    - trolleys
    - wheelbarrow
    - wheelbarrows
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 2c19917fb3a13a6924f5a3d31e00fb70e77c0396a1e3c4831601b3bb2c9e1ff7
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/wheelbarrows-and-trolleys
    relationshipId: rel-outdoor-and-landscaping--garden-and-landscaping--wheelbarrows-and-trolleys-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping
    type: child_of
x-journeyax-synonyms:
  - trolley
  - trolleys
  - wheelbarrow
  - wheelbarrows
---
# Wheelbarrows & Trolleys

Wheelbarrows & Trolleys: 36 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Garden & Landscaping (Outdoor & Landscaping)](../garden-and-landscaping.md)
