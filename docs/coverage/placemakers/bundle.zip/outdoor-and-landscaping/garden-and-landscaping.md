---
description: 'Garden & Landscaping: 1,303 products across 15 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Garden & Landscaping (Outdoor & Landscaping)
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/paving
      - concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/watering-systems
      - concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/letterboxes
      - concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/plant-and-pest-control
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_outdoor_and_landscaping_garden_and_landscaping
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping
  contentHash: 3e0deff0a9079cdd468612401000917a6fb5cb4865cfbce2709adc9c4fe8a5ec
  customerPhrases: []
  description: 'Garden & Landscaping: 1,303 products across 15 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_outdoor_and_landscaping_garden_and_landscaping
      questionRef: q.nav_outdoor_and_landscaping_garden_and_landscaping
      valueMap:
        clotheslines: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/clotheslines
        decorative-aggregates: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/decorative-aggregates
        garden-containers: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/garden-containers
        garden-sprayers: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/garden-sprayers
        kerbs-and-edging: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/kerbs-and-edging
        letterboxes: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/letterboxes
        non-timber-retaining-walls: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/non-timber-retaining-walls
        paving: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/paving
        plant-and-garden-care: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/plant-and-garden-care
        plant-and-pest-control: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/plant-and-pest-control
        plants-and-seeds: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/plants-and-seeds
        underlay-and-textiles: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/underlay-and-textiles
        waste: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/waste
        watering-systems: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/watering-systems
        wheelbarrows-and-trolleys: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping/wheelbarrows-and-trolleys
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-55b82d4d4e23
    - src-doc-68f0a6e32c6a
    - src-doc-6d4ca31be1b4
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Garden & Landscaping
          path:
            - Outdoor & Landscaping
            - Garden & Landscaping
          products: 1303
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Garden & Landscaping (Outdoor & Landscaping)
  requiredFacts:
    - factKey: nav_outdoor_and_landscaping_garden_and_landscaping
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - Garden & Landscaping
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - garden
    - gardens
    - plant
    - plants
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 88a10575083c80119334243f0754ba58d0dc0365f583358db4de66b5dc32c1b7
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping
    relationshipId: rel-outdoor-and-landscaping--garden-and-landscaping-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping
    type: child_of
x-journeyax-synonyms:
  - garden
  - gardens
  - plant
  - plants
---
# Garden & Landscaping (Outdoor & Landscaping)

Garden & Landscaping: 1,303 products across 15 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Outdoor & Landscaping](../outdoor-and-landscaping.md)
