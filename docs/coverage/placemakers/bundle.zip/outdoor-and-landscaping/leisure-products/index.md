# outdoor-and-landscaping/leisure-products

* [Leisure Items](leisure-items.md) - Leisure Items: 14 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
