---
description: 'Leisure Items: 14 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Leisure Items
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/leisure-products/leisure-items
  contentHash: 916b1142313d1a23f13f06923d75ce8a5a0242e5711843bdbb3135f1250e02c3
  customerPhrases:
    - smoke chips
    - camping shower
    - salt for pool chlorinator
    - rain cape
    - insulated drink bottle
    - wood chips
    - portable shower
    - saltwater pool salt
  description: 'Leisure Items: 14 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:03:58.595Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Leisure Items
          path:
            - Outdoor & Landscaping
            - Leisure Products
            - Leisure Items
          products: 14
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Leisure Items
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - Leisure Products
        - Leisure Items
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - leisure item
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 7b7fb903280e03e51ad43de71a092fbb57ad9c45ea2d791d66bdba2423afb11f
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/leisure-products/leisure-items
    relationshipId: rel-outdoor-and-landscaping--leisure-products--leisure-items-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping/leisure-products
    type: child_of
x-journeyax-synonyms:
  - leisure item
---
# Leisure Items

Leisure Items: 14 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Leisure Products](../leisure-products.md)
