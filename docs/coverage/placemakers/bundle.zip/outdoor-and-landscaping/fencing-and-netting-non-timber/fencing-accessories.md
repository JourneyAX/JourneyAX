---
description: 'Fencing Accessories: 309 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Fencing Accessories
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/fencing-accessories
  contentHash: 233958b975cb387b4a60f643ce8ab3ef27b296120d92d5dde42aa0b8f64b7491
  customerPhrases:
    - aluminium balustrade brackets
    - glass spigot
    - crimp ferrules
    - raking bracket kit
    - balustrade spigot
    - picket gate kit
    - sleeve crimps
    - powdercoated aluminium spacer
  description: 'Fencing Accessories: 309 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:42.423Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Fencing Accessories
          path:
            - Outdoor & Landscaping
            - Fencing & Netting (Non Timber)
            - Fencing Accessories
          products: 309
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Fencing Accessories
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - Fencing & Netting (Non Timber)
        - Fencing Accessories
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - fencing accessory
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 2965f0b8e208695acc55d3eb628797dce4483b1957f515ab6bffaf37fd2506bd
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/fencing-accessories
    relationshipId: rel-outdoor-and-landscaping--fencing-and-netting-non-timber--fencing-accessories-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber
    type: child_of
x-journeyax-synonyms:
  - fencing accessory
---
# Fencing Accessories

Fencing Accessories: 309 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Fencing & Netting (Non Timber)](../fencing-and-netting-non-timber.md)
