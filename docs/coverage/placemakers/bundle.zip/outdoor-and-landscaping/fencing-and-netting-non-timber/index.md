# outdoor-and-landscaping/fencing-and-netting-non-timber

* [Fence Panels](fence-panels.md) - Fence Panels: 408 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Fencing Accessories](fencing-accessories.md) - Fencing Accessories: 309 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Fencing Wire](fencing-wire.md) - Fencing Wire: 95 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Metal Gates](metal-gates.md) - Metal Gates: 240 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Netting & Mesh](netting-and-mesh.md) - Netting & Mesh: 70 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Posts](posts.md) - Posts: 130 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
