---
description: 'Fence Panels: 408 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Fence Panels
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/fence-panels
  contentHash: 888ad2c50975730be86ad76580b334d71a4a3cc4b462d3cdebcc9b2451f0f281
  customerPhrases:
    - coloursteel fence
    - aluminium slat fence
    - frameless pool glass
    - privacy screen panel
    - metal paling panel
    - balustrade panel
    - balustrade glass panel
    - decorative screening
  description: 'Fence Panels: 408 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-911c73171979
    - src-doc-23767054bf47
    - src-doc-fa23e2129f45
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:23.677Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Fence Panels
          path:
            - Outdoor & Landscaping
            - Fencing & Netting (Non Timber)
            - Fence Panels
          products: 408
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Fence Panels
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - Fencing & Netting (Non Timber)
        - Fence Panels
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - fence panel
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: cd23e0d251ca9e64c81eb9bd58c8f45e22b9e2c24aeab8fd2fc6238943d2fcc4
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/fence-panels
    relationshipId: rel-outdoor-and-landscaping--fencing-and-netting-non-timber--fence-panels-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber
    type: child_of
x-journeyax-synonyms:
  - fence panel
---
# Fence Panels

Fence Panels: 408 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Fencing & Netting (Non Timber)](../fencing-and-netting-non-timber.md)
