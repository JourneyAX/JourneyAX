---
description: 'Fencing Wire: 95 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Fencing Wire
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/fencing-wire
  contentHash: 98636d48d2c4f140b5682eeff038053538e4f7ce4c0f325a1b3d6aa4d45fc54a
  customerPhrases:
    - fencing binding wire
    - wire strainer
    - fence wire blue
    - low tensile wire
    - barbed wire staples
    - high tensile barb wire
    - fence strainer
    - high tensile fencing
  description: 'Fencing Wire: 95 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:52.530Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Fencing Wire
          path:
            - Outdoor & Landscaping
            - Fencing & Netting (Non Timber)
            - Fencing Wire
          products: 95
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Fencing Wire
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - Fencing & Netting (Non Timber)
        - Fencing Wire
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - fencing wires
    - wire
    - wires
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: c4e6d825b2e21b476af1393420e3fb46b9fcb4b1a18be78e6047f89ade793f46
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/fencing-wire
    relationshipId: rel-outdoor-and-landscaping--fencing-and-netting-non-timber--fencing-wire-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber
    type: child_of
x-journeyax-synonyms:
  - fencing wires
  - wire
  - wires
---
# Fencing Wire

Fencing Wire: 95 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Fencing & Netting (Non Timber)](../fencing-and-netting-non-timber.md)
