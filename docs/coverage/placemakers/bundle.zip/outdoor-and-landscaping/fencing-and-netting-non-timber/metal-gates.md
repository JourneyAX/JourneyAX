---
description: 'Metal Gates: 240 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Metal Gates
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/metal-gates
  contentHash: 7220b768e9275c504f52ef8521c19cf7611aedd43940e49d2401b85544d368dd
  customerPhrases:
    - pedestrian gate aluminium
    - stock gate
    - slatted gate
    - livestock gate
    - horizontal slat gate
    - farm entrance gate
    - privacy gate
    - chain link gate
  description: 'Metal Gates: 240 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-a6d1bcc5762b
    - src-doc-c27051251716
    - src-doc-4b2c0e057985
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:19.820Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Metal Gates
          path:
            - Outdoor & Landscaping
            - Fencing & Netting (Non Timber)
            - Metal Gates
          products: 240
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Metal Gates
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
        - Fencing & Netting (Non Timber)
        - Metal Gates
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - gate
    - gates
    - metal gate
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 67eaafa766d25b38d36a72b8ad0af3bc81c3e5f7139445f00fa433d886d6577c
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/metal-gates
    relationshipId: rel-outdoor-and-landscaping--fencing-and-netting-non-timber--metal-gates-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber
    type: child_of
x-journeyax-synonyms:
  - gate
  - gates
  - metal gate
---
# Metal Gates

Metal Gates: 240 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Fencing & Netting (Non Timber)](../fencing-and-netting-non-timber.md)
