---
description: 'Rivets: 31 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Rivets
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/fastenings-and-general-hardware/fastenings/rivets
  contentHash: 2ba082eb67778d31c16fb0392bc9940e30c52f67bf24f6cd75a263b35e90478e
  customerPhrases:
    - blind rivet
    - pop rivet
    - aluminium rivet
    - steel stem rivet
    - truss head rivet
    - roofing rivet
    - sheets rivet
    - panel rivet
  description: 'Rivets: 31 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:17.686Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Rivets
          path:
            - Fastenings & General Hardware
            - Fastenings
            - Rivets
          products: 31
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Rivets
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Fastenings & General Hardware
        - Fastenings
        - Rivets
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - rivet
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 380b60c54481c903e6bdcf0b69ba1a31faa1ce4a5033deaca0dd358671312978
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/fastenings/rivets
    relationshipId: rel-fastenings-and-general-hardware--fastenings--rivets-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/fastenings-and-general-hardware/fastenings
    type: child_of
x-journeyax-synonyms:
  - rivet
---
# Rivets

Rivets: 31 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Fastenings](../fastenings.md)
