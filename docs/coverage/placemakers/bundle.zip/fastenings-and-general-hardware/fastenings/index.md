# fastenings-and-general-hardware/fastenings

* [Bolts & Nut](bolts-and-nut.md) - Bolts & Nut: 310 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Building Brackets](building-brackets.md) - Building Brackets: 114 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Collated Nails](collated-nails.md) - Collated Nails: 277 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Loose Nails](loose-nails.md) - Loose Nails: 175 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Masonry  Anchors](masonry-anchors.md) - Masonry  Anchors: 412 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Metal Screws](metal-screws.md) - Metal Screws: 78 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Power Actuated](power-actuated.md) - Power Actuated: 43 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Rivets](rivets.md) - Rivets: 31 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Ties, Soakers](ties-soakers.md) - Ties, Soakers: 15 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Timber Connectors](timber-connectors.md) - Timber Connectors: 179 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Wood Screws](wood-screws.md) - Wood Screws: 991 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
