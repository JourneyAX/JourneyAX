---
description: 'Loose Nails: 175 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Loose Nails
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: true
  conceptId: concept://placemakers/fastenings-and-general-hardware/fastenings/loose-nails
  contentHash: 64d826db37b9502f75943530b66b28adc7d8914d99b308b4471517e02c7b38ad
  customerPhrases:
    - bright nails
    - jolthead nail
    - clouts
    - rose head nails
    - pin nails
    - jolt head nails
    - boat nails
    - annular grooved nails
    - clout nails
    - flat head nails
    - galv nails
    - galvanised nails
    - brads
    - roofing nails
  description: 'Loose Nails: 175 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_clouts:
        detail:
          alias: clouts
          reason: Clouts and brads are the trade names for common nails.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:36.501Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      policy_fixings_depend_on_substrate:
        detail:
          overlay: fixings_depend_on_substrate
          reason: The right fixing depends on what it goes into, so these categories are treated as compatibility-sensitive.
          section: overlays
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Loose Nails
          path:
            - Fastenings & General Hardware
            - Fastenings
            - Loose Nails
          products: 175
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Loose Nails
  requiredFacts: []
  riskClass: compatibility
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Fastenings & General Hardware
        - Fastenings
        - Loose Nails
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - loose nail
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: medium
    contentHash: ea12b56e06c632daba6f28b462362443e6bbca507d4e3fb9f6b8789609e6746d
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: families
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/fastenings/loose-nails
    relationshipId: rel-family-nails-loose-nails
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/families/nails
    type: child_of
  - claimClasses: []
    confidence: high
    contentHash: 0ed3b0bfcb1cc4964bdb5b10d4b148a5795f622488a9e581fb3deb2d44a13495
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/fastenings/loose-nails
    relationshipId: rel-fastenings-and-general-hardware--fastenings--loose-nails-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/fastenings-and-general-hardware/fastenings
    type: child_of
x-journeyax-synonyms:
  - loose nail
---
# Loose Nails

Loose Nails: 175 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Nails](../../families/nails.md)
* child of: [Fastenings](../fastenings.md)
