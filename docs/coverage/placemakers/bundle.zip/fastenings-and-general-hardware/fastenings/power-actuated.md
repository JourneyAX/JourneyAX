---
description: 'Power Actuated: 43 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Power Actuated
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: true
  conceptId: concept://placemakers/fastenings-and-general-hardware/fastenings/power-actuated
  contentHash: 45532ab270dd464780cf5a303f1a70cf2b6982ecdd146725a0cff0e6dd355adb
  customerPhrases:
    - powder actuated nails
    - powder actuated tool accessories
    - collated drive nails
    - power actuator charges
    - washer discs
    - concrete nails
    - drive pins for concrete
    - powder loads 22
  description: 'Power Actuated: 43 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-399e76fae9f3
    - src-doc-7a7acbfe0dd4
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:03:13.426Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      policy_fixings_depend_on_substrate:
        detail:
          overlay: fixings_depend_on_substrate
          reason: The right fixing depends on what it goes into, so these categories are treated as compatibility-sensitive.
          section: overlays
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Power Actuated
          path:
            - Fastenings & General Hardware
            - Fastenings
            - Power Actuated
          products: 43
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Power Actuated
  requiredFacts: []
  riskClass: compatibility
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Fastenings & General Hardware
        - Fastenings
        - Power Actuated
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - actuated
    - actuateds
    - power actuateds
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: b17074ef7e4811ec5d99afad479e51748b8f894aa23c8a2187525922f3ef2914
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/fastenings/power-actuated
    relationshipId: rel-fastenings-and-general-hardware--fastenings--power-actuated-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/fastenings-and-general-hardware/fastenings
    type: child_of
x-journeyax-synonyms:
  - actuated
  - actuateds
  - power actuateds
---
# Power Actuated

Power Actuated: 43 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Fastenings](../fastenings.md)
