---
description: 'Masonry  Anchors: 412 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Masonry  Anchors
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: true
  conceptId: concept://placemakers/fastenings-and-general-hardware/fastenings/masonry-anchors
  contentHash: 291076aa16a4973e66c1c49d7e2476eaac3c2d47610d4d4333d21c5de5de53ff
  customerPhrases:
    - screw in anchor
    - rawlplug
    - wedge anchor
    - toggle bolt
    - concrete pins
    - concrete screw anchor
    - bottom plate anchor
    - concrete spikes
    - dynabolt
    - dynabolts
    - dyna bolt
    - dyna bolts
    - sleeve anchor
    - sleeve anchors
    - rawlplugs
    - rawl plug
    - wall plug
    - wall plugs
    - tapcon
    - concrete anchors
  description: 'Masonry  Anchors: 412 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-4f3f3f0a14e6
    - src-doc-dabc92877e3f
    - src-doc-499ffce69022
  extensions:
    x-journeyax-provenance:
      alias_dynabolts:
        detail:
          alias: dynabolts
          reason: Dynabolt and Rawlplug are the brand names customers use for masonry anchors.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:39.992Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      policy_fixings_depend_on_substrate:
        detail:
          overlay: fixings_depend_on_substrate
          reason: The right fixing depends on what it goes into, so these categories are treated as compatibility-sensitive.
          section: overlays
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Masonry  Anchors
          path:
            - Fastenings & General Hardware
            - Fastenings
            - Masonry  Anchors
          products: 412
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Masonry  Anchors
  requiredFacts: []
  riskClass: compatibility
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Fastenings & General Hardware
        - Fastenings
        - Masonry  Anchors
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - anchor
    - anchors
    - masonry anchor
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: medium
    contentHash: 39489db47a851d6478705ac93fc04527ef401c89589941a8e57f20d2eee856e4
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: families
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/fastenings/masonry-anchors
    relationshipId: rel-family-screws-masonry-anchors
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/families/screws
    type: child_of
  - claimClasses: []
    confidence: high
    contentHash: bf5840fe17df7980d207d00e7a1405840d702ff0fe1940ff455cb2f3242c3048
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/fastenings/masonry-anchors
    relationshipId: rel-fastenings-and-general-hardware--fastenings--masonry-anchors-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/fastenings-and-general-hardware/fastenings
    type: child_of
x-journeyax-synonyms:
  - anchor
  - anchors
  - masonry anchor
---
# Masonry  Anchors

Masonry  Anchors: 412 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Screws](../../families/screws.md)
* child of: [Fastenings](../fastenings.md)
