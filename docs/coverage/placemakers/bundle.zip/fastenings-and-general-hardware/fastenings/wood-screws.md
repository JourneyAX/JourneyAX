---
description: 'Wood Screws: 991 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Wood Screws
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: true
  conceptId: concept://placemakers/fastenings-and-general-hardware/fastenings/wood-screws
  contentHash: 5db6687d1cd3edd75c906ac3b5531030130fba53b1a8ede9b3b0a2a46ab0dd85
  customerPhrases:
    - cladding screws
    - wafer head screw
    - joltscrew
    - stainless deck screws
    - timber screws
    - type 17 screw
    - collated screws
    - landscape timber screws
  description: 'Wood Screws: 991 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-010a0c7530a0
    - src-doc-4977ebbbc79a
    - src-doc-7365139ed9fb
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:21.833Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      policy_fixings_depend_on_substrate:
        detail:
          overlay: fixings_depend_on_substrate
          reason: The right fixing depends on what it goes into, so these categories are treated as compatibility-sensitive.
          section: overlays
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Wood Screws
          path:
            - Fastenings & General Hardware
            - Fastenings
            - Wood Screws
          products: 991
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Wood Screws
  requiredFacts: []
  riskClass: compatibility
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Fastenings & General Hardware
        - Fastenings
        - Wood Screws
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - wood screw
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: medium
    contentHash: 83b8b13d8cdf03395d2cd54c191213fe0d3ae903ee18ac15aa2d133263cb9ee6
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: families
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/fastenings/wood-screws
    relationshipId: rel-family-screws-wood-screws
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/families/screws
    type: child_of
  - claimClasses: []
    confidence: high
    contentHash: e444a52e5ba27cb0474d7fc16acfa952887bd6582900a85998e538633408cb34
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/fastenings/wood-screws
    relationshipId: rel-fastenings-and-general-hardware--fastenings--wood-screws-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/fastenings-and-general-hardware/fastenings
    type: child_of
  - claimClasses: []
    confidence: low
    contentHash: b1dab34e90a1db0cebfa6077124fff850a8f2c53ef6c2d6c8f251e5df0a6cebc
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/fastenings/wood-screws
    relationshipId: rel-xs-wood_screw_extras-1
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/tools/power-tool-accessories/drill-bits
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: bb51634a2d9624791914637d7fab0d40e79ed75f54d486d9817c2448767ad4d8
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/fastenings/wood-screws
    relationshipId: rel-xs-wood_screw_extras-2
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/tools/power-tool-accessories/screwdriver-bits
    type: cross_sell
x-journeyax-synonyms:
  - wood screw
---
# Wood Screws

Wood Screws: 991 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Screws](../../families/screws.md)
* child of: [Fastenings](../fastenings.md)
* cross sell: [Drill Bits](../../tools/power-tool-accessories/drill-bits.md)
* cross sell: [Screwdriver Bits](../../tools/power-tool-accessories/screwdriver-bits.md)
