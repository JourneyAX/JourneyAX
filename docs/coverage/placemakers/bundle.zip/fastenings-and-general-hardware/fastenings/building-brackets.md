---
description: 'Building Brackets: 114 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Building Brackets
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: true
  conceptId: concept://placemakers/fastenings-and-general-hardware/fastenings/building-brackets
  contentHash: f805aa70d17fedf49bdd9fce90291dfdbbe2022b1aefb55844527919737875a5
  customerPhrases:
    - angle brace
    - post base bracket
    - corner brace
    - post anchor
    - joining bracket
    - bearer support
    - flat plate bracket
    - timber post bracket
  description: 'Building Brackets: 114 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:49.990Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      policy_fixings_depend_on_substrate:
        detail:
          overlay: fixings_depend_on_substrate
          reason: The right fixing depends on what it goes into, so these categories are treated as compatibility-sensitive.
          section: overlays
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Building Brackets
          path:
            - Fastenings & General Hardware
            - Fastenings
            - Building Brackets
          products: 114
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Building Brackets
  requiredFacts: []
  riskClass: compatibility
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Fastenings & General Hardware
        - Fastenings
        - Building Brackets
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - bracket
    - brackets
    - building bracket
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 3465aa51da0e4412e6cb47c77707c6c58bbf1453cf1101e66de5f1067e2f910d
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/fastenings/building-brackets
    relationshipId: rel-fastenings-and-general-hardware--fastenings--building-brackets-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/fastenings-and-general-hardware/fastenings
    type: child_of
x-journeyax-synonyms:
  - bracket
  - brackets
  - building bracket
---
# Building Brackets

Building Brackets: 114 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Fastenings](../fastenings.md)
