---
description: 'Metal Screws: 78 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Metal Screws
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: true
  conceptId: concept://placemakers/fastenings-and-general-hardware/fastenings/metal-screws
  contentHash: ce45b95f751d4375c096855060ea1df456e5e689bbc50a65fce33ff5227037c5
  customerPhrases:
    - wafer head self drilling
    - cement sheet screw
    - button head screws
    - winged self drilling screw
    - self tapping metal screw
    - tek screw no washer
    - type 17 timber screw
    - hardie screw
  description: 'Metal Screws: 78 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:02:20.096Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      policy_fixings_depend_on_substrate:
        detail:
          overlay: fixings_depend_on_substrate
          reason: The right fixing depends on what it goes into, so these categories are treated as compatibility-sensitive.
          section: overlays
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Metal Screws
          path:
            - Fastenings & General Hardware
            - Fastenings
            - Metal Screws
          products: 78
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Metal Screws
  requiredFacts: []
  riskClass: compatibility
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Fastenings & General Hardware
        - Fastenings
        - Metal Screws
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - metal screw
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: medium
    contentHash: 5131401dcc0233b8892df12f49e368bb26fac9c2ca4eb4d9843991524d9c096f
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: families
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/fastenings/metal-screws
    relationshipId: rel-family-screws-metal-screws
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/families/screws
    type: child_of
  - claimClasses: []
    confidence: high
    contentHash: 71bea38d51536d5a3887fc445c1e848ec8e83dd2092ef88572911c94c5b3ab53
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/fastenings/metal-screws
    relationshipId: rel-fastenings-and-general-hardware--fastenings--metal-screws-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/fastenings-and-general-hardware/fastenings
    type: child_of
  - claimClasses: []
    confidence: low
    contentHash: f38c1efd908152033e89b5e7d7254664c1022102bc780e5fbf025ec0a00b9c5b
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/fastenings/metal-screws
    relationshipId: rel-xs-metal_screw_extras-1
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/tools/power-tool-accessories/drill-bits
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: c561308d0bbbc4531f779000858bcd4721b954f18b429afbe5b1488be406b0bf
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/fastenings/metal-screws
    relationshipId: rel-xs-metal_screw_extras-2
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/tools/power-tool-accessories/screwdriver-bits
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: 8f90d084e329e76ef34f6790d54cdc03172a9e6f1fc2b9c24a6f0c5cf2a18c02
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/fastenings/metal-screws
    relationshipId: rel-xs-metal_screw_extras-3
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/safety-and-ladders/safety/eye-protection
    type: cross_sell
x-journeyax-synonyms:
  - metal screw
---
# Metal Screws

Metal Screws: 78 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Screws](../../families/screws.md)
* child of: [Fastenings](../fastenings.md)
* cross sell: [Drill Bits](../../tools/power-tool-accessories/drill-bits.md)
* cross sell: [Screwdriver Bits](../../tools/power-tool-accessories/screwdriver-bits.md)
* cross sell: [Eye Protection](../../safety-and-ladders/safety/eye-protection.md)
