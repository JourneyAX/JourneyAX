---
description: 'Packers, Wedges, Pods: 78 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Packers, Wedges, Pods
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/fastenings-and-general-hardware/hardware/packers-wedges-pods
  contentHash: 49f16db361be8b62b2cc396999000f62e241492c5bc5865b5feac47903535168
  customerPhrases:
    - decking pods
    - packing wedges
    - joist pedestals
    - door shims
    - deck supports
    - window packers
    - timber shims
    - pile pads
  description: 'Packers, Wedges, Pods: 78 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-a1a1229daa96
    - src-doc-d188fa173e04
    - src-doc-661057e61933
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:00.185Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Packers, Wedges, Pods
          path:
            - Fastenings & General Hardware
            - Hardware
            - Packers, Wedges, Pods
          products: 78
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Packers, Wedges, Pods
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Fastenings & General Hardware
        - Hardware
        - Packers, Wedges, Pods
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - packer
    - packers
    - pod
    - pods
    - wedge
    - wedges
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 27a624cbe5e6ff85e4af5c4539cfaf4e7840e72fd8c444d078690e44035e7287
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/hardware/packers-wedges-pods
    relationshipId: rel-fastenings-and-general-hardware--hardware--packers-wedges-pods-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/fastenings-and-general-hardware/hardware
    type: child_of
x-journeyax-synonyms:
  - packer
  - packers
  - pod
  - pods
  - wedge
  - wedges
---
# Packers, Wedges, Pods

Packers, Wedges, Pods: 78 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Hardware](../hardware.md)
