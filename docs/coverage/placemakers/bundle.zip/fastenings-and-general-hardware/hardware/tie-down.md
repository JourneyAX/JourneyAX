---
description: 'Tie Down: 33 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Tie Down
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/fastenings-and-general-hardware/hardware/tie-down
  contentHash: d652710ceecc6b3d1551889976d7ff98fd35d3d4d2817f4ceaded3b1a980586f
  customerPhrases:
    - ratchet straps
    - shock cord
    - cam strap
    - cam buckle strap
    - tie down straps
    - bungy cord
    - s hook tie down
    - lashing straps
    - ratchet strap
    - tie downs
    - bungee
    - bungee cords
    - cargo strap
    - cargo straps
  description: 'Tie Down: 33 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-438a2b5d51a9
    - src-doc-64fb1b095637
  extensions:
    x-journeyax-provenance:
      alias_ratchet_straps:
        detail:
          alias: ratchet_straps
          reason: Ratchet straps and bungee cords are tie-downs.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:02:31.418Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Tie Down
          path:
            - Fastenings & General Hardware
            - Hardware
            - Tie Down
          products: 33
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Tie Down
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Fastenings & General Hardware
        - Hardware
        - Tie Down
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - down
    - downs
    - tie downs
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: d795230316c6c6138048514d15f0e0c4f9d61bb819d5db3e445921212e14eac7
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/hardware/tie-down
    relationshipId: rel-fastenings-and-general-hardware--hardware--tie-down-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/fastenings-and-general-hardware/hardware
    type: child_of
x-journeyax-synonyms:
  - down
  - downs
  - tie downs
---
# Tie Down

Tie Down: 33 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Hardware](../hardware.md)
