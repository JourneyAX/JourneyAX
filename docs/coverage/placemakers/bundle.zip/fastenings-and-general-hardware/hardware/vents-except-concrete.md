---
description: 'Vents (Except Concrete): 9 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Vents (Except Concrete)
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/fastenings-and-general-hardware/hardware/vents-except-concrete
  contentHash: e4e53d808d66d6330543d1c145bcb2dfef20cf7b720eb730ea585408dbdc08b8
  customerPhrases:
    - foundation vent
    - cavity vent
    - aluminium louvre vent
    - vent grille
    - air brick alternative
    - subfloor vent
    - moisture control vent
    - tradie vent
  description: 'Vents (Except Concrete): 9 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:03:53.513Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Vents (Except Concrete)
          path:
            - Fastenings & General Hardware
            - Hardware
            - Vents (Except Concrete)
          products: 9
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Vents (Except Concrete)
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Fastenings & General Hardware
        - Hardware
        - Vents (Except Concrete)
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - vents except concretes
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 8fefc9fe990ba053029afe0d26b0ccc2e019ccd4c404aad579b4a7d6e2139f0e
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/hardware/vents-except-concrete
    relationshipId: rel-fastenings-and-general-hardware--hardware--vents-except-concrete-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/fastenings-and-general-hardware/hardware
    type: child_of
x-journeyax-synonyms:
  - vents except concretes
---
# Vents (Except Concrete)

Vents (Except Concrete): 9 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Hardware](../hardware.md)
