---
description: 'Fastenings: 2,625 products across 11 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Fastenings
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/fastenings-and-general-hardware/fastenings/wood-screws
      - concept://placemakers/fastenings-and-general-hardware/fastenings/masonry-anchors
      - concept://placemakers/fastenings-and-general-hardware/fastenings/bolts-and-nut
      - concept://placemakers/fastenings-and-general-hardware/fastenings/collated-nails
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_fastenings_and_general_hardware_fastenings
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/fastenings-and-general-hardware/fastenings
  contentHash: e970fb17156accd4c38f9cbfdef02bf6db6ce1cd74fbe8dc67984c894acd3258
  customerPhrases:
    - timber screw
    - roofing screws
    - neo washer screw
    - masonry nails
    - drive pins
    - anchor stud
    - masonry bolt
    - timber to concrete fixings
  description: 'Fastenings: 2,625 products across 11 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_fastenings_and_general_hardware_fastenings
      questionRef: q.nav_fastenings_and_general_hardware_fastenings
      valueMap:
        bolts-and-nut: concept://placemakers/fastenings-and-general-hardware/fastenings/bolts-and-nut
        building-brackets: concept://placemakers/fastenings-and-general-hardware/fastenings/building-brackets
        collated-nails: concept://placemakers/fastenings-and-general-hardware/fastenings/collated-nails
        loose-nails: concept://placemakers/fastenings-and-general-hardware/fastenings/loose-nails
        masonry-anchors: concept://placemakers/fastenings-and-general-hardware/fastenings/masonry-anchors
        metal-screws: concept://placemakers/fastenings-and-general-hardware/fastenings/metal-screws
        power-actuated: concept://placemakers/fastenings-and-general-hardware/fastenings/power-actuated
        rivets: concept://placemakers/fastenings-and-general-hardware/fastenings/rivets
        ties-soakers: concept://placemakers/fastenings-and-general-hardware/fastenings/ties-soakers
        timber-connectors: concept://placemakers/fastenings-and-general-hardware/fastenings/timber-connectors
        wood-screws: concept://placemakers/fastenings-and-general-hardware/fastenings/wood-screws
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-010a0c7530a0
    - src-doc-4f3f3f0a14e6
    - src-doc-dabc92877e3f
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Fastenings
          path:
            - Fastenings & General Hardware
            - Fastenings
          products: 2625
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Fastenings
  requiredFacts:
    - factKey: nav_fastenings_and_general_hardware_fastenings
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Fastenings & General Hardware
        - Fastenings
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 9b68495a8563f5fe76cfa23f96ac30b404c5d597813fc667e9bf0f5f6a27a415
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/fastenings
    relationshipId: rel-fastenings-and-general-hardware--fastenings-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/fastenings-and-general-hardware
    type: child_of
---
# Fastenings

Fastenings: 2,625 products across 11 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Fastenings & General Hardware](../fastenings-and-general-hardware.md)
