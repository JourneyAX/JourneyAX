# fastenings-and-general-hardware

* [Fastenings](fastenings.md) - Fastenings: 2,625 products across 11 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Hardware](hardware.md) - Hardware: 497 products across 11 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [fastenings](fastenings/) - Knowledge and references
* [hardware](hardware/) - Knowledge and references
