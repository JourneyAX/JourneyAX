---
description: 'Hardware: 497 products across 11 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Hardware
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/fastenings-and-general-hardware/hardware/gate-hardware
      - concept://placemakers/fastenings-and-general-hardware/hardware/rope-and-chain-accessories
      - concept://placemakers/fastenings-and-general-hardware/hardware/packers-wedges-pods
      - concept://placemakers/fastenings-and-general-hardware/hardware/padlocks
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_fastenings_and_general_hardware_hardware
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/fastenings-and-general-hardware/hardware
  contentHash: 6578f767452598cbd845d5a098d712b4bc40cb3ebf42ed4a771cadce99505a05
  customerPhrases:
    - galvanised link
    - security cable
    - heavy duty chain
  description: 'Hardware: 497 products across 11 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_fastenings_and_general_hardware_hardware
      questionRef: q.nav_fastenings_and_general_hardware_hardware
      valueMap:
        chain: concept://placemakers/fastenings-and-general-hardware/hardware/chain
        gate-hardware: concept://placemakers/fastenings-and-general-hardware/hardware/gate-hardware
        general-hardware: concept://placemakers/fastenings-and-general-hardware/hardware/general-hardware
        hooks: concept://placemakers/fastenings-and-general-hardware/hardware/hooks
        packers-wedges-pods: concept://placemakers/fastenings-and-general-hardware/hardware/packers-wedges-pods
        padlocks: concept://placemakers/fastenings-and-general-hardware/hardware/padlocks
        rope-and-chain-accessories: concept://placemakers/fastenings-and-general-hardware/hardware/rope-and-chain-accessories
        rope-and-wire: concept://placemakers/fastenings-and-general-hardware/hardware/rope-and-wire
        tarps-and-accessories: concept://placemakers/fastenings-and-general-hardware/hardware/tarps-and-accessories
        tie-down: concept://placemakers/fastenings-and-general-hardware/hardware/tie-down
        vents-except-concrete: concept://placemakers/fastenings-and-general-hardware/hardware/vents-except-concrete
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-a1a1229daa96
    - src-doc-d188fa173e04
    - src-doc-661057e61933
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Hardware
          path:
            - Fastenings & General Hardware
            - Hardware
          products: 497
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Hardware
  requiredFacts:
    - factKey: nav_fastenings_and_general_hardware_hardware
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Fastenings & General Hardware
        - Hardware
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - rope
    - ropes
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 5bcf1a430ec0a9ffab2051d05c2cde79f7d8e1f98fcd2f1d05194f3d3b81683e
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/fastenings-and-general-hardware/hardware
    relationshipId: rel-fastenings-and-general-hardware--hardware-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/fastenings-and-general-hardware
    type: child_of
x-journeyax-synonyms:
  - rope
  - ropes
---
# Hardware

Hardware: 497 products across 11 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Fastenings & General Hardware](../fastenings-and-general-hardware.md)
