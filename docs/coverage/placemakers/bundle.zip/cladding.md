---
description: 'Cladding: 327 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Cladding
type: department
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/cladding/timber-cladding
      - concept://placemakers/cladding/prefinished-cladding-and-facades
      - concept://placemakers/cladding/fibre-cement-and-accessories
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_cladding
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cladding
  contentHash: 223a03d6146c9b9dc134f56bfea6d1acd5257c79764cf5e665cc1f097a4b10eb
  customerPhrases: []
  description: 'Cladding: 327 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_cladding
      questionRef: q.nav_cladding
      valueMap:
        fibre-cement-and-accessories: concept://placemakers/cladding/fibre-cement-and-accessories
        prefinished-cladding-and-facades: concept://placemakers/cladding/prefinished-cladding-and-facades
        timber-cladding: concept://placemakers/cladding/timber-cladding
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-a992d27e75a9
    - src-doc-f923359526dc
    - src-doc-fc4f75744900
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Cladding
          path:
            - Cladding
          products: 327
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Cladding
  requiredFacts:
    - factKey: nav_cladding
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cladding
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - claddings
  tenantId: placemakers
  type: department
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - claddings
---
# Cladding

Cladding: 327 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
