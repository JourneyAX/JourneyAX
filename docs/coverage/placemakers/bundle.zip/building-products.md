---
description: 'Building Products: 1,977 products across 17 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Building Products
type: department
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/building-products/insulation
      - concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes
      - concept://placemakers/building-products/wet-wall-linings
      - concept://placemakers/building-products/panels
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_building_products
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products
  contentHash: 23292fd9661aea97f9ccafe317c9f7bda73b6a88070efdc368eac476c66440d8
  customerPhrases:
    - thermal insulation board
    - corner flashing
    - rigid wall underlay
    - water resistant wallboard
    - wall lining board
    - moisture resistant board
    - particle board sheets
    - osb alternative
  description: 'Building Products: 1,977 products across 17 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_building_products
      questionRef: q.nav_building_products
      valueMap:
        aggregates: concept://placemakers/building-products/aggregates
        building-wraps-barriers-underlay-and-tapes: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes
        ceilings: concept://placemakers/building-products/ceilings
        concrete: concept://placemakers/building-products/concrete
        concrete-and-mortars: concept://placemakers/building-products/concrete-and-mortars
        fibre-cement-and-accessories: concept://placemakers/building-products/fibre-cement-and-accessories
        insulation: concept://placemakers/building-products/insulation
        masonry: concept://placemakers/building-products/masonry
        panels: concept://placemakers/building-products/panels
        passive-fire: concept://placemakers/building-products/passive-fire
        plasterboard: concept://placemakers/building-products/plasterboard
        plasterboard-compounds-and-accessories: concept://placemakers/building-products/plasterboard-compounds-and-accessories
        reinforcing: concept://placemakers/building-products/reinforcing
        roofing: concept://placemakers/building-products/roofing
        steel-framing: concept://placemakers/building-products/steel-framing
        structural-flooring: concept://placemakers/building-products/structural-flooring
        wet-wall-linings: concept://placemakers/building-products/wet-wall-linings
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-2d9ecd66eeda
    - src-doc-951379169c64
    - src-doc-32119c2af64f
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Building Products
          path:
            - Building Products
          products: 1977
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Building Products
  requiredFacts:
    - factKey: nav_building_products
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - building product
    - cements
    - sheet
    - sheets
    - tape
    - tapes
  tenantId: placemakers
  type: department
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - building product
  - cements
  - sheet
  - sheets
  - tape
  - tapes
---
# Building Products

Building Products: 1,977 products across 17 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
