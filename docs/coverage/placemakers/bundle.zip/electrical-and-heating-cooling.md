---
description: 'Electrical & Heating/Cooling: 1,130 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Electrical & Heating/Cooling
type: department
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling
      - concept://placemakers/electrical-and-heating-cooling/electrical
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_electrical_and_heating_cooling
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/electrical-and-heating-cooling
  contentHash: 1d14f3c85885249bdac28eec73198e75388fb0dfc4e4aaa3aff7e2d861def847
  customerPhrases:
    - bathroom heat lamp
  description: 'Electrical & Heating/Cooling: 1,130 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_electrical_and_heating_cooling
      questionRef: q.nav_electrical_and_heating_cooling
      valueMap:
        electrical: concept://placemakers/electrical-and-heating-cooling/electrical
        heating-ventilation-and-cooling: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-7a3580a31b1d
    - src-doc-7bf6465b5c47
    - src-doc-99db5ac5deae
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Electrical & Heating/Cooling
          path:
            - Electrical & Heating/Cooling
          products: 1130
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Electrical & Heating/Cooling
  requiredFacts:
    - factKey: nav_electrical_and_heating_cooling
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Electrical & Heating/Cooling
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - cooling
    - coolings
    - electricals
    - heating
    - heatings
  tenantId: placemakers
  type: department
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - cooling
  - coolings
  - electricals
  - heating
  - heatings
---
# Electrical & Heating/Cooling

Electrical & Heating/Cooling: 1,130 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
