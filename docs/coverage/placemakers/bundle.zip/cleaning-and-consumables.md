---
description: 'Cleaning & Consumables: 262 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Cleaning & Consumables
type: department
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment
      - concept://placemakers/cleaning-and-consumables/automotive
      - concept://placemakers/cleaning-and-consumables/household-and-pets
      - concept://placemakers/cleaning-and-consumables/site-consumables
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_cleaning_and_consumables
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cleaning-and-consumables
  contentHash: bb9eee40a095e04e109bf54485ef42420aafa773d2f6f2173149fc79319ab560
  customerPhrases:
    - extendable wash brush
    - replacement broom handle
    - soft bristle wash brush
    - soap chamber brush
  description: 'Cleaning & Consumables: 262 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_cleaning_and_consumables
      questionRef: q.nav_cleaning_and_consumables
      valueMap:
        automotive: concept://placemakers/cleaning-and-consumables/automotive
        cleaners-and-cleaning-equipment: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment
        household-and-pets: concept://placemakers/cleaning-and-consumables/household-and-pets
        site-consumables: concept://placemakers/cleaning-and-consumables/site-consumables
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-5227deb9031d
    - src-doc-f87dc1483360
    - src-doc-6d28cb493414
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Cleaning & Consumables
          path:
            - Cleaning & Consumables
          products: 262
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Cleaning & Consumables
  requiredFacts:
    - factKey: nav_cleaning_and_consumables
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cleaning & Consumables
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - cleaning
    - cleanings
    - consumable
    - consumables
  tenantId: placemakers
  type: department
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - cleaning
  - cleanings
  - consumable
  - consumables
---
# Cleaning & Consumables

Cleaning & Consumables: 262 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
