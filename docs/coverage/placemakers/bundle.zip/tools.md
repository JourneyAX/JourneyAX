---
description: 'Tools: 8,089 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Tools
type: department
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/tools/power-tool-accessories
      - concept://placemakers/tools/hand-tools
      - concept://placemakers/tools/power-tools
      - concept://placemakers/tools/outdoor-power-equipment
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_tools
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/tools
  contentHash: 5f7cba4ed7692f3ce53980bdbdbd59e3967e5be720fb50a42861a6bcc16533f8
  customerPhrases:
    - bit set
    - square recess bits
    - impact rated bits
    - impact sockets
    - deep sockets
    - metric socket set
    - sae socket set
    - 6 point sockets
  description: 'Tools: 8,089 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_tools
      questionRef: q.nav_tools
      valueMap:
        hand-tools: concept://placemakers/tools/hand-tools
        outdoor-power-equipment: concept://placemakers/tools/outdoor-power-equipment
        power-tool-accessories: concept://placemakers/tools/power-tool-accessories
        power-tools: concept://placemakers/tools/power-tools
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-e5979ddb6b1f
    - src-doc-c720b18a8555
    - src-doc-6a1b6571f3f8
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Tools
          path:
            - Tools
          products: 8089
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Tools
  requiredFacts:
    - factKey: nav_tools
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Tools
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - blade
    - blades
    - caulking guns
    - concrete
    - concretes
    - dust extraction
    - dust extractions
    - extraction
    - extractions
    - gun
    - guns
    - planer
    - saw
    - screwdriver
    - tool
    - trimmer
    - trimmers
    - vacuum
    - vacuums
    - weldings
  tenantId: placemakers
  type: department
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - blade
  - blades
  - caulking guns
  - concrete
  - concretes
  - dust extraction
  - dust extractions
  - extraction
  - extractions
  - gun
  - guns
  - planer
  - saw
  - screwdriver
  - tool
  - trimmer
  - trimmers
  - vacuum
  - vacuums
  - weldings
---
# Tools

Tools: 8,089 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
