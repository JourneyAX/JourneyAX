---
description: Cleaning products and equipment grouped by task, without assuming chemical suitability for a surface.
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Cleaning supplies
type: product family
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/indoor-cleaners
      - concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/outdoor-cleaners
      - concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/mops-and-brooms
      - concept://placemakers/cleaning-and-consumables/automotive/car-cleaning
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.cleaning_task
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/families/cleaning-supplies
  contentHash: 0e8cb70357f63048adea7fc29ef233a160fe14c0c24964bb56fad21f4ec9f2c5
  customerPhrases:
    - i need cleaning supplies
    - show me cleaning supplies
    - something to clean with
    - i need some cleaning gear
  description: Cleaning products and equipment grouped by task, without assuming chemical suitability for a surface.
  discriminators:
    - clarifyFirst: false
      factKey: cleaning_task
      questionRef: q.cleaning_task
      valueMap:
        car: concept://placemakers/cleaning-and-consumables/automotive/car-cleaning
        equipment: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/mops-and-brooms
        household: concept://placemakers/cleaning-and-consumables/household-and-pets/household
        indoor: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/indoor-cleaners
        outdoor: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/outdoor-cleaners
  evidenceRefs:
    - src-authoring-proposal
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          id: cleaning-supplies
          section: families
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Cleaning supplies
  requiredFacts:
    - factKey: cleaning_task
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cleaning & Consumables
        - Cleaners & Cleaning Equipment
        - Indoor Cleaners
      - - Cleaning & Consumables
        - Cleaners & Cleaning Equipment
        - Outdoor Cleaners
      - - Cleaning & Consumables
        - Cleaners & Cleaning Equipment
        - Mops & Brooms
      - - Cleaning & Consumables
        - Automotive
        - Car Cleaning
      - - Cleaning & Consumables
        - Household & Pets
        - Household
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - cleaning products
    - cleaning equipment
    - cleaning supply
    - cleaning stuff
    - cleaning gear
    - cleaning materials
  tenantId: placemakers
  type: product_family
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - cleaning products
  - cleaning equipment
  - cleaning supply
  - cleaning stuff
  - cleaning gear
  - cleaning materials
---
# Cleaning supplies

Cleaning products and equipment grouped by task, without assuming chemical suitability for a surface.
