# families

* [Cleaning supplies](cleaning-supplies.md) - Cleaning products and equipment grouped by task, without assuming chemical suitability for a surface.
* [Nails](nails.md) - Hand-driven and gun-driven nails.
* [Screws](screws.md) - Screws and fixings, grouped by what they are fixed into.
