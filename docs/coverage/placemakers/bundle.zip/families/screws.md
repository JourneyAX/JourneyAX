---
description: Screws and fixings, grouped by what they are fixed into.
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Screws
type: product family
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/fastenings-and-general-hardware/fastenings/wood-screws
      - concept://placemakers/fastenings-and-general-hardware/fastenings/metal-screws
      - concept://placemakers/fastenings-and-general-hardware/fastenings/masonry-anchors
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.fastener_substrate
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: true
  conceptId: concept://placemakers/families/screws
  contentHash: a2a032feb6cf7b1b301aa967ab59f87fe9fc020455b4e2ac0c2cb24debcb2d1d
  customerPhrases:
    - what screws do i need
    - fixing screws
  description: Screws and fixings, grouped by what they are fixed into.
  discriminators:
    - clarifyFirst: false
      factKey: fastener_substrate
      questionRef: q.fastener_substrate
      valueMap:
        masonry: concept://placemakers/fastenings-and-general-hardware/fastenings/masonry-anchors
        metal: concept://placemakers/fastenings-and-general-hardware/fastenings/metal-screws
        timber: concept://placemakers/fastenings-and-general-hardware/fastenings/wood-screws
  evidenceRefs:
    - src-authoring-proposal
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          id: screws
          section: families
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Screws
  requiredFacts:
    - factKey: fastener_substrate
      importance: medium
  riskClass: compatibility
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Fastenings & General Hardware
        - Fastenings
        - Wood Screws
      - - Fastenings & General Hardware
        - Fastenings
        - Metal Screws
      - - Fastenings & General Hardware
        - Fastenings
        - Masonry  Anchors
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - screw
  tenantId: placemakers
  type: product_family
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - screw
---
# Screws

Screws and fixings, grouped by what they are fixed into.
