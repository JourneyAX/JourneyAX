---
description: Hand-driven and gun-driven nails.
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Nails
type: product family
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/fastenings-and-general-hardware/fastenings/collated-nails
      - concept://placemakers/fastenings-and-general-hardware/fastenings/loose-nails
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_family_nails
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/families/nails
  contentHash: 3e2961abe0a7c9a4e7939487ee5e4b7f8900aa8639399592a35cdd75972302f7
  customerPhrases:
    - nails for my nail gun
  description: Hand-driven and gun-driven nails.
  discriminators:
    - clarifyFirst: false
      factKey: nav_family_nails
      questionRef: q.nav_family_nails
      valueMap:
        collated-nails: concept://placemakers/fastenings-and-general-hardware/fastenings/collated-nails
        loose-nails: concept://placemakers/fastenings-and-general-hardware/fastenings/loose-nails
  evidenceRefs:
    - src-authoring-proposal
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          id: nails
          section: families
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Nails
  requiredFacts:
    - factKey: nav_family_nails
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Fastenings & General Hardware
        - Fastenings
        - Collated Nails
      - - Fastenings & General Hardware
        - Fastenings
        - Loose Nails
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - nail
  tenantId: placemakers
  type: product_family
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - nail
---
# Nails

Hand-driven and gun-driven nails.
