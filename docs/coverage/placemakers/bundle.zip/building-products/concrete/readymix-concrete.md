---
description: 'Readymix Concrete: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Readymix Concrete
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/concrete/readymix-concrete
  contentHash: fe664bf9147271b2cfee6762c64816139017a1e8312669d845b440b68ec6f529
  customerPhrases:
    - flowable grout
    - shrinkage compensated grout
    - pre mixed grout
    - high early strength grout
    - ready to use grout
    - construction grout 25 kg
    - machineable grout
    - structural grout
    - ready mix
    - ready mix concrete
    - readymix
    - ready mixed concrete
  description: 'Readymix Concrete: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-020c65a5aa55
  extensions:
    x-journeyax-provenance:
      alias_ready_mix:
        detail:
          alias: ready_mix
          reason: Ready mix is written as two words as often as one.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:07:03.628Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Readymix Concrete
          path:
            - Building Products
            - Concrete
            - Readymix Concrete
          products: 1
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Readymix Concrete
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Concrete
        - Readymix Concrete
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - readymix concretes
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 686047691893d8a52d2a303b25553f15f64e7c494b44b6438968115e54da55ff
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/concrete/readymix-concrete
    relationshipId: rel-building-products--concrete--readymix-concrete-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/concrete
    type: child_of
x-journeyax-synonyms:
  - readymix concretes
---
# Readymix Concrete

Readymix Concrete: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Concrete (Building Products)](../concrete.md)
