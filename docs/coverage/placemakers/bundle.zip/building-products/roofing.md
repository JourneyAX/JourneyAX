---
description: 'Roofing: 111 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Roofing
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/building-products/roofing/roof-windows
      - concept://placemakers/building-products/roofing/longrun
      - concept://placemakers/building-products/roofing/passive-ventilation
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_building_products_roofing
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/roofing
  contentHash: dab7ff3e40f0c41955dc80ea8ad8fbe503934abc8e0905999b017d3e7dd9037d
  customerPhrases:
    - roofing iron
    - corrugated iron
    - corrugate
    - colorsteel
    - coloursteel
    - iron roofing
    - roofing sheets
  description: 'Roofing: 111 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_building_products_roofing
      questionRef: q.nav_building_products_roofing
      valueMap:
        longrun: concept://placemakers/building-products/roofing/longrun
        passive-ventilation: concept://placemakers/building-products/roofing/passive-ventilation
        roof-windows: concept://placemakers/building-products/roofing/roof-windows
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-4e0f477f7a93
    - src-doc-7cf0ca283816
    - src-doc-327669d57739
  extensions:
    x-journeyax-provenance:
      alias_roofing_iron:
        detail:
          alias: roofing_iron
          reason: Roofing iron, corrugate and Colorsteel are the everyday words for metal roofing.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Roofing
          path:
            - Building Products
            - Roofing
          products: 111
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Roofing
  requiredFacts:
    - factKey: nav_building_products_roofing
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Roofing
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 791cf0bc13de3e26b952b5e2f5393560c70ea34db0eb296e71f76b42c7046e18
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/roofing
    relationshipId: rel-building-products--roofing-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products
    type: child_of
---
# Roofing

Roofing: 111 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Products](../building-products.md)
