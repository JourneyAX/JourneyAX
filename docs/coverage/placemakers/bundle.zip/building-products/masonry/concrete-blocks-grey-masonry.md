---
description: 'Concrete Blocks - Grey Masonry: 32 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Concrete Blocks - Grey Masonry
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/masonry/concrete-blocks-grey-masonry
  contentHash: 756a9920e6d86c33b7eab7dafc4a75c6d5967309b82e2b2f483ec0e8f25fda82
  customerPhrases:
    - concrete breeze block
    - concrete masonry block
    - 390 x 90 x 190 block
    - capping block
    - hollow block
    - 390 x 90 x 90 block
    - coping block
    - cinder block
  description: 'Concrete Blocks - Grey Masonry: 32 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-80b9fc1db76b
    - src-doc-976955835eb0
    - src-doc-9fb12ee04f83
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:02:23.740Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Concrete Blocks - Grey Masonry
          path:
            - Building Products
            - Masonry
            - Concrete Blocks - Grey Masonry
          products: 32
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Concrete Blocks - Grey Masonry
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Masonry
        - Concrete Blocks - Grey Masonry
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - concrete blocks grey masonries
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 68c271bb11f313f8c0efd9454fe6e60fc27e55df731dcdfa73a5be8f862a4cb6
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/masonry/concrete-blocks-grey-masonry
    relationshipId: rel-building-products--masonry--concrete-blocks-grey-masonry-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/masonry
    type: child_of
x-journeyax-synonyms:
  - concrete blocks grey masonries
---
# Concrete Blocks - Grey Masonry

Concrete Blocks - Grey Masonry: 32 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Masonry](../masonry.md)
