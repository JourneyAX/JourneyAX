---
description: 'Bricks & Stone: 8 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Bricks & Stone
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/masonry/bricks-and-stone
  contentHash: 49e21903688c8efb278df4d0b03f8098608716c86d264c37eb9273198510be49
  customerPhrases:
    - bricks 230x76
    - modular brick
    - facing brick
    - clay face brick
    - external brick veneer
    - solid clay brick
    - white cream grey bricks
    - standard size bricks
  description: 'Bricks & Stone: 8 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:04:10.402Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Bricks & Stone
          path:
            - Building Products
            - Masonry
            - Bricks & Stone
          products: 8
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Bricks & Stone
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Masonry
        - Bricks & Stone
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - brick
    - bricks
    - stone
    - stones
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 3c1f7a128b5d357d5f265afa1d4e4a3a71e370f34a30cf9856cee422b3113c22
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/masonry/bricks-and-stone
    relationshipId: rel-building-products--masonry--bricks-and-stone-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/masonry
    type: child_of
x-journeyax-synonyms:
  - brick
  - bricks
  - stone
  - stones
---
# Bricks & Stone

Bricks & Stone: 8 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Masonry](../masonry.md)
