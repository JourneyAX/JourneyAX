# building-products/insulation

* [Fibreglass](fibreglass.md) - Fibreglass: 58 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Other Insulation](other-insulation.md) - Other Insulation: 130 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Polyester](polyester.md) - Polyester: 94 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Polystyrene](polystyrene.md) - Polystyrene: 168 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Wool](wool.md) - Wool: 17 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
