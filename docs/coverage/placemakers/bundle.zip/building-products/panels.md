---
description: 'Panels: 241 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Panels (Building Products)
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/building-products/panels/mdf
      - concept://placemakers/building-products/panels/veneer-pre-cut-panels
      - concept://placemakers/building-products/panels/other-pre-cut-panels
      - concept://placemakers/building-products/panels/melamine
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_building_products_panels
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/panels
  contentHash: 9c5160dd21866927dd857cc129a53161d7bf20bb87c6188f8cb51bdfb8d0db5a
  customerPhrases:
    - shelving board
    - mr particleboard
    - soundproofing board
    - mdf alternative
  description: 'Panels: 241 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_building_products_panels
      questionRef: q.nav_building_products_panels
      valueMap:
        hardboard-and-hessian-full-sheets: concept://placemakers/building-products/panels/hardboard-and-hessian-full-sheets
        mdf: concept://placemakers/building-products/panels/mdf
        medium-density-particle-board: concept://placemakers/building-products/panels/medium-density-particle-board
        melamine: concept://placemakers/building-products/panels/melamine
        other-panels: concept://placemakers/building-products/panels/other-panels
        other-pre-cut-panels: concept://placemakers/building-products/panels/other-pre-cut-panels
        strandboard: concept://placemakers/building-products/panels/strandboard
        veneer-pre-cut-panels: concept://placemakers/building-products/panels/veneer-pre-cut-panels
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-2d9ecd66eeda
    - src-doc-81870cf59096
    - src-doc-be82c6a1d93b
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Panels
          path:
            - Building Products
            - Panels
          products: 241
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Panels (Building Products)
  requiredFacts:
    - factKey: nav_building_products_panels
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Panels
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 4c8a9927237cc6fb5ce39cf82a961bc3360f6045b114d37e988ba859cef8677a
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/panels
    relationshipId: rel-building-products--panels-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products
    type: child_of
---
# Panels (Building Products)

Panels: 241 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Products](../building-products.md)
