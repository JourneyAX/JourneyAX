---
description: 'Structural Flooring: 4 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Structural Flooring
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/building-products/structural-flooring/strandboard-floor-sheets
      - concept://placemakers/building-products/structural-flooring/particle-board-floor-sheets
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_building_products_structural_flooring
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/structural-flooring
  contentHash: 7e5c4fe1e58267eafb9137a4bff8bac8cbc6563f6d0ca98edb980c2c76f0830a
  customerPhrases: []
  description: 'Structural Flooring: 4 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_building_products_structural_flooring
      questionRef: q.nav_building_products_structural_flooring
      valueMap:
        particle-board-floor-sheets: concept://placemakers/building-products/structural-flooring/particle-board-floor-sheets
        strandboard-floor-sheets: concept://placemakers/building-products/structural-flooring/strandboard-floor-sheets
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Structural Flooring
          path:
            - Building Products
            - Structural Flooring
          products: 4
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Structural Flooring
  requiredFacts:
    - factKey: nav_building_products_structural_flooring
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Structural Flooring
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - structural floorings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 7dfdeb0419ba10ddc74ac446b649b8ea1993d385bd9549c6e2ded9378e6b81dd
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/structural-flooring
    relationshipId: rel-building-products--structural-flooring-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products
    type: child_of
x-journeyax-synonyms:
  - structural floorings
---
# Structural Flooring

Structural Flooring: 4 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Products](../building-products.md)
