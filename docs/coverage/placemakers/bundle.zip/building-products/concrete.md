---
description: 'Concrete: 5 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Concrete (Building Products)
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/building-products/concrete/formwork
      - concept://placemakers/building-products/concrete/concrete-flooring-systems
      - concept://placemakers/building-products/concrete/readymix-concrete
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_building_products_concrete
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/concrete
  contentHash: 5168e839f748acf7ffc2995af131a34bb4cfc77bc7f27f8d7bdaf68adfb5debf
  customerPhrases: []
  description: 'Concrete: 5 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_building_products_concrete
      questionRef: q.nav_building_products_concrete
      valueMap:
        concrete-flooring-systems: concept://placemakers/building-products/concrete/concrete-flooring-systems
        formwork: concept://placemakers/building-products/concrete/formwork
        readymix-concrete: concept://placemakers/building-products/concrete/readymix-concrete
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-020c65a5aa55
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Concrete
          path:
            - Building Products
            - Concrete
          products: 5
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Concrete (Building Products)
  requiredFacts:
    - factKey: nav_building_products_concrete
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Concrete
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: db62b9aea44161a9e940680c2000a274ea4a49754eab2092de5c1d7e5f00edb2
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/concrete
    relationshipId: rel-building-products--concrete-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products
    type: child_of
---
# Concrete (Building Products)

Concrete: 5 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Products](../building-products.md)
