---
description: 'Building Wraps,Barriers,Underlay & Tapes: 259 products across 11 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Building Wraps,Barriers,Underlay & Tapes
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/flashing-and-sealing-tapes
      - concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/accessories
      - concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/building-papers-wraps-and-barriers
      - concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/damp-proof-course-dpc
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_building_products_building_wraps_barriers_underlay_and_tapes
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes
  contentHash: a8f5468202e48b695a580620e6247232ba535867c41c87d2ed332b945d23d447
  customerPhrases:
    - breathable wall wrap
    - wall underlay
    - heavy duty underlay
  description: 'Building Wraps,Barriers,Underlay & Tapes: 259 products across 11 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_building_products_building_wraps_barriers_underlay_and_tapes
      questionRef: q.nav_building_products_building_wraps_barriers_underlay_and_tapes
      valueMap:
        accessories: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/accessories
        building-papers-wraps-and-barriers: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/building-papers-wraps-and-barriers
        building-wraps-accessories: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/building-wraps-accessories
        concrete-underlays: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/concrete-underlays
        damp-proof-course-dpc: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/damp-proof-course-dpc
        flashing-and-sealing-tapes: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/flashing-and-sealing-tapes
        flexible-air-barriers: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/flexible-air-barriers
        foils: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/foils
        moisture-control: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/moisture-control
        rigid-air-barriers: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/rigid-air-barriers
        roof-underlays: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/roof-underlays
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-2ef26b49d67f
    - src-doc-8ce1aff659ee
    - src-doc-d074cba0b428
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Building Wraps,Barriers,Underlay & Tapes
          path:
            - Building Products
            - Building Wraps,Barriers,Underlay & Tapes
          products: 259
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Building Wraps,Barriers,Underlay & Tapes
  requiredFacts:
    - factKey: nav_building_products_building_wraps_barriers_underlay_and_tapes
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Building Wraps,Barriers,Underlay & Tapes
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - barrier
    - barriers
    - building wrap
    - building wraps
    - underlays
    - wrap
    - wraps
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 37ac50a1e0b68cebda3c4ef9b9a6f175d951e601d91b1c9571df9e49ebb1f1f1
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes
    relationshipId: rel-building-products--building-wraps-barriers-underlay-and-tapes-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products
    type: child_of
x-journeyax-synonyms:
  - barrier
  - barriers
  - building wrap
  - building wraps
  - underlays
  - wrap
  - wraps
---
# Building Wraps,Barriers,Underlay & Tapes

Building Wraps,Barriers,Underlay & Tapes: 259 products across 11 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Products](../building-products.md)
