---
description: 'Concrete & Mortars: 76 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Concrete & Mortars
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/building-products/concrete-and-mortars/concrete-additives
      - concept://placemakers/building-products/concrete-and-mortars/bagged-mortars
      - concept://placemakers/building-products/concrete-and-mortars/bagged-concrete
      - concept://placemakers/building-products/concrete-and-mortars/cement
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_building_products_concrete_and_mortars
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/concrete-and-mortars
  contentHash: a53b2b6cb5303e87d286eca8030fb6c19a3af0aa211b25fe5b2279f22b471141
  customerPhrases: []
  description: 'Concrete & Mortars: 76 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_building_products_concrete_and_mortars
      questionRef: q.nav_building_products_concrete_and_mortars
      valueMap:
        bagged-concrete: concept://placemakers/building-products/concrete-and-mortars/bagged-concrete
        bagged-mortars: concept://placemakers/building-products/concrete-and-mortars/bagged-mortars
        cement: concept://placemakers/building-products/concrete-and-mortars/cement
        concrete-additives: concept://placemakers/building-products/concrete-and-mortars/concrete-additives
        lime: concept://placemakers/building-products/concrete-and-mortars/lime
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-af25cb68342c
    - src-doc-0482068b605d
    - src-doc-218b7c9b3316
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Concrete & Mortars
          path:
            - Building Products
            - Concrete & Mortars
          products: 76
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Concrete & Mortars
  requiredFacts:
    - factKey: nav_building_products_concrete_and_mortars
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Concrete & Mortars
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - mortar
    - mortars
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 98d500001397e4e9572535c7837c5f0c1b2992d260be7ce1507b3cc6bbab3290
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/concrete-and-mortars
    relationshipId: rel-building-products--concrete-and-mortars-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products
    type: child_of
x-journeyax-synonyms:
  - mortar
  - mortars
---
# Concrete & Mortars

Concrete & Mortars: 76 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Products](../building-products.md)
