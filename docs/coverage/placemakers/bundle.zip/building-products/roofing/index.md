# building-products/roofing

* [Longrun](longrun.md) - Longrun: 41 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Passive Ventilation](passive-ventilation.md) - Passive Ventilation: 6 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Roof Windows](roof-windows.md) - Roof Windows: 64 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
