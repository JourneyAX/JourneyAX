---
description: 'Specialist Board: 65 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Specialist Board
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/plasterboard/specialist-board
  contentHash: 093f08e86a4372e2624560c3bae5c7d2f38d4455beadc30d709676c78cd92f07
  customerPhrases:
    - fireboard
    - waterproof plasterboard
    - soundproof plasterboard
    - ultra smooth gib board
    - impact resistant plasterboard
    - gyprock sheets
    - radiation shielding plasterboard
  description: 'Specialist Board: 65 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:02:38.885Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Specialist Board
          path:
            - Building Products
            - Plasterboard
            - Specialist Board
          products: 65
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Specialist Board
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Plasterboard
        - Specialist Board
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - specialist boards
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 507b643f24c5df42945ee4f513113dc2f874b4aabd08c0cc8d04d5271885f09b
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/plasterboard/specialist-board
    relationshipId: rel-building-products--plasterboard--specialist-board-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/plasterboard
    type: child_of
x-journeyax-synonyms:
  - specialist boards
---
# Specialist Board

Specialist Board: 65 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Plasterboard](../plasterboard.md)
