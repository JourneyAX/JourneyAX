# building-products/plasterboard

* [Specialist Board](specialist-board.md) - Specialist Board: 65 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Standard Board](standard-board.md) - Standard Board: 15 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
