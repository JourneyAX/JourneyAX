# building-products/reinforcing

* [Reinforcing (Reinforcing)](reinforcing.md) - Reinforcing: 33 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Reinforcing Accessories](reinforcing-accessories.md) - Reinforcing Accessories: 50 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
