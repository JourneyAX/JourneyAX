---
description: 'Masonry: 40 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Masonry
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/building-products/masonry/concrete-blocks-grey-masonry
      - concept://placemakers/building-products/masonry/bricks-and-stone
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_building_products_masonry
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/masonry
  contentHash: ee409916d17854972272d9a70b18b95086c91459f102c7a40d6445d06dd0d5b5
  customerPhrases: []
  description: 'Masonry: 40 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_building_products_masonry
      questionRef: q.nav_building_products_masonry
      valueMap:
        bricks-and-stone: concept://placemakers/building-products/masonry/bricks-and-stone
        concrete-blocks-grey-masonry: concept://placemakers/building-products/masonry/concrete-blocks-grey-masonry
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-80b9fc1db76b
    - src-doc-976955835eb0
    - src-doc-9fb12ee04f83
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Masonry
          path:
            - Building Products
            - Masonry
          products: 40
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Masonry
  requiredFacts:
    - factKey: nav_building_products_masonry
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Masonry
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - masonries
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 0be63abfe264c41e78f464c31bbbf3a559a77117d622cba1ab2d9e619ac87469
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/masonry
    relationshipId: rel-building-products--masonry-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products
    type: child_of
x-journeyax-synonyms:
  - masonries
---
# Masonry

Masonry: 40 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Products](../building-products.md)
