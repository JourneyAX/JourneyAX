---
description: 'Reinforcing: 87 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Reinforcing (Building Products)
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/building-products/reinforcing/reinforcing-accessories
      - concept://placemakers/building-products/reinforcing/reinforcing
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_building_products_reinforcing
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/reinforcing
  contentHash: afcdfeaba143473286b8c17d91a136cd4119f82d62ba74416e38aabe5db5b62a
  customerPhrases: []
  description: 'Reinforcing: 87 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_building_products_reinforcing
      questionRef: q.nav_building_products_reinforcing
      valueMap:
        reinforcing: concept://placemakers/building-products/reinforcing/reinforcing
        reinforcing-accessories: concept://placemakers/building-products/reinforcing/reinforcing-accessories
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-25b036030642
    - src-doc-23e26665a711
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Reinforcing
          path:
            - Building Products
            - Reinforcing
          products: 87
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Reinforcing (Building Products)
  requiredFacts:
    - factKey: nav_building_products_reinforcing
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Reinforcing
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - reinforcing
    - reinforcings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 57d587883622f209d9b8d26f01600e589707ee47c1e6f6c81fb21dc4daa2492c
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/reinforcing
    relationshipId: rel-building-products--reinforcing-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products
    type: child_of
x-journeyax-synonyms:
  - reinforcing
  - reinforcings
---
# Reinforcing (Building Products)

Reinforcing: 87 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Products](../building-products.md)
