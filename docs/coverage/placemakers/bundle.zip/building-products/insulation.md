---
description: 'Insulation: 467 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Insulation
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/building-products/insulation/polystyrene
      - concept://placemakers/building-products/insulation/other-insulation
      - concept://placemakers/building-products/insulation/polyester
      - concept://placemakers/building-products/insulation/fibreglass
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_building_products_insulation
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/insulation
  contentHash: 5d481a00b467c42154554a6cf31c1e254713683bd6a4088bbed16c3a5f5b95f0
  customerPhrases:
    - rigid foam insulation
    - high r value board
    - underfloor batts
    - wall batts
    - ceiling batts
    - suspended floor insulation
    - friction fit insulation
    - ceiling blanket
    - pink batts
    - batts
    - insulation batts
  description: 'Insulation: 467 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_building_products_insulation
      questionRef: q.nav_building_products_insulation
      valueMap:
        fibreglass: concept://placemakers/building-products/insulation/fibreglass
        other-insulation: concept://placemakers/building-products/insulation/other-insulation
        polyester: concept://placemakers/building-products/insulation/polyester
        polystyrene: concept://placemakers/building-products/insulation/polystyrene
        wool: concept://placemakers/building-products/insulation/wool
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-32119c2af64f
    - src-doc-0ede268cc1f8
    - src-doc-d3dee270db1e
  extensions:
    x-journeyax-provenance:
      alias_pink_batts:
        detail:
          alias: pink_batts
          reason: Customers ask for insulation by brand and by the batt.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Insulation
          path:
            - Building Products
            - Insulation
          products: 467
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Insulation
  requiredFacts:
    - factKey: nav_building_products_insulation
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Insulation
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - insulations
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: d6524544fee0c5c2e978de00eedaf4453d3b9774844513bcc5f00211f5161d2d
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/insulation
    relationshipId: rel-building-products--insulation-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products
    type: child_of
x-journeyax-synonyms:
  - insulations
---
# Insulation

Insulation: 467 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Products](../building-products.md)
