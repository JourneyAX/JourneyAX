---
description: 'Plasterboard Compounds & Accessories: 101 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Plasterboard Compounds & Accessories
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/building-products/plasterboard-compounds-and-accessories/compounds-and-plasters
      - concept://placemakers/building-products/plasterboard-compounds-and-accessories/trims-and-moulds
      - concept://placemakers/building-products/plasterboard-compounds-and-accessories/drywall-tapes
      - concept://placemakers/building-products/plasterboard-compounds-and-accessories/plasterboard-accessories
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_building_products_plasterboard_compounds_and_accessories
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/plasterboard-compounds-and-accessories
  contentHash: 873001e70caf3bbc907201c618c2594cf4c6b5a188c1dac7f657d85fdb737082
  customerPhrases: []
  description: 'Plasterboard Compounds & Accessories: 101 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_building_products_plasterboard_compounds_and_accessories
      questionRef: q.nav_building_products_plasterboard_compounds_and_accessories
      valueMap:
        compounds-and-plasters: concept://placemakers/building-products/plasterboard-compounds-and-accessories/compounds-and-plasters
        drywall-tapes: concept://placemakers/building-products/plasterboard-compounds-and-accessories/drywall-tapes
        plasterboard-accessories: concept://placemakers/building-products/plasterboard-compounds-and-accessories/plasterboard-accessories
        trims-and-moulds: concept://placemakers/building-products/plasterboard-compounds-and-accessories/trims-and-moulds
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-3ddbdabef485
    - src-doc-d6d14594aeed
    - src-doc-066f992ad496
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Plasterboard Compounds & Accessories
          path:
            - Building Products
            - Plasterboard Compounds & Accessories
          products: 101
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Plasterboard Compounds & Accessories
  requiredFacts:
    - factKey: nav_building_products_plasterboard_compounds_and_accessories
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Plasterboard Compounds & Accessories
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - compound
    - compounds
    - plasterboard compounds
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: c7553c91a7d34482d31e1fd158d2158f41968a43615037e47e18ba33b3429e7e
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/plasterboard-compounds-and-accessories
    relationshipId: rel-building-products--plasterboard-compounds-and-accessories-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products
    type: child_of
x-journeyax-synonyms:
  - compound
  - compounds
  - plasterboard compounds
---
# Plasterboard Compounds & Accessories

Plasterboard Compounds & Accessories: 101 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Products](../building-products.md)
