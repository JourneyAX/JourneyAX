# building-products/aggregates

* [Bagged](bagged.md) - Bagged: 25 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Bulk](bulk.md) - Bulk: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
