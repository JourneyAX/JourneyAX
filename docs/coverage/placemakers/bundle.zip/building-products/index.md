# building-products

* [Aggregates](aggregates.md) - Aggregates: 27 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Building Wraps,Barriers,Underlay & Tapes](building-wraps-barriers-underlay-and-tapes.md) - Building Wraps,Barriers,Underlay & Tapes: 259 products across 11 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Ceilings](ceilings.md) - Ceilings: 21 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Concrete & Mortars](concrete-and-mortars.md) - Concrete & Mortars: 76 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Concrete (Building Products)](concrete.md) - Concrete: 5 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Fibre Cement & Accessories (Building Products)](fibre-cement-and-accessories.md) - Fibre Cement & Accessories: 206 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Insulation](insulation.md) - Insulation: 467 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Masonry](masonry.md) - Masonry: 40 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Panels (Building Products)](panels.md) - Panels: 241 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Passive Fire](passive-fire.md) - Passive Fire: 1 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Plasterboard Compounds & Accessories](plasterboard-compounds-and-accessories.md) - Plasterboard Compounds & Accessories: 101 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Plasterboard](plasterboard.md) - Plasterboard: 80 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Reinforcing (Building Products)](reinforcing.md) - Reinforcing: 87 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Roofing](roofing.md) - Roofing: 111 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Steel Framing (Building Products)](steel-framing.md) - Steel Framing: 9 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Structural Flooring](structural-flooring.md) - Structural Flooring: 4 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Wet Wall Linings](wet-wall-linings.md) - Wet Wall Linings: 242 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [aggregates](aggregates/) - Knowledge and references
* [building-wraps-barriers-underlay-and-tapes](building-wraps-barriers-underlay-and-tapes/) - Knowledge and references
* [ceilings](ceilings/) - Knowledge and references
* [concrete-and-mortars](concrete-and-mortars/) - Knowledge and references
* [concrete](concrete/) - Knowledge and references
* [fibre-cement-and-accessories](fibre-cement-and-accessories/) - Knowledge and references
* [insulation](insulation/) - Knowledge and references
* [masonry](masonry/) - Knowledge and references
* [panels](panels/) - Knowledge and references
* [passive-fire](passive-fire/) - Knowledge and references
* [plasterboard-compounds-and-accessories](plasterboard-compounds-and-accessories/) - Knowledge and references
* [plasterboard](plasterboard/) - Knowledge and references
* [reinforcing](reinforcing/) - Knowledge and references
* [roofing](roofing/) - Knowledge and references
* [steel-framing](steel-framing/) - Knowledge and references
* [structural-flooring](structural-flooring/) - Knowledge and references
* [wet-wall-linings](wet-wall-linings/) - Knowledge and references
