---
description: 'Particle Board Floor Sheets: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Particle Board Floor Sheets
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/structural-flooring/particle-board-floor-sheets
  contentHash: 2cdbea8340281281c5c317e6487810fcc0801c0dc0771c33eae6f3b32f7d3ef3
  customerPhrases:
    - chipboard flooring
    - flooring panels
    - prelaid flooring
    - postlaid flooring
    - timber joist flooring
    - engineered joist board
    - structural chipboard
    - flooring underlay board
    - floor chipboard
    - tongue and groove flooring
    - t and g flooring
  description: 'Particle Board Floor Sheets: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_chipboard_flooring:
        detail:
          alias: chipboard_flooring
          reason: Customers ask for flooring by the tongue-and-groove sheet.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:07:51.749Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Particle Board Floor Sheets
          path:
            - Building Products
            - Structural Flooring
            - Particle Board Floor Sheets
          products: 1
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Particle Board Floor Sheets
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Structural Flooring
        - Particle Board Floor Sheets
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - particle board floor sheet
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 865bbcc91c5e80bdf15008c0e740c37700b29b77c42d6e91cf6cbcdf6b315f47
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/structural-flooring/particle-board-floor-sheets
    relationshipId: rel-building-products--structural-flooring--particle-board-floor-sheets-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/structural-flooring
    type: child_of
x-journeyax-synonyms:
  - particle board floor sheet
---
# Particle Board Floor Sheets

Particle Board Floor Sheets: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Structural Flooring](../structural-flooring.md)
