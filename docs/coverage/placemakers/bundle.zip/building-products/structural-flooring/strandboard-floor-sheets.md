---
description: 'Strandboard Floor Sheets: 3 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Strandboard Floor Sheets
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/structural-flooring/strandboard-floor-sheets
  contentHash: 69468c0c61fe840c329cc858fe54690812ea7b716a358bd625337ee49e940640
  customerPhrases:
    - osb flooring
    - oriented strand board
    - tongue and groove panels
    - t and g floorboards
    - radiata pine floor sheet
    - h3 1 treated flooring
    - 20mm floor sheets
    - flooring underlay sheet
  description: 'Strandboard Floor Sheets: 3 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:05:53.578Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Strandboard Floor Sheets
          path:
            - Building Products
            - Structural Flooring
            - Strandboard Floor Sheets
          products: 3
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Strandboard Floor Sheets
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Structural Flooring
        - Strandboard Floor Sheets
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - strandboard floor sheet
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 22408205b542aef4d1c0368c8be9e703b1a1a6efce9fe3fa444bb848ca2a0571
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/structural-flooring/strandboard-floor-sheets
    relationshipId: rel-building-products--structural-flooring--strandboard-floor-sheets-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/structural-flooring
    type: child_of
x-journeyax-synonyms:
  - strandboard floor sheet
---
# Strandboard Floor Sheets

Strandboard Floor Sheets: 3 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Structural Flooring](../structural-flooring.md)
