# building-products/structural-flooring

* [Particle Board Floor Sheets](particle-board-floor-sheets.md) - Particle Board Floor Sheets: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Strandboard Floor Sheets](strandboard-floor-sheets.md) - Strandboard Floor Sheets: 3 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
