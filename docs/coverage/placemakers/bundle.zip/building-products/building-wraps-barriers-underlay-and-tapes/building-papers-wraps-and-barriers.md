---
description: 'Building Papers, Wraps & Barriers: 37 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Building Papers, Wraps & Barriers
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/building-papers-wraps-and-barriers
  contentHash: ae034dade6fa49759fa062366326a60ca0c57bf67f17f4e67d4c9c9556914877
  customerPhrases:
    - house wrap underlay
    - weather resistant barrier
    - sarking alternative
    - wall underlay membrane
    - breathable membrane
    - vapour permeable wrap
    - vapour permeable underlay
    - synthetic building wrap
  description: 'Building Papers, Wraps & Barriers: 37 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-2015810d67fc
    - src-doc-3f4f7f624c80
    - src-doc-a903d01d1a7a
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:09.553Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Building Papers, Wraps & Barriers
          path:
            - Building Products
            - Building Wraps,Barriers,Underlay & Tapes
            - Building Papers, Wraps & Barriers
          products: 37
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Building Papers, Wraps & Barriers
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Building Wraps,Barriers,Underlay & Tapes
        - Building Papers, Wraps & Barriers
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - building paper
    - building papers
    - paper
    - papers
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: d6fdfce4311c4be2cb03f623cd99487b705c9283f585aefb25623fde6cc54f9a
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/building-papers-wraps-and-barriers
    relationshipId: rel-building-products--building-wraps-barriers-underlay-and-tapes--building-papers-wraps-and-barriers-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes
    type: child_of
x-journeyax-synonyms:
  - building paper
  - building papers
  - paper
  - papers
---
# Building Papers, Wraps & Barriers

Building Papers, Wraps & Barriers: 37 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Wraps,Barriers,Underlay & Tapes](../building-wraps-barriers-underlay-and-tapes.md)
