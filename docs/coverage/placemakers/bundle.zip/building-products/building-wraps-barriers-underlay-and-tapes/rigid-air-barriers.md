---
description: 'Rigid Air Barriers: 24 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Rigid Air Barriers
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/rigid-air-barriers
  contentHash: e2fc170025a1ffa318237344a324852771dad426babf3b20c58249a96a31ebb3
  customerPhrases:
    - fibre cement sheeting
    - osb air barrier
    - gypsum air barrier
    - ecoply barrier board
    - rigid sheathing
    - rigid wrap
    - weatherline gypsum board
    - air barrier plywood
  description: 'Rigid Air Barriers: 24 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-8ce1aff659ee
    - src-doc-1f1e92cd24e1
    - src-doc-1a0574220b23
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:03:17.803Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Rigid Air Barriers
          path:
            - Building Products
            - Building Wraps,Barriers,Underlay & Tapes
            - Rigid Air Barriers
          products: 24
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Rigid Air Barriers
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Building Wraps,Barriers,Underlay & Tapes
        - Rigid Air Barriers
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - rigid air barrier
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: cbbc1df05d8a716d4c519683a6e1899200bb0818c57f803f4419ca7d327c5381
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/rigid-air-barriers
    relationshipId: rel-building-products--building-wraps-barriers-underlay-and-tapes--rigid-air-barriers-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes
    type: child_of
x-journeyax-synonyms:
  - rigid air barrier
---
# Rigid Air Barriers

Rigid Air Barriers: 24 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Wraps,Barriers,Underlay & Tapes](../building-wraps-barriers-underlay-and-tapes.md)
