---
description: 'Damp Proof Course (DPC): 32 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Damp Proof Course (DPC)
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/damp-proof-course-dpc
  contentHash: 8d594e36b1f8b5f834e67cb4c01e94de47ba51e2acf5e4ec75c130a29021a431
  customerPhrases:
    - plastic dpc
    - bitumen dpc
    - synthetic damp course
    - asphalt dpc
    - ldpe dpc
    - tack free dpc
    - brick course damp proofing
    - sanded dpc roll
  description: 'Damp Proof Course (DPC): 32 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-2ef26b49d67f
    - src-doc-b8cfe6840f00
    - src-doc-70827f33e14a
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:02:15.013Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Damp Proof Course (DPC)
          path:
            - Building Products
            - Building Wraps,Barriers,Underlay & Tapes
            - Damp Proof Course (DPC)
          products: 32
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Damp Proof Course (DPC)
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Building Wraps,Barriers,Underlay & Tapes
        - Damp Proof Course (DPC)
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - damp proof course dpcs
    - dpc
    - dpcs
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 61140b9d733b2e2e5e34edb626a2b79fc479e9af161b456960a66f59e3298c1a
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/damp-proof-course-dpc
    relationshipId: rel-building-products--building-wraps-barriers-underlay-and-tapes--damp-proof-course-dpc-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes
    type: child_of
x-journeyax-synonyms:
  - damp proof course dpcs
  - dpc
  - dpcs
---
# Damp Proof Course (DPC)

Damp Proof Course (DPC): 32 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Wraps,Barriers,Underlay & Tapes](../building-wraps-barriers-underlay-and-tapes.md)
