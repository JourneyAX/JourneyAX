---
description: 'Flashing & Sealing Tapes: 67 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Flashing & Sealing Tapes
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/flashing-and-sealing-tapes
  contentHash: 2369a782500ff4081c9a40c49b832fc9a88bfb4417bbd8cd6a85e748552c8792
  customerPhrases:
    - butyl flashing tape
    - butyl tape
    - self adhesive flashing
    - sill seal tape
    - window flashing tape
    - flashing repair tape
    - window seal tape
    - air barrier tape
  description: 'Flashing & Sealing Tapes: 67 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-2604173cfcb6
    - src-doc-494d6f92f245
    - src-doc-c4abf692d232
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:50.144Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Flashing & Sealing Tapes
          path:
            - Building Products
            - Building Wraps,Barriers,Underlay & Tapes
            - Flashing & Sealing Tapes
          products: 67
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Flashing & Sealing Tapes
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Building Wraps,Barriers,Underlay & Tapes
        - Flashing & Sealing Tapes
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - flashing
    - flashings
    - sealing tape
    - sealing tapes
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 3b47d85b417c8fa0627f5cc7c8132c538241278b9600e939decbda56bb294a6e
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/flashing-and-sealing-tapes
    relationshipId: rel-building-products--building-wraps-barriers-underlay-and-tapes--flashing-and-sealing-tapes-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes
    type: child_of
x-journeyax-synonyms:
  - flashing
  - flashings
  - sealing tape
  - sealing tapes
---
# Flashing & Sealing Tapes

Flashing & Sealing Tapes: 67 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Wraps,Barriers,Underlay & Tapes](../building-wraps-barriers-underlay-and-tapes.md)
