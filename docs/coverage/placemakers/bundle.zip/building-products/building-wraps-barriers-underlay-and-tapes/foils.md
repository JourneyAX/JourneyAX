---
description: 'Foils: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Foils
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/foils
  contentHash: 60be9c1ac2629e53b7d618e7fdf1439dbe474cb36aa2e1602ecbc46c5bfb4551
  customerPhrases:
    - aluminium foil underlay
    - reflective building foil
    - fire retardant foil lining
    - foil vapour barrier
    - white faced foil laminate
    - interior foil lining
    - roof and wall foil
    - heat reflective underlay
  description: 'Foils: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-0fd81ea0ce2c
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:06:28.750Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Foils
          path:
            - Building Products
            - Building Wraps,Barriers,Underlay & Tapes
            - Foils
          products: 2
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Foils
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Building Wraps,Barriers,Underlay & Tapes
        - Foils
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - foil
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 883db471dcf1a1f660b2c403a2583eccdb5d254ab01b5ba0c03a3efc28ab7e04
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/foils
    relationshipId: rel-building-products--building-wraps-barriers-underlay-and-tapes--foils-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes
    type: child_of
x-journeyax-synonyms:
  - foil
---
# Foils

Foils: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Wraps,Barriers,Underlay & Tapes](../building-wraps-barriers-underlay-and-tapes.md)
