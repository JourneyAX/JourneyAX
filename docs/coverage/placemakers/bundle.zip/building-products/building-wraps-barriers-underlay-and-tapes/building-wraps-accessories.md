---
description: 'Building Wraps Accessories: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Building Wraps Accessories
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/building-wraps-accessories
  contentHash: 2ee88f2f2228674bf4ecbd47990c683c79f6d3fdd3889f3f2194e46d00026d98
  customerPhrases:
    - underlay strapping
    - house wrap strap
    - insulation strap
    - polythene strap
    - wrap strapping
    - stud wrap strap
    - wall underlay strap
    - roof underlay strapping
  description: 'Building Wraps Accessories: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-48289e01b556
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:05:19.565Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Building Wraps Accessories
          path:
            - Building Products
            - Building Wraps,Barriers,Underlay & Tapes
            - Building Wraps Accessories
          products: 4
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Building Wraps Accessories
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Building Wraps,Barriers,Underlay & Tapes
        - Building Wraps Accessories
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - building wraps accessory
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 142edd36a7f393db26ad86d5521598d6c00c15249140ec0d7e04b1914ffbd62e
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/building-wraps-accessories
    relationshipId: rel-building-products--building-wraps-barriers-underlay-and-tapes--building-wraps-accessories-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes
    type: child_of
x-journeyax-synonyms:
  - building wraps accessory
---
# Building Wraps Accessories

Building Wraps Accessories: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Wraps,Barriers,Underlay & Tapes](../building-wraps-barriers-underlay-and-tapes.md)
