---
description: 'Accessories: 43 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Accessories
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/accessories
  contentHash: 31ef4cd4ac196be9c5b25e3b9bc12fcb3de7343f78217a8cc16da4cbe8b5a1ce
  customerPhrases:
    - drainage board
    - corner guards
    - dimpled membrane
    - below ground drain mat
    - mason guards
    - pipe penetration seal
    - window sill corner trim
    - cable gland seal
  description: 'Accessories: 43 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-ff4c3ca1e870
    - src-doc-6dbac1af3f7e
    - src-doc-86c5d918b00f
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:54.037Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Accessories
          path:
            - Building Products
            - Building Wraps,Barriers,Underlay & Tapes
            - Accessories
          products: 43
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Accessories
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Building Wraps,Barriers,Underlay & Tapes
        - Accessories
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 1fc8cfd0d3aa8743a8851ff740723472e1c5923361d571b8840d91aaf0a94a79
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/accessories
    relationshipId: rel-building-products--building-wraps-barriers-underlay-and-tapes--accessories-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes
    type: child_of
---
# Accessories

Accessories: 43 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Wraps,Barriers,Underlay & Tapes](../building-wraps-barriers-underlay-and-tapes.md)
