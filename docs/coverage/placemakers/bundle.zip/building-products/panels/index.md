# building-products/panels

* [Hardboard & Hessian Full Sheets](hardboard-and-hessian-full-sheets.md) - Hardboard & Hessian Full Sheets: 15 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [MDF](mdf.md) - MDF: 72 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Medium Density Particle Board](medium-density-particle-board.md) - Medium Density Particle Board: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Melamine](melamine.md) - Melamine: 31 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Other Panels](other-panels.md) - Other Panels: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Other Pre-Cut  Panels](other-pre-cut-panels.md) - Other Pre-Cut  Panels: 46 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Strandboard](strandboard.md) - Strandboard: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Veneer Pre-Cut Panels](veneer-pre-cut-panels.md) - Veneer Pre-Cut Panels: 69 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
