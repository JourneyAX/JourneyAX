---
description: 'Hardboard & Hessian Full Sheets: 15 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Hardboard & Hessian Full Sheets
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/panels/hardboard-and-hessian-full-sheets
  contentHash: 56b284047be356b2f1f192a0c919a5631a9ba10cad9fc49af653291d7688b25e
  customerPhrases:
    - pegboard panel
    - pinboard fabric
    - hardboard pegboard
    - cork alternative
    - tempered fibreboard
    - notice board cover
    - high density hardboard
    - tack board
  description: 'Hardboard & Hessian Full Sheets: 15 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:03:19.834Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Hardboard & Hessian Full Sheets
          path:
            - Building Products
            - Panels
            - Hardboard & Hessian Full Sheets
          products: 15
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Hardboard & Hessian Full Sheets
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Panels
        - Hardboard & Hessian Full Sheets
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - hardboard
    - hardboards
    - hessian full sheet
    - hessian full sheets
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: f8cdb2691bdcc449c9cab7ce9e6c5d16718ab3e1aff7315ac217f3761558e5b3
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/panels/hardboard-and-hessian-full-sheets
    relationshipId: rel-building-products--panels--hardboard-and-hessian-full-sheets-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/panels
    type: child_of
x-journeyax-synonyms:
  - hardboard
  - hardboards
  - hessian full sheet
  - hessian full sheets
---
# Hardboard & Hessian Full Sheets

Hardboard & Hessian Full Sheets: 15 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Panels (Building Products)](../panels.md)
