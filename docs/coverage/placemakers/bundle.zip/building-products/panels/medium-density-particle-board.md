---
description: 'Medium Density Particle Board: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Medium Density Particle Board
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/panels/medium-density-particle-board
  contentHash: f2051c0ec7418b4bb80a240e5cd6e6f304ad2bdaa5b356a7578bcfdae1a3d226
  customerPhrases:
    - chipboard sheets
    - pb board 2440x1220
    - radiata pine panels
    - grainless particleboard
    - resin bonded panels
    - moisture resistant chipboard
    - cabinetry board
    - 9mm 12mm 16mm 18mm sheets
    - chipboard
    - chip board
    - particle board
    - particleboard
  description: 'Medium Density Particle Board: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_chipboard:
        detail:
          alias: chipboard
          reason: Chipboard is the everyday word for particle board.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:05:17.737Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Medium Density Particle Board
          path:
            - Building Products
            - Panels
            - Medium Density Particle Board
          products: 4
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Medium Density Particle Board
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Panels
        - Medium Density Particle Board
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - medium density particle boards
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: af1efc9e5aa67bc6613361d7f8419de646f0d3a8dc799c8b930cd613aff37c06
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/panels/medium-density-particle-board
    relationshipId: rel-building-products--panels--medium-density-particle-board-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/panels
    type: child_of
x-journeyax-synonyms:
  - medium density particle boards
---
# Medium Density Particle Board

Medium Density Particle Board: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Panels (Building Products)](../panels.md)
