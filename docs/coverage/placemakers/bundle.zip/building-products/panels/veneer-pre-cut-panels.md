---
description: 'Veneer Pre-Cut Panels: 69 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Veneer Pre-Cut Panels
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/panels/veneer-pre-cut-panels
  contentHash: 1268812726e747f644b339a7dd4a2f1a4369916374dc66d05a5078c5ac48e53f
  customerPhrases:
    - decorative battens
    - pre finished battens
    - timber look battens
    - melamine wrapped battens
    - mdf battens
    - interior battens
    - feature battens
    - wall battens
  description: 'Veneer Pre-Cut Panels: 69 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:54.592Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Veneer Pre-Cut Panels
          path:
            - Building Products
            - Panels
            - Veneer Pre-Cut Panels
          products: 69
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Veneer Pre-Cut Panels
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Panels
        - Veneer Pre-Cut Panels
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - veneer pre cut panel
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 71a928ec2d672b2eb1060a3a2a9b051ee707e3cd2d429b4cc55abf7e23351edf
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/panels/veneer-pre-cut-panels
    relationshipId: rel-building-products--panels--veneer-pre-cut-panels-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/panels
    type: child_of
x-journeyax-synonyms:
  - veneer pre cut panel
---
# Veneer Pre-Cut Panels

Veneer Pre-Cut Panels: 69 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Panels (Building Products)](../panels.md)
