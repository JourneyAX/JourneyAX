# building-products/ceilings

* [Access Panels](access-panels.md) - Access Panels: 21 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
