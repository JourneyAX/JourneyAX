---
description: 'Fibre Cement & Accessories: 206 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Fibre Cement & Accessories (Building Products)
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/building-products/fibre-cement-and-accessories/fibre-cement-accessories
      - concept://placemakers/building-products/fibre-cement-and-accessories/other-fibre-cement-flat-sheet
      - concept://placemakers/building-products/fibre-cement-and-accessories/hardipanel
      - concept://placemakers/building-products/fibre-cement-and-accessories/villaboard
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_building_products_fibre_cement_and_accessories
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/fibre-cement-and-accessories
  contentHash: baeaaeadef04203b737c501f90aa3adb911a78415c3463c80dbcf28620710f23
  customerPhrases:
    - fibre cement board
    - hardie alternative
    - soffit lining board
    - bathroom lining board
    - soffit lining
    - cement sheet lining
    - soffit sheets
    - hardies
    - hardie board
    - hardi board
    - james hardie
    - fibre cement sheet
    - fibre cement sheets
  description: 'Fibre Cement & Accessories: 206 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_building_products_fibre_cement_and_accessories
      questionRef: q.nav_building_products_fibre_cement_and_accessories
      valueMap:
        fibre-cement-accessories: concept://placemakers/building-products/fibre-cement-and-accessories/fibre-cement-accessories
        hardiflex: concept://placemakers/building-products/fibre-cement-and-accessories/hardiflex
        hardigroove: concept://placemakers/building-products/fibre-cement-and-accessories/hardigroove
        hardipanel: concept://placemakers/building-products/fibre-cement-and-accessories/hardipanel
        hardisoffit: concept://placemakers/building-products/fibre-cement-and-accessories/hardisoffit
        other-fibre-cement-flat-sheet: concept://placemakers/building-products/fibre-cement-and-accessories/other-fibre-cement-flat-sheet
        tile-and-slate: concept://placemakers/building-products/fibre-cement-and-accessories/tile-and-slate
        villaboard: concept://placemakers/building-products/fibre-cement-and-accessories/villaboard
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-951379169c64
    - src-doc-ef2e92d1021e
    - src-doc-974ad0a01d61
  extensions:
    x-journeyax-provenance:
      alias_hardies:
        detail:
          alias: hardies
          reason: Customers call fibre cement sheet by the Hardie brand.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Fibre Cement & Accessories
          path:
            - Building Products
            - Fibre Cement & Accessories
          products: 206
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Fibre Cement & Accessories (Building Products)
  requiredFacts:
    - factKey: nav_building_products_fibre_cement_and_accessories
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Fibre Cement & Accessories
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - fibre cement
    - fibre cements
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 78503da67ec7c25edfbbd13b31ce64e1e3442d73316f13adef7d40824805f5e0
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/fibre-cement-and-accessories
    relationshipId: rel-building-products--fibre-cement-and-accessories-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products
    type: child_of
x-journeyax-synonyms:
  - fibre cement
  - fibre cements
---
# Fibre Cement & Accessories (Building Products)

Fibre Cement & Accessories: 206 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Products](../building-products.md)
