---
description: 'Other Fibre Cement Flat Sheet: 27 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Other Fibre Cement Flat Sheet
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/fibre-cement-and-accessories/other-fibre-cement-flat-sheet
  contentHash: 1ab233729ee49dd5328e9fce457cad8478d323ba529b300c412e877dee2f13eb
  customerPhrases:
    - cement sheet
    - special order sheets
    - custom length sheets
    - large format panels
    - 6mm fibreboard
    - 9mm cement sheet
    - 2400 x 1200 board
    - 3000 x 1200 panel
  description: 'Other Fibre Cement Flat Sheet: 27 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:30.394Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Other Fibre Cement Flat Sheet
          path:
            - Building Products
            - Fibre Cement & Accessories
            - Other Fibre Cement Flat Sheet
          products: 27
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Other Fibre Cement Flat Sheet
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Fibre Cement & Accessories
        - Other Fibre Cement Flat Sheet
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - other fibre cement flat sheets
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 824635e6ede707f14e21cec2ccf0ff8e2da0e003bdf8e26ed050796d67b804f6
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/fibre-cement-and-accessories/other-fibre-cement-flat-sheet
    relationshipId: rel-building-products--fibre-cement-and-accessories--other-fibre-cement-flat-sheet-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/fibre-cement-and-accessories
    type: child_of
x-journeyax-synonyms:
  - other fibre cement flat sheets
---
# Other Fibre Cement Flat Sheet

Other Fibre Cement Flat Sheet: 27 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Fibre Cement & Accessories (Building Products)](../fibre-cement-and-accessories.md)
