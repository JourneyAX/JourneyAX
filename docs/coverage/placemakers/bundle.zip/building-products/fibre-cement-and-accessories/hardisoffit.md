---
description: 'Hardisoffit: 5 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Hardisoffit
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/fibre-cement-and-accessories/hardisoffit
  contentHash: a00f3dc53afa002bf5fc096e377e6f61955433976f9fefb217174cc49bcd88ab
  customerPhrases:
    - eaves lining
    - eaves soffit panels
    - prepainted soffit
    - fibre cement soffit
    - prefinished eaves panel
    - veranda lining
    - porch ceiling lining
    - 4 5mm soffit board
  description: 'Hardisoffit: 5 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-023ed540aae1
    - src-doc-22dd5bed8b1e
    - src-doc-fc25cea021a1
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:05:06.923Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Hardisoffit
          path:
            - Building Products
            - Fibre Cement & Accessories
            - Hardisoffit
          products: 5
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Hardisoffit
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Fibre Cement & Accessories
        - Hardisoffit
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - hardisoffits
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 89967e8601152917ea57c13cf0f2ea45f719cb9e0f2fb99cca881f262c787e2f
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/fibre-cement-and-accessories/hardisoffit
    relationshipId: rel-building-products--fibre-cement-and-accessories--hardisoffit-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/fibre-cement-and-accessories
    type: child_of
x-journeyax-synonyms:
  - hardisoffits
---
# Hardisoffit

Hardisoffit: 5 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Fibre Cement & Accessories (Building Products)](../fibre-cement-and-accessories.md)
