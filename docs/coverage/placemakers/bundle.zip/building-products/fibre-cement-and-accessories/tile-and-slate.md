---
description: 'Tile & Slate: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Tile & Slate
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/fibre-cement-and-accessories/tile-and-slate
  contentHash: ee2416c961e2d2a575546a5c0725db33bf5b266d7141f8a9d13eeeb274e976e9
  customerPhrases:
    - tile underlay
    - stone backing board
    - fibre cement backer board
    - ceramic tile backer
    - underlay for tiles
    - stonsheet alternative
    - tile backer board 9mm
    - floor tile substrate
  description: 'Tile & Slate: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:05:19.596Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Tile & Slate
          path:
            - Building Products
            - Fibre Cement & Accessories
            - Tile & Slate
          products: 4
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Tile & Slate
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Fibre Cement & Accessories
        - Tile & Slate
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - slate
    - slates
    - tile
    - tiles
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 973e922fc030b785fc50356c5131aaf9459f14d7fdc573e26b0d0d396ee54ed4
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/fibre-cement-and-accessories/tile-and-slate
    relationshipId: rel-building-products--fibre-cement-and-accessories--tile-and-slate-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/fibre-cement-and-accessories
    type: child_of
x-journeyax-synonyms:
  - slate
  - slates
  - tile
  - tiles
---
# Tile & Slate

Tile & Slate: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Fibre Cement & Accessories (Building Products)](../fibre-cement-and-accessories.md)
