# building-products/fibre-cement-and-accessories

* [Fibre Cement Accessories (Fibre Cement & Accessories)](fibre-cement-accessories.md) - Fibre Cement Accessories: 138 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Hardiflex](hardiflex.md) - Hardiflex: 7 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Hardigroove](hardigroove.md) - Hardigroove: 5 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Hardipanel](hardipanel.md) - Hardipanel: 10 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Hardisoffit](hardisoffit.md) - Hardisoffit: 5 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Other Fibre Cement Flat Sheet](other-fibre-cement-flat-sheet.md) - Other Fibre Cement Flat Sheet: 27 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Tile & Slate](tile-and-slate.md) - Tile & Slate: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Villaboard](villaboard.md) - Villaboard: 10 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
