---
description: 'Fibre Cement Accessories: 138 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Fibre Cement Accessories (Fibre Cement & Accessories)
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/fibre-cement-and-accessories/fibre-cement-accessories
  contentHash: 2a26d82020157d6520f5434a7272c785d9b3af3e426390c8eb8f7be826afc717
  customerPhrases:
    - corner soaker
    - corner moulding
    - corner trim
    - fibre cement corner profile
    - corner soakers aluminium
    - internal corner trim
    - external corner profile
    - shiplap corner
  description: 'Fibre Cement Accessories: 138 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-a5b3d439694c
    - src-doc-45ed305edf0b
    - src-doc-a6df95198a5e
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:49.918Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Fibre Cement Accessories
          path:
            - Building Products
            - Fibre Cement & Accessories
            - Fibre Cement Accessories
          products: 138
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Fibre Cement Accessories (Fibre Cement & Accessories)
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Fibre Cement & Accessories
        - Fibre Cement Accessories
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - fibre cement accessories
    - fibre cement accessory
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 01c0120a1b9f41a7046e90cce7ddb98fa78a15222c450eac6769f3d260ba5fb7
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/fibre-cement-and-accessories/fibre-cement-accessories
    relationshipId: rel-building-products--fibre-cement-and-accessories--fibre-cement-accessories-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/fibre-cement-and-accessories
    type: child_of
x-journeyax-synonyms:
  - fibre cement accessories
  - fibre cement accessory
---
# Fibre Cement Accessories (Fibre Cement & Accessories)

Fibre Cement Accessories: 138 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Fibre Cement & Accessories (Building Products)](../fibre-cement-and-accessories.md)
