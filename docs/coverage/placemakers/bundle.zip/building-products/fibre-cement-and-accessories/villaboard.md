---
description: 'Villaboard: 10 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Villaboard
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/fibre-cement-and-accessories/villaboard
  contentHash: 1e753dc739ef3976bab478454d341d80852970eb80dbe6ae0f25531c56e150b0
  customerPhrases:
    - fibre cement lining
    - internal cladding board
    - plaster backing board
    - veranda ceiling lining
    - rimboard 6mm 9mm
    - durable lining board
  description: 'Villaboard: 10 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-951379169c64
    - src-doc-ef2e92d1021e
    - src-doc-33d07044c5ca
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:03:26.166Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Villaboard
          path:
            - Building Products
            - Fibre Cement & Accessories
            - Villaboard
          products: 10
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Villaboard
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Fibre Cement & Accessories
        - Villaboard
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - villaboards
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 158c1e2216463963b80251d5a95d8ecdc3748aebcb51cb32b47b629e3b05cc7f
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/fibre-cement-and-accessories/villaboard
    relationshipId: rel-building-products--fibre-cement-and-accessories--villaboard-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/fibre-cement-and-accessories
    type: child_of
x-journeyax-synonyms:
  - villaboards
---
# Villaboard

Villaboard: 10 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Fibre Cement & Accessories (Building Products)](../fibre-cement-and-accessories.md)
