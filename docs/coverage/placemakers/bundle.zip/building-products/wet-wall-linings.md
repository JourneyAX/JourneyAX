---
description: 'Wet Wall Linings: 242 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Wet Wall Linings
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/building-products/wet-wall-linings/accessories-and-special-order-lining
      - concept://placemakers/building-products/wet-wall-linings/high-pressure-laminates
      - concept://placemakers/building-products/wet-wall-linings/paint-surface-hardboard-backing
      - concept://placemakers/building-products/wet-wall-linings/paint-finish-fibre-cement-backing
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_building_products_wet_wall_linings
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/wet-wall-linings
  contentHash: 6046e9ddbd3678f14cb9aeb504df526d2b5a3427e580eb75584e607933ba42a7
  customerPhrases:
    - easy clean wall lining
    - shower wall panels
  description: 'Wet Wall Linings: 242 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_building_products_wet_wall_linings
      questionRef: q.nav_building_products_wet_wall_linings
      valueMap:
        accessories-and-special-order-lining: concept://placemakers/building-products/wet-wall-linings/accessories-and-special-order-lining
        high-pressure-laminates: concept://placemakers/building-products/wet-wall-linings/high-pressure-laminates
        paint-finish-fibre-cement-backing: concept://placemakers/building-products/wet-wall-linings/paint-finish-fibre-cement-backing
        paint-surface-hardboard-backing: concept://placemakers/building-products/wet-wall-linings/paint-surface-hardboard-backing
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-e37da80e78d7
    - src-doc-e7def1ebf257
    - src-doc-8078ffafcd16
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Wet Wall Linings
          path:
            - Building Products
            - Wet Wall Linings
          products: 242
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Wet Wall Linings
  requiredFacts:
    - factKey: nav_building_products_wet_wall_linings
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Wet Wall Linings
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - backing
    - backings
    - lining
    - linings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 1b05e33553d39b63db4489c24a9e2c89b7cc1d467dd8a6d9d467b0add7ab3430
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/wet-wall-linings
    relationshipId: rel-building-products--wet-wall-linings-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products
    type: child_of
x-journeyax-synonyms:
  - backing
  - backings
  - lining
  - linings
---
# Wet Wall Linings

Wet Wall Linings: 242 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Products](../building-products.md)
