# building-products/wet-wall-linings

* [Accessories & Special Order Lining](accessories-and-special-order-lining.md) - Accessories & Special Order Lining: 195 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [High Pressure Laminates](high-pressure-laminates.md) - High Pressure Laminates: 23 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Paint Finish Fibre Cement Backing](paint-finish-fibre-cement-backing.md) - Paint Finish Fibre Cement Backing: 9 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Paint Surface Hardboard Backing](paint-surface-hardboard-backing.md) - Paint Surface Hardboard Backing: 15 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
