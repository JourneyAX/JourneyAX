---
description: 'Paint Finish Fibre Cement Backing: 9 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Paint Finish Fibre Cement Backing
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/wet-wall-linings/paint-finish-fibre-cement-backing
  contentHash: 135d69bdd7c2927055fa52450723af1d0b2b75538e58fc96abad9b19620ff1c9
  customerPhrases:
    - pre finished wall panels
    - fibre cement linings
    - moisture resistant wall panels
    - grout free tile panels
    - internal wet area panels
    - ceramic look panels
    - backing board for tiles
    - paint finish cement sheet
  description: 'Paint Finish Fibre Cement Backing: 9 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-8078ffafcd16
    - src-doc-42b6d865bc8c
    - src-doc-fce85f126013
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:03:51.499Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Paint Finish Fibre Cement Backing
          path:
            - Building Products
            - Wet Wall Linings
            - Paint Finish Fibre Cement Backing
          products: 9
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Paint Finish Fibre Cement Backing
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Wet Wall Linings
        - Paint Finish Fibre Cement Backing
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - paint finish fibre cement backings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 9b6f9fede7c47a7db7257f628409e3f58de425215f13d5c113e5fb28378f9ded
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/wet-wall-linings/paint-finish-fibre-cement-backing
    relationshipId: rel-building-products--wet-wall-linings--paint-finish-fibre-cement-backing-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/wet-wall-linings
    type: child_of
x-journeyax-synonyms:
  - paint finish fibre cement backings
---
# Paint Finish Fibre Cement Backing

Paint Finish Fibre Cement Backing: 9 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Wet Wall Linings](../wet-wall-linings.md)
