---
description: 'High Pressure Laminates: 23 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: High Pressure Laminates
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/wet-wall-linings/high-pressure-laminates
  contentHash: c3ed4b43153993c76a349e53a8b1883b709b0bca06bb6a371b143def582bae8d
  customerPhrases:
    - wall panelling board
    - compact laminate panel
    - wet area cladding
    - kitchen splashback board
    - non rot wall lining
    - fire resistant wall panel
    - 4 5mm wall sheet
    - gloss laminate panel
  description: 'High Pressure Laminates: 23 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-942cf8003094
    - src-doc-cfd6089b58ac
    - src-doc-f67c0b8d949b
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:47.734Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - High Pressure Laminates
          path:
            - Building Products
            - Wet Wall Linings
            - High Pressure Laminates
          products: 23
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: High Pressure Laminates
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Wet Wall Linings
        - High Pressure Laminates
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - high pressure laminate
    - laminate
    - laminates
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: ef8ab11d3378e7cbb2f50b7d2c4b8e0d6e18e1eb7b95a005ef1bcc5c78146191
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/wet-wall-linings/high-pressure-laminates
    relationshipId: rel-building-products--wet-wall-linings--high-pressure-laminates-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/wet-wall-linings
    type: child_of
x-journeyax-synonyms:
  - high pressure laminate
  - laminate
  - laminates
---
# High Pressure Laminates

High Pressure Laminates: 23 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Wet Wall Linings](../wet-wall-linings.md)
