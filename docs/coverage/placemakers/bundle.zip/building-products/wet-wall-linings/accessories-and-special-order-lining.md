---
description: 'Accessories & Special Order Lining: 195 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Accessories & Special Order Lining
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/wet-wall-linings/accessories-and-special-order-lining
  contentHash: 30770d520e1c4828e21c3c9b45963acf7c72ef6ba7e3b49fc1c7711ea86bdd2b
  customerPhrases:
    - wall panel trim
    - waterproof wall panels
    - wet wall join strip
    - shower wall cladding
    - pvc wall profile
    - wet area panelling
    - panel end cap
    - bathroom wall sheets
  description: 'Accessories & Special Order Lining: 195 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-e37da80e78d7
    - src-doc-e7def1ebf257
    - src-doc-eb4593eb30d1
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:26.876Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Accessories & Special Order Lining
          path:
            - Building Products
            - Wet Wall Linings
            - Accessories & Special Order Lining
          products: 195
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Accessories & Special Order Lining
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Wet Wall Linings
        - Accessories & Special Order Lining
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - special order lining
    - special order linings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 315ffc95494eae422c998c3119ce661532685884a5ff76070fa70fcab6638c8f
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/wet-wall-linings/accessories-and-special-order-lining
    relationshipId: rel-building-products--wet-wall-linings--accessories-and-special-order-lining-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/wet-wall-linings
    type: child_of
x-journeyax-synonyms:
  - special order lining
  - special order linings
---
# Accessories & Special Order Lining

Accessories & Special Order Lining: 195 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Wet Wall Linings](../wet-wall-linings.md)
