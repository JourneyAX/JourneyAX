---
description: 'Plasterboard: 80 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Plasterboard
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/building-products/plasterboard/specialist-board
      - concept://placemakers/building-products/plasterboard/standard-board
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_building_products_plasterboard
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/plasterboard
  contentHash: dec18fca6761d3d19f7c564fe852e30bae2f50ef105ddce4f8abe68cfbed8b2d
  customerPhrases:
    - long length plasterboard
    - gib
    - gibboard
    - gib board
    - gib sheet
    - gib sheets
    - gib plasterboard
    - plasterboard sheets
  description: 'Plasterboard: 80 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_building_products_plasterboard
      questionRef: q.nav_building_products_plasterboard
      valueMap:
        specialist-board: concept://placemakers/building-products/plasterboard/specialist-board
        standard-board: concept://placemakers/building-products/plasterboard/standard-board
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_gib:
        detail:
          alias: gib
          reason: GIB is the brand New Zealand customers use as the everyday word for plasterboard.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Plasterboard
          path:
            - Building Products
            - Plasterboard
          products: 80
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Plasterboard
  requiredFacts:
    - factKey: nav_building_products_plasterboard
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Plasterboard
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - plasterboards
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 45b20f055f8ba3a95f89c4865d24de97b7bd80e4c066b93ee1755349f6398cf8
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/plasterboard
    relationshipId: rel-building-products--plasterboard-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products
    type: child_of
  - claimClasses: []
    confidence: low
    contentHash: 384dd2a2619ec5d2cd5d629bdaa1a8ed24be73347f21033098089c8fd394f017
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/plasterboard
    relationshipId: rel-xs-plasterboard_installation_extras-1
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/building-products/plasterboard-compounds-and-accessories/compounds-and-plasters
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: 1acaace50ef2be01bd1cbd0b63559fcae71b1394a12fabf9e5137d70eb24a9f1
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/plasterboard
    relationshipId: rel-xs-plasterboard_installation_extras-2
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/building-products/plasterboard-compounds-and-accessories/drywall-tapes
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: f1ea574963820a755a4a920778e6377d179897ed3c67813064971d67a355c037
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/plasterboard
    relationshipId: rel-xs-plasterboard_installation_extras-3
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/fastenings-and-general-hardware/fastenings/wood-screws
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: 6e1d2eadbc042572cdeb6babcc82f661ed60a5beee844f7b4a92e94d53632366
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/plasterboard
    relationshipId: rel-xs-plasterboard_installation_extras-4
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/building-products/plasterboard-compounds-and-accessories/trims-and-moulds
    type: cross_sell
x-journeyax-synonyms:
  - plasterboards
---
# Plasterboard

Plasterboard: 80 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Building Products](../building-products.md)
* cross sell: [Compounds & Plasters](plasterboard-compounds-and-accessories/compounds-and-plasters.md)
* cross sell: [Drywall Tapes](plasterboard-compounds-and-accessories/drywall-tapes.md)
* cross sell: [Wood Screws](../fastenings-and-general-hardware/fastenings/wood-screws.md)
* cross sell: [Trims & Moulds](plasterboard-compounds-and-accessories/trims-and-moulds.md)
