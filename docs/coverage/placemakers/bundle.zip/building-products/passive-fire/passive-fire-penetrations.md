---
description: 'Passive Fire Penetrations: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Passive Fire Penetrations
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: requires_professional_confirmation
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/passive-fire/passive-fire-penetrations
  contentHash: 3df75afbb6046750d3e6f2bc3a074e9a892f155b5f750d87da28044eb3bc5105
  customerPhrases:
    - fire collar retrofit
    - pipe firestop collar
    - penetration collar 100mm
    - plastic pipe fire collar
    - cable firestop
    - lagged copper pipe protection
    - concrete slab firestop
    - firestop penetration
  description: 'Passive Fire Penetrations: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-4484620230bf
    - src-doc-f347704b6a1c
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:07:33.012Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      policy_confirm_with_a_qualified_person:
        detail:
          overlay: confirm_with_a_qualified_person
          reason: 'Proposed: a qualified person confirms the selection before checkout for products that are normally installed by a licensed trade. PlaceMakers to approve the list.'
          section: overlays
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Passive Fire Penetrations
          path:
            - Building Products
            - Passive Fire
            - Passive Fire Penetrations
          products: 1
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Passive Fire Penetrations
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Passive Fire
        - Passive Fire Penetrations
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - passive fire penetration
    - penetration
    - penetrations
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: c926230ca22c928ea735315ab6abef7c53e4b2f977a9bd52a2bbd890a57a7ecd
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/passive-fire/passive-fire-penetrations
    relationshipId: rel-building-products--passive-fire--passive-fire-penetrations-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/passive-fire
    type: child_of
x-journeyax-synonyms:
  - passive fire penetration
  - penetration
  - penetrations
---
# Passive Fire Penetrations

Passive Fire Penetrations: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Passive Fire](../passive-fire.md)
