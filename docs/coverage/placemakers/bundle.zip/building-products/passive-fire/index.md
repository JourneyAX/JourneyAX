# building-products/passive-fire

* [Passive Fire Penetrations](passive-fire-penetrations.md) - Passive Fire Penetrations: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
