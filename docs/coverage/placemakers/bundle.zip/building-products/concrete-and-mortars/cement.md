---
description: 'Cement: 5 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Cement
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/concrete-and-mortars/cement
  contentHash: 032ab41f52bc07558ec0a08297b489fba0e7583f2763d6bed0518bc17f2c3d11
  customerPhrases:
    - bagged cement
    - white portland cement
    - general purpose cement
    - white cement 20kg
    - gp cement
    - white opc
    - portland cement bags
    - white mortar mix base
  description: 'Cement: 5 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:05:35.764Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Cement
          path:
            - Building Products
            - Concrete & Mortars
            - Cement
          products: 5
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Cement
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Concrete & Mortars
        - Cement
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 641729b703cde51dc8a1438ba8996afb3f71d412480d6a217204341faf882799
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/concrete-and-mortars/cement
    relationshipId: rel-building-products--concrete-and-mortars--cement-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/concrete-and-mortars
    type: child_of
---
# Cement

Cement: 5 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Concrete & Mortars](../concrete-and-mortars.md)
