---
description: 'Bagged Concrete: 10 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Bagged Concrete
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/concrete-and-mortars/bagged-concrete
  contentHash: 70f01591f17f875a693e1b1152c8b93ae3a6addb778ca702a39de1e54029e81e
  customerPhrases:
    - high strength premix
    - pre mixed concrete
    - 40mpa concrete mix
    - commercial plaster
    - ready mix concrete bags
    - rapid set concrete
    - rendering mix
    - instant post mix
  description: 'Bagged Concrete: 10 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:04:56.889Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Bagged Concrete
          path:
            - Building Products
            - Concrete & Mortars
            - Bagged Concrete
          products: 10
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Bagged Concrete
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Concrete & Mortars
        - Bagged Concrete
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - bagged concretes
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: ee81351b83af2acfa5d10bea0a59cfc52d0e745ab9cb141c9674b7ced248edcd
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/concrete-and-mortars/bagged-concrete
    relationshipId: rel-building-products--concrete-and-mortars--bagged-concrete-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/concrete-and-mortars
    type: child_of
x-journeyax-synonyms:
  - bagged concretes
---
# Bagged Concrete

Bagged Concrete: 10 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Concrete & Mortars](../concrete-and-mortars.md)
