---
description: 'Lime: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Lime
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/concrete-and-mortars/lime
  contentHash: db10503d7637505db015341f77b03315e83045372c425a70ad116c4ef7368a95
  customerPhrases:
    - builders lime
    - hydrated lime powder
    - mortar lime
    - lime for plaster
    - lime for masonry
    - bagged lime 20kg
    - lime for rendering
    - lime for soil stabilisation
  description: 'Lime: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:06:59.140Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Lime
          path:
            - Building Products
            - Concrete & Mortars
            - Lime
          products: 1
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Lime
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Concrete & Mortars
        - Lime
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - limes
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 88060c3e2e8a1bfb4c10c96e9114e299b3345034eba85e72836273bfea81de71
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/concrete-and-mortars/lime
    relationshipId: rel-building-products--concrete-and-mortars--lime-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/concrete-and-mortars
    type: child_of
x-journeyax-synonyms:
  - limes
---
# Lime

Lime: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Concrete & Mortars](../concrete-and-mortars.md)
