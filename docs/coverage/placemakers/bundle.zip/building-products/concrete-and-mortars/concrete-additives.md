---
description: 'Concrete Additives: 35 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Concrete Additives
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/concrete-and-mortars/concrete-additives
  contentHash: 3114d0ba10d2eccddaad0f6cf44ee49f762f82b7fa3bb0d6bffa54cb91f70eab
  customerPhrases:
    - concrete surface retarder
    - plasticiser
    - concrete pigment
    - exposed aggregate finish
    - plasticizer
    - masonry oxide
    - aggregate reveal
    - mortar additive
  description: 'Concrete Additives: 35 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-af25cb68342c
    - src-doc-218b7c9b3316
    - src-doc-ad050654582f
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:02:14.698Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Concrete Additives
          path:
            - Building Products
            - Concrete & Mortars
            - Concrete Additives
          products: 35
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Concrete Additives
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Concrete & Mortars
        - Concrete Additives
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - additive
    - additives
    - concrete additive
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 92f27380a83126b63e719437f40a96942bb2d087ba300bbd81684595d2a46375
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/concrete-and-mortars/concrete-additives
    relationshipId: rel-building-products--concrete-and-mortars--concrete-additives-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/concrete-and-mortars
    type: child_of
x-journeyax-synonyms:
  - additive
  - additives
  - concrete additive
---
# Concrete Additives

Concrete Additives: 35 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Concrete & Mortars](../concrete-and-mortars.md)
