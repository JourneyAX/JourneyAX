---
description: 'Bagged Mortars: 25 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Bagged Mortars
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/concrete-and-mortars/bagged-mortars
  contentHash: 7ed63748277de566d6aad03280ba0b3773911a6a12f698704368dfc1c85833a4
  customerPhrases:
    - mortar mix
    - masonry mortar mix
    - concrete patch
    - block mortar mix
    - ready mixed mortar
    - bagged coloured mortar
    - patching compound
    - masonry mortar
    - bagged mortar
    - brick mortar
    - builders mortar
  description: 'Bagged Mortars: 25 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-0482068b605d
    - src-doc-eb04f00e82e9
    - src-doc-4da6dea390aa
  extensions:
    x-journeyax-provenance:
      alias_mortar:
        detail:
          alias: mortar
          reason: Customers ask for mortar mix.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:03:54.934Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Bagged Mortars
          path:
            - Building Products
            - Concrete & Mortars
            - Bagged Mortars
          products: 25
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Bagged Mortars
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Concrete & Mortars
        - Bagged Mortars
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - bagged mortar
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 9720af223bcaf377b426afef9f63d8fec401fcb3b6db3205c95df36348cfb54a
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/concrete-and-mortars/bagged-mortars
    relationshipId: rel-building-products--concrete-and-mortars--bagged-mortars-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/concrete-and-mortars
    type: child_of
x-journeyax-synonyms:
  - bagged mortar
---
# Bagged Mortars

Bagged Mortars: 25 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Concrete & Mortars](../concrete-and-mortars.md)
