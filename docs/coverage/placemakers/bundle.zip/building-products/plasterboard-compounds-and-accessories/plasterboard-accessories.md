---
description: 'Plasterboard Accessories: 5 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Plasterboard Accessories
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/plasterboard-compounds-and-accessories/plasterboard-accessories
  contentHash: cff4df287fb02455784cd012d759cc2d5cdc2380accd6cbd02701e47799c1e6d
  customerPhrases:
    - cove moulding
    - cornice moulding
    - plaster cove
    - ceiling trim
    - wall and ceiling mould
    - gyprock cornice
    - gib cove
    - cove strip
  description: 'Plasterboard Accessories: 5 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:05:06.825Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Plasterboard Accessories
          path:
            - Building Products
            - Plasterboard Compounds & Accessories
            - Plasterboard Accessories
          products: 5
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Plasterboard Accessories
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Plasterboard Compounds & Accessories
        - Plasterboard Accessories
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - plasterboard accessory
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 9ea0583979ff9aab6e5161275b6d0557b7e8260a86ee991c4b34e64cebb50f32
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/plasterboard-compounds-and-accessories/plasterboard-accessories
    relationshipId: rel-building-products--plasterboard-compounds-and-accessories--plasterboard-accessories-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/plasterboard-compounds-and-accessories
    type: child_of
x-journeyax-synonyms:
  - plasterboard accessory
---
# Plasterboard Accessories

Plasterboard Accessories: 5 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Plasterboard Compounds & Accessories](../plasterboard-compounds-and-accessories.md)
