---
description: 'Compounds & Plasters: 50 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Compounds & Plasters
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/plasterboard-compounds-and-accessories/compounds-and-plasters
  contentHash: dfa34b0f58d6e40fde7e2ee4bf2595ccc2d84088d80f885a580d7b9db0e666fd
  customerPhrases:
    - jointing compound
    - plaster adhesive
    - plaster of paris
    - mud for joints
    - cornice adhesive
    - casting plaster
    - tanking joint compound
    - coving bond
    - gib stopping
    - gib stop
    - stopping compound
    - plasterboard compound
  description: 'Compounds & Plasters: 50 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_gib_stopping:
        detail:
          alias: gib_stopping
          reason: Stopping and jointing are the trade words for plasterboard compound.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:05.779Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Compounds & Plasters
          path:
            - Building Products
            - Plasterboard Compounds & Accessories
            - Compounds & Plasters
          products: 50
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Compounds & Plasters
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Plasterboard Compounds & Accessories
        - Compounds & Plasters
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - plaster
    - plasters
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 344a0a8e6159825044b8cafba4dada15d9289969bd46764d48c9116eafac96ae
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/plasterboard-compounds-and-accessories/compounds-and-plasters
    relationshipId: rel-building-products--plasterboard-compounds-and-accessories--compounds-and-plasters-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/plasterboard-compounds-and-accessories
    type: child_of
x-journeyax-synonyms:
  - plaster
  - plasters
---
# Compounds & Plasters

Compounds & Plasters: 50 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Plasterboard Compounds & Accessories](../plasterboard-compounds-and-accessories.md)
