---
description: 'Trims & Moulds: 34 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Trims & Moulds
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/plasterboard-compounds-and-accessories/trims-and-moulds
  contentHash: aa00c32b1e63345938dc7cf08de69acc120a302e3b3741b702ece95768a4c196
  customerPhrases:
    - corner bead
    - stopping bead
    - stop end cap
    - galv steel trim
    - perforated bead
    - masonry corner angle
    - plasterboard edge trim
    - 90 degree angle bead
    - cornice
    - gib cornice
    - stop bead
    - shadowline
    - shadow line
  description: 'Trims & Moulds: 34 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-3ddbdabef485
    - src-doc-d6d14594aeed
    - src-doc-066f992ad496
  extensions:
    x-journeyax-provenance:
      alias_cornice:
        detail:
          alias: cornice
          reason: Cornice, beads and shadowline are how customers ask for plasterboard trims.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:08.059Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Trims & Moulds
          path:
            - Building Products
            - Plasterboard Compounds & Accessories
            - Trims & Moulds
          products: 34
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Trims & Moulds
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Plasterboard Compounds & Accessories
        - Trims & Moulds
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - mould
    - moulds
    - trim
    - trims
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 2541bff525b45768a5e84c82fbf617632ca37faf31ac1e375553dc057f3990be
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/plasterboard-compounds-and-accessories/trims-and-moulds
    relationshipId: rel-building-products--plasterboard-compounds-and-accessories--trims-and-moulds-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/plasterboard-compounds-and-accessories
    type: child_of
x-journeyax-synonyms:
  - mould
  - moulds
  - trim
  - trims
---
# Trims & Moulds

Trims & Moulds: 34 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Plasterboard Compounds & Accessories](../plasterboard-compounds-and-accessories.md)
