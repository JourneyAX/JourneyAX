---
description: 'Drywall Tapes: 12 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Drywall Tapes
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/building-products/plasterboard-compounds-and-accessories/drywall-tapes
  contentHash: 384f25fddb63bded70d67d1afa728e54d2ff1ac2a2d7c177fb1af75f8ed2c12a
  customerPhrases:
    - jointing tape
    - fibreglass tape
    - paper joint tape
    - glass fibre tape
    - corner tape
    - fiberglass joint tape
    - paper drywall tape
    - jointing tape 50mm
    - scrim
    - scrim tape
    - gib tape
    - paper tape
    - mesh tape
    - joint tape
  description: 'Drywall Tapes: 12 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_gib_tape:
        detail:
          alias: gib_tape
          reason: Scrim and paper tape are the usual words for plasterboard joint tape.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:03:10.938Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Drywall Tapes
          path:
            - Building Products
            - Plasterboard Compounds & Accessories
            - Drywall Tapes
          products: 12
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Drywall Tapes
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Building Products
        - Plasterboard Compounds & Accessories
        - Drywall Tapes
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - drywall tape
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: bff661f93aec096f4302feef86a85fa3962ec6f6ea710ea2907c5256ed5d6d7c
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/building-products/plasterboard-compounds-and-accessories/drywall-tapes
    relationshipId: rel-building-products--plasterboard-compounds-and-accessories--drywall-tapes-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/building-products/plasterboard-compounds-and-accessories
    type: child_of
x-journeyax-synonyms:
  - drywall tape
---
# Drywall Tapes

Drywall Tapes: 12 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Plasterboard Compounds & Accessories](../plasterboard-compounds-and-accessories.md)
