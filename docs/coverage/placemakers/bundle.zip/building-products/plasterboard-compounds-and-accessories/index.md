# building-products/plasterboard-compounds-and-accessories

* [Compounds & Plasters](compounds-and-plasters.md) - Compounds & Plasters: 50 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Drywall Tapes](drywall-tapes.md) - Drywall Tapes: 12 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Plasterboard Accessories](plasterboard-accessories.md) - Plasterboard Accessories: 5 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Trims & Moulds](trims-and-moulds.md) - Trims & Moulds: 34 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
