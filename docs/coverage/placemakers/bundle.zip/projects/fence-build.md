---
description: Building or replacing a fence.
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Fence build
type: project
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/timber-and-plywood/timber-fencing
      - concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/fence-panels
      - concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/posts
      - concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/fencing-accessories
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.fence_type
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/projects/fence-build
  contentHash: 09589653b2bb717638e6d1c561a3619cf5e83bcb38f2d12642c556d9b727b4b5
  customerPhrases:
    - build a fence
    - new fence
    - fencing project
    - replace my fence
    - build my fence
    - building a fence
    - put up a fence
    - build a new fence
  description: Building or replacing a fence.
  discriminators:
    - clarifyFirst: false
      factKey: fence_type
      questionRef: q.fence_type
      valueMap: {}
    - clarifyFirst: false
      factKey: fence_length
      questionRef: q.fence_length
      valueMap: {}
  evidenceRefs:
    - src-authoring-proposal
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          id: fence-build
          section: projects
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: project
  lifecycle:
    status: active_draft
  name: Fence build
  requiredFacts:
    - factKey: fence_type
      importance: high
    - factKey: fence_length
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Timber Fencing
      - - Outdoor & Landscaping
        - Fencing & Netting (Non Timber)
        - Fence Panels
      - - Outdoor & Landscaping
        - Fencing & Netting (Non Timber)
        - Posts
      - - Outdoor & Landscaping
        - Fencing & Netting (Non Timber)
        - Fencing Accessories
      - - Outdoor & Landscaping
        - Fencing & Netting (Non Timber)
        - Metal Gates
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: project
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: low
    contentHash: d08f6a2dddad35622e40df3a09e62132bd456b9132dba239c2d9d3e443d3de86
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/projects/fence-build
    relationshipId: rel-xs-fence_project_extras-1
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber/metal-gates
    type: cross_sell
---
# Fence build

Building or replacing a fence.

## Related concepts

* cross sell: [Metal Gates](../outdoor-and-landscaping/fencing-and-netting-non-timber/metal-gates.md)
