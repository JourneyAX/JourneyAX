# projects

* [Bathroom renovation](bathroom-renovation.md) - Planning a new or renovated bathroom or ensuite.
* [Deck build](deck-build.md) - Building or extending a deck.
* [Fence build](fence-build.md) - Building or replacing a fence.
* [Insulating a home](insulate-home.md) - Insulating walls, ceilings or floors.
* [Kitchen update](kitchen-update.md) - Updating or renovating a kitchen.
* [Laundry makeover](laundry-makeover.md) - Planning a new or renovated laundry.
* [Painting project](paint-a-room.md) - Painting or finishing walls, ceilings or timber.
* [Wet area lining](wet-area-lining.md) - Lining and sealing the walls of a bathroom, shower or laundry.
