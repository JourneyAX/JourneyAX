---
description: Planning a new or renovated laundry.
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Laundry makeover
type: project
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/kitchens-and-laundry/laundry/laundry-cabinetry
      - concept://placemakers/kitchens-and-laundry/laundry/laundry-tubs
      - concept://placemakers/kitchens-and-laundry/laundry/laundry-appliances-and-accessories
      - concept://placemakers/kitchens-and-laundry/laundry/laundry-sinkware
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.project_scope
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/projects/laundry-makeover
  contentHash: 3673d7983503924e16988f71c5f21720fc723ac077eda26bd428bc0018f44615
  customerPhrases:
    - laundry makeover
    - renovate my laundry
    - new laundry
    - laundry renovation
    - laundry remodel
    - laundry reno
    - renovating my laundry
    - redo my laundry
  description: Planning a new or renovated laundry.
  discriminators:
    - clarifyFirst: false
      factKey: project_scope
      questionRef: q.project_scope
      valueMap: {}
    - clarifyFirst: false
      factKey: room_dimensions
      questionRef: q.room_dimensions
      valueMap: {}
    - clarifyFirst: false
      factKey: laundry_features
      questionRef: q.laundry_features
      valueMap: {}
  evidenceRefs:
    - src-authoring-proposal
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          id: laundry-makeover
          section: projects
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  journeyRef:
    journeyId: placemakers_plan_your_space
  lens: project
  lifecycle:
    status: active_draft
  name: Laundry makeover
  requiredFacts:
    - factKey: project_scope
      importance: high
    - factKey: room_dimensions
      importance: medium
    - factKey: laundry_features
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Kitchens & Laundry
        - Laundry
        - Laundry Cabinetry
      - - Kitchens & Laundry
        - Laundry
        - Laundry Tubs
      - - Kitchens & Laundry
        - Laundry
        - Laundry Appliances & Accessories
      - - Kitchens & Laundry
        - Laundry
        - Laundry Sinkware
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: project
  version: 1
x-journeyax-relationships: []
---
# Laundry makeover

Planning a new or renovated laundry.
