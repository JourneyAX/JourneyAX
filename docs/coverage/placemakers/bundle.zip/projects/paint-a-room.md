---
description: Painting or finishing walls, ceilings or timber.
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Painting project
type: project
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/paint-and-decorating/paint/interior-paint
      - concept://placemakers/paint-and-decorating/paint/exterior-paint
      - concept://placemakers/paint-and-decorating/paint/woodcare
      - concept://placemakers/paint-and-decorating/paint/primers-sealers-and-undercoats
    groupSelection:
      factKey: paint_surface
      valueMap:
        exterior:
          - concept://placemakers/paint-and-decorating/paint/exterior-paint
        interior:
          - concept://placemakers/paint-and-decorating/paint/interior-paint
        timber:
          - concept://placemakers/paint-and-decorating/paint/woodcare
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.paint_surface
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/projects/paint-a-room
  contentHash: aca9eca9de196c95ec09cfbffbf250e5396c31272663988d2443ebf555fd388f
  customerPhrases:
    - paint a room
    - painting a room
    - repaint my house
    - paint my house
    - painting project
    - paint the walls
    - paint my room
    - painting my house
    - repaint a room
    - paint my walls
    - painting a house
  description: Painting or finishing walls, ceilings or timber.
  discriminators:
    - clarifyFirst: false
      factKey: paint_surface
      questionRef: q.paint_surface
      valueMap: {}
  evidenceRefs:
    - src-authoring-proposal
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          id: paint-a-room
          section: projects
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: project
  lifecycle:
    status: active_draft
  name: Painting project
  requiredFacts:
    - factKey: paint_surface
      importance: high
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Paint & Decorating
        - Paint
        - Interior Paint
      - - Paint & Decorating
        - Paint
        - Exterior Paint
      - - Paint & Decorating
        - Paint
        - Woodcare
      - - Paint & Decorating
        - Paint
        - Primers Sealers & Undercoats
      - - Paint & Decorating
        - Paint Accessories
        - Brushes & Rollers
      - - Paint & Decorating
        - Paint Accessories
        - Masking
      - - Paint & Decorating
        - Paint Accessories
        - Protective Wear & Coverings
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: project
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: low
    contentHash: 7230f116a0e2c456f4749b5cae733ded8818b5b9acb94aa38ba20d8e284ee73b
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/projects/paint-a-room
    relationshipId: rel-xs-paint_project_extras-1
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/paint-and-decorating/paint-accessories/brushes-and-rollers
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: 9d53ca5aee977e9ef152d17dfcbca0a15e99b38a5daf6076857075c34f3aebb6
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/projects/paint-a-room
    relationshipId: rel-xs-paint_project_extras-2
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/paint-and-decorating/paint-accessories/masking
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: 18b7d2b3c9ead06c64682e6f5ad8b1a700a19015169caa851ec92d3236b317c0
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/projects/paint-a-room
    relationshipId: rel-xs-paint_project_extras-3
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/paint-and-decorating/paint/primers-sealers-and-undercoats
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: 09d33dfc2c9074628f691b3eaa4cd86d7d179d5f391575e15a604bdd3273e14e
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/projects/paint-a-room
    relationshipId: rel-xs-paint_project_extras-4
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/paint-and-decorating/paint-accessories/protective-wear-and-coverings
    type: cross_sell
---
# Painting project

Painting or finishing walls, ceilings or timber.

## Related concepts

* cross sell: [Brushes & Rollers](../paint-and-decorating/paint-accessories/brushes-and-rollers.md)
* cross sell: [Masking](../paint-and-decorating/paint-accessories/masking.md)
* cross sell: [Primers Sealers & Undercoats](../paint-and-decorating/paint/primers-sealers-and-undercoats.md)
* cross sell: [Protective Wear & Coverings](../paint-and-decorating/paint-accessories/protective-wear-and-coverings.md)
