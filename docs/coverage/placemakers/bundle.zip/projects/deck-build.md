---
description: Building or extending a deck.
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Deck build
type: project
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/timber-and-plywood/decking/composite-decking
      - concept://placemakers/timber-and-plywood/decking/radiata-decking
      - concept://placemakers/timber-and-plywood/decking/hardwood-decking
      - concept://placemakers/timber-and-plywood/decking/decking-accessories
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.deck_material
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/projects/deck-build
  contentHash: 154e3207704a4e4487c6934ca8b8155112abb185c5ecd12a6058aa6e4e7ed093
  customerPhrases:
    - build a deck
    - building a deck
    - new deck
    - deck build
    - deck project
    - build my deck
    - building my deck
    - construct a deck
    - build a new deck
  description: Building or extending a deck.
  discriminators:
    - clarifyFirst: false
      factKey: deck_material
      questionRef: q.deck_material
      valueMap: {}
    - clarifyFirst: false
      factKey: deck_size
      questionRef: q.deck_size
      valueMap: {}
  evidenceRefs:
    - src-authoring-proposal
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          id: deck-build
          section: projects
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: project
  lifecycle:
    status: active_draft
  name: Deck build
  requiredFacts:
    - factKey: deck_material
      importance: high
    - factKey: deck_size
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Decking
        - Composite Decking
      - - Timber & Plywood
        - Decking
        - Radiata Decking
      - - Timber & Plywood
        - Decking
        - Hardwood Decking
      - - Timber & Plywood
        - Decking
        - Decking Accessories
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: project
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: low
    contentHash: 97630e67c4b8623fc3a652ff98e9bcc7aa2696472dd2ca7579600fca0120fe1e
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/projects/deck-build
    relationshipId: rel-xs-deck_project_extras-1
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/fastenings-and-general-hardware/fastenings/wood-screws
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: c34d080eb3bafa7e374769b9abf752b5dc18ac47d24f2895f714baa60d3bd8b2
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/projects/deck-build
    relationshipId: rel-xs-deck_project_extras-2
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/paint-and-decorating/paint/woodcare
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: 7a87bf1988617e2de7252d9d1295487f108069ca363629d5b0317ceb89718f0c
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/projects/deck-build
    relationshipId: rel-xs-deck_project_extras-3
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/outdoor-cleaners
    type: cross_sell
---
# Deck build

Building or extending a deck.

## Related concepts

* cross sell: [Wood Screws](../fastenings-and-general-hardware/fastenings/wood-screws.md)
* cross sell: [Woodcare](../paint-and-decorating/paint/woodcare.md)
* cross sell: [Outdoor Cleaners](../cleaning-and-consumables/cleaners-and-cleaning-equipment/outdoor-cleaners.md)
