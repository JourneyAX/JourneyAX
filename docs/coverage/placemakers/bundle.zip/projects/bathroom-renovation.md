---
description: Planning a new or renovated bathroom or ensuite.
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Bathroom renovation
type: project
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/vanities
      - concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/tapware-and-showering
      - concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/showers
      - concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/baths
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.project_scope
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/projects/bathroom-renovation
  contentHash: d886ba92687f0ae06441a6c5e36df37a9200e29bb25aaae371fe706a2656bdf8
  customerPhrases:
    - bathroom renovation
    - renovate my bathroom
    - bathroom makeover
    - new bathroom
    - ensuite renovation
    - bathroom remodel
    - bathroom reno
    - renovating my bathroom
    - redo my bathroom
    - update my bathroom
  description: Planning a new or renovated bathroom or ensuite.
  discriminators:
    - clarifyFirst: false
      factKey: project_scope
      questionRef: q.project_scope
      valueMap: {}
    - clarifyFirst: false
      factKey: room_dimensions
      questionRef: q.room_dimensions
      valueMap: {}
    - clarifyFirst: false
      factKey: bathroom_features
      questionRef: q.bathroom_features
      valueMap: {}
  evidenceRefs:
    - src-authoring-proposal
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          id: bathroom-renovation
          section: projects
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  journeyRef:
    journeyId: placemakers_plan_your_space
  lens: project
  lifecycle:
    status: active_draft
  name: Bathroom renovation
  requiredFacts:
    - factKey: project_scope
      importance: high
    - factKey: room_dimensions
      importance: medium
    - factKey: bathroom_features
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Bathrooms & Plumbing
        - Bathrooms & Accessories
        - Vanities
      - - Bathrooms & Plumbing
        - Bathrooms & Accessories
        - Tapware & Showering
      - - Bathrooms & Plumbing
        - Bathrooms & Accessories
        - Showers
      - - Bathrooms & Plumbing
        - Bathrooms & Accessories
        - Baths
      - - Bathrooms & Plumbing
        - Bathrooms & Accessories
        - Toilets
      - - Bathrooms & Plumbing
        - Bathrooms & Accessories
        - Basins
      - - Bathrooms & Plumbing
        - Bathrooms & Accessories
        - Mirrors
      - - Bathrooms & Plumbing
        - Bathrooms & Accessories
        - Heated Towel Rails
      - - Bathrooms & Plumbing
        - Bathrooms & Accessories
        - Bathroom Accessories
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: project
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: low
    contentHash: 9f44eb3f6f642939bded2d3287b6a1299c9f61729f5c63118d32efc4d20677f3
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/projects/bathroom-renovation
    relationshipId: rel-xs-bathroom_project_extras-1
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/heated-towel-rails
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: af5aa19057a03aef6dce31de4e124286ae091d9755f39d67e90c008174914404
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/projects/bathroom-renovation
    relationshipId: rel-xs-bathroom_project_extras-2
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/mirrors
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: 4ec70748bb6187b00eab4fd3bfbc1519d0ae787bba1e3c2ef3922fc8784002d4
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/projects/bathroom-renovation
    relationshipId: rel-xs-bathroom_project_extras-3
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/building-products/wet-wall-linings
    type: cross_sell
---
# Bathroom renovation

Planning a new or renovated bathroom or ensuite.

## Related concepts

* cross sell: [Heated Towel Rails](../bathrooms-and-plumbing/bathrooms-and-accessories/heated-towel-rails.md)
* cross sell: [Mirrors](../bathrooms-and-plumbing/bathrooms-and-accessories/mirrors.md)
* cross sell: [Wet Wall Linings](../building-products/wet-wall-linings.md)
