---
description: Updating or renovating a kitchen.
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Kitchen update
type: project
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/kitchens-and-laundry/kitchens/kitchen-sinks
      - concept://placemakers/kitchens-and-laundry/kitchens/kitchen-tapware
      - concept://placemakers/kitchens-and-laundry/kitchens/kitchen-benchtops
      - concept://placemakers/kitchens-and-laundry/kitchens/kitchen-splashbacks
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.project_scope
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/projects/kitchen-update
  contentHash: b52bd3aa2f206cd1f492e65ffa6d14a79760f679a93babff5284bf67cc6858f1
  customerPhrases:
    - kitchen update
    - renovate my kitchen
    - kitchen renovation
    - new kitchen
    - kitchen makeover
    - kitchen reno
    - renovating my kitchen
    - redo my kitchen
  description: Updating or renovating a kitchen.
  discriminators:
    - clarifyFirst: false
      factKey: project_scope
      questionRef: q.project_scope
      valueMap: {}
    - clarifyFirst: false
      factKey: kitchen_features
      questionRef: q.kitchen_features
      valueMap: {}
  evidenceRefs:
    - src-authoring-proposal
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          id: kitchen-update
          section: projects
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  journeyRef:
    journeyId: placemakers_plan_your_space
  lens: project
  lifecycle:
    status: active_draft
  name: Kitchen update
  requiredFacts:
    - factKey: project_scope
      importance: high
    - factKey: kitchen_features
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Kitchens & Laundry
        - Kitchens
        - Kitchen Sinks
      - - Kitchens & Laundry
        - Kitchens
        - Kitchen Tapware
      - - Kitchens & Laundry
        - Kitchens
        - Kitchen Benchtops
      - - Kitchens & Laundry
        - Kitchens
        - Kitchen Splashbacks
      - - Kitchens & Laundry
        - Kitchens
        - Kitchen Appliances
      - - Kitchens & Laundry
        - Kitchens
        - Kitchen Hardware & Accessories
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: project
  version: 1
x-journeyax-relationships: []
---
# Kitchen update

Updating or renovating a kitchen.
