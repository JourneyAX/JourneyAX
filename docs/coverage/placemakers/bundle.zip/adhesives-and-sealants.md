---
description: 'Adhesives & Sealants: 430 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Adhesives & Sealants
type: department
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/adhesives-and-sealants/adhesives-and-sealants
      - concept://placemakers/adhesives-and-sealants/caulks-and-sealants
      - concept://placemakers/adhesives-and-sealants/repair-products
      - concept://placemakers/adhesives-and-sealants/foam-products
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_adhesives_and_sealants
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/adhesives-and-sealants
  contentHash: 3752b83b74f8fff4e6f55be2864811cc9a91d0e50b983b0e957cf4abdc5b41f0
  customerPhrases:
    - heavy duty caulking gun
    - polymer modified mortar
    - gap sealer
    - ms polymer sealant
    - fire stop sealant
    - sanitary silicone
    - sealant gun
    - modified silicone
  description: 'Adhesives & Sealants: 430 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_adhesives_and_sealants
      questionRef: q.nav_adhesives_and_sealants
      valueMap:
        adhesives: concept://placemakers/adhesives-and-sealants/adhesives
        adhesives-and-sealants: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants
        caulks-and-sealants: concept://placemakers/adhesives-and-sealants/caulks-and-sealants
        foam-products: concept://placemakers/adhesives-and-sealants/foam-products
        repair-products: concept://placemakers/adhesives-and-sealants/repair-products
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-619e187c3e84
    - src-doc-c0c065ec1dc2
    - src-doc-0dc46e04e722
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Adhesives & Sealants
          path:
            - Adhesives & Sealants
          products: 430
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Adhesives & Sealants
  requiredFacts:
    - factKey: nav_adhesives_and_sealants
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Adhesives & Sealants
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - adhesive
    - adhesives
    - caulks and sealant
    - caulks and sealants
    - foam product
    - foam products
    - repair product
    - repair products
    - sealants
  tenantId: placemakers
  type: department
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - adhesive
  - adhesives
  - caulks and sealant
  - caulks and sealants
  - foam product
  - foam products
  - repair product
  - repair products
  - sealants
---
# Adhesives & Sealants

Adhesives & Sealants: 430 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
