---
description: 'Outdoor & Landscaping: 2,763 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Outdoor & Landscaping
type: department
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/outdoor-and-landscaping/garden-and-landscaping
      - concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber
      - concept://placemakers/outdoor-and-landscaping/translucent-roofing
      - concept://placemakers/outdoor-and-landscaping/bbqs-furniture-and-sun-shade
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_outdoor_and_landscaping
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/outdoor-and-landscaping
  contentHash: 3df2d3d049ba358378ab729a71f120f55d7bbc58d6ab7a12e1ce04363272376a
  customerPhrases:
    - windbreak mesh
    - barbecue fuel
  description: 'Outdoor & Landscaping: 2,763 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_outdoor_and_landscaping
      questionRef: q.nav_outdoor_and_landscaping
      valueMap:
        bbqs-furniture-and-sun-shade: concept://placemakers/outdoor-and-landscaping/bbqs-furniture-and-sun-shade
        fencing-and-netting-non-timber: concept://placemakers/outdoor-and-landscaping/fencing-and-netting-non-timber
        garden-and-landscaping: concept://placemakers/outdoor-and-landscaping/garden-and-landscaping
        leisure-products: concept://placemakers/outdoor-and-landscaping/leisure-products
        translucent-roofing: concept://placemakers/outdoor-and-landscaping/translucent-roofing
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-55b82d4d4e23
    - src-doc-68f0a6e32c6a
    - src-doc-6d4ca31be1b4
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Outdoor & Landscaping
          path:
            - Outdoor & Landscaping
          products: 2763
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Outdoor & Landscaping
  requiredFacts:
    - factKey: nav_outdoor_and_landscaping
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Outdoor & Landscaping
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - landscaping
    - landscapings
    - outdoor
    - outdoors
  tenantId: placemakers
  type: department
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - landscaping
  - landscapings
  - outdoor
  - outdoors
---
# Outdoor & Landscaping

Outdoor & Landscaping: 2,763 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
