---
description: 'Services & Packages > Room Solutions > Bathroom Packages: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Services & Packages > Room Solutions > Bathroom Packages
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/other-products/services-and-packages-room-solutions-bathroom-packages
  contentHash: 99b87e96d74833a03081076e9c9c8ce318882fa00af9944c4e705fd0be4af835
  customerPhrases: []
  description: 'Services & Packages > Room Solutions > Bathroom Packages: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Services & Packages > Room Solutions > Bathroom Packages
          path:
            - Other products
            - Services & Packages > Room Solutions > Bathroom Packages
          products: 1
          scopedBy: name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Services & Packages > Room Solutions > Bathroom Packages
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds:
      - Services & Packages > Room Solutions > Bathroom Packages
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - packages room solutions bathroom package
    - packages room solutions bathroom packages
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: ab400b613f851c34a3b541521fe266433c7fe1fedb441e71bfcc064671ff5fdb
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/other-products/services-and-packages-room-solutions-bathroom-packages
    relationshipId: rel-other-products--services-and-packages-room-solutions-bathroom-packages-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/other-products
    type: child_of
x-journeyax-synonyms:
  - packages room solutions bathroom package
  - packages room solutions bathroom packages
---
# Services & Packages > Room Solutions > Bathroom Packages

Services & Packages > Room Solutions > Bathroom Packages: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Other products](../other-products.md)
