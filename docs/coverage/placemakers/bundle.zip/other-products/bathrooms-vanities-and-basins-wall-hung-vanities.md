---
description: 'Bathrooms > Vanities & Basins > Wall Hung Vanities: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Bathrooms > Vanities & Basins > Wall Hung Vanities
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/other-products/bathrooms-vanities-and-basins-wall-hung-vanities
  contentHash: 7a076fe2f467373821b7bfa92e17bf7dd9ccbeb9167ce06c9d7435d74da6834f
  customerPhrases: []
  description: 'Bathrooms > Vanities & Basins > Wall Hung Vanities: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Bathrooms > Vanities & Basins > Wall Hung Vanities
          path:
            - Other products
            - Bathrooms > Vanities & Basins > Wall Hung Vanities
          products: 1
          scopedBy: name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Bathrooms > Vanities & Basins > Wall Hung Vanities
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds:
      - Bathrooms > Vanities & Basins > Wall Hung Vanities
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - basins wall hung vanities
    - basins wall hung vanity
    - bathrooms vanities
    - bathrooms vanity
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: bc362b0e6f84a399b4464c3966739155942acfe8ecf6bf87a3186105ab4298ba
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/other-products/bathrooms-vanities-and-basins-wall-hung-vanities
    relationshipId: rel-other-products--bathrooms-vanities-and-basins-wall-hung-vanities-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/other-products
    type: child_of
x-journeyax-synonyms:
  - basins wall hung vanities
  - basins wall hung vanity
  - bathrooms vanities
  - bathrooms vanity
---
# Bathrooms > Vanities & Basins > Wall Hung Vanities

Bathrooms > Vanities & Basins > Wall Hung Vanities: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Other products](../other-products.md)
