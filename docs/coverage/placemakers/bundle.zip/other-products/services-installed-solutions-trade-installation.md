---
description: 'Services > Installed Solutions > Trade Installation: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Services > Installed Solutions > Trade Installation
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/other-products/services-installed-solutions-trade-installation
  contentHash: 7be780763ecdbd36244dba73a98ba4caa7d30b86e9de3454f3ef9a3ddc95fb52
  customerPhrases: []
  description: 'Services > Installed Solutions > Trade Installation: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Services > Installed Solutions > Trade Installation
          path:
            - Other products
            - Services > Installed Solutions > Trade Installation
          products: 1
          scopedBy: name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Services > Installed Solutions > Trade Installation
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds:
      - Services > Installed Solutions > Trade Installation
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - installation
    - installations
    - services installed solutions trade installations
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: b12d13450a9288aec0d80894aac9a69171ecd7bcdb8082db701d7c67524ed861
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/other-products/services-installed-solutions-trade-installation
    relationshipId: rel-other-products--services-installed-solutions-trade-installation-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/other-products
    type: child_of
x-journeyax-synonyms:
  - installation
  - installations
  - services installed solutions trade installations
---
# Services > Installed Solutions > Trade Installation

Services > Installed Solutions > Trade Installation: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Other products](../other-products.md)
