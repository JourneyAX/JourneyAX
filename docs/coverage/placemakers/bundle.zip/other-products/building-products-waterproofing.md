---
description: 'Building Products > Waterproofing: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Building Products > Waterproofing
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/other-products/building-products-waterproofing
  contentHash: 4a5e4d35fca039a61241c5839025c6fb4c21646eed997199e31ce6f96ef66844
  customerPhrases: []
  description: 'Building Products > Waterproofing: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Building Products > Waterproofing
          path:
            - Other products
            - Building Products > Waterproofing
          products: 1
          scopedBy: name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Building Products > Waterproofing
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds:
      - Building Products > Waterproofing
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - building products waterproofings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: f99ff2aec8520c035fa157f60336e9d4e002e304111f2f78415f304fc5df167d
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/other-products/building-products-waterproofing
    relationshipId: rel-other-products--building-products-waterproofing-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/other-products
    type: child_of
x-journeyax-synonyms:
  - building products waterproofings
---
# Building Products > Waterproofing

Building Products > Waterproofing: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Other products](../other-products.md)
