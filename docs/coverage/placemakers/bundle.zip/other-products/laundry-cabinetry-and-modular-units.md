---
description: 'Laundry Cabinetry & Modular Units: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Laundry Cabinetry & Modular Units
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/other-products/laundry-cabinetry-and-modular-units
  contentHash: d7c9d994829d6be8ea10d1eaddad79e09d1a0e445e1ccba047a3ea3aca407be2
  customerPhrases: []
  description: 'Laundry Cabinetry & Modular Units: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Laundry Cabinetry & Modular Units
          path:
            - Other products
            - Laundry Cabinetry & Modular Units
          products: 1
          scopedBy: name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Laundry Cabinetry & Modular Units
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds:
      - Laundry Cabinetry & Modular Units
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - modular unit
    - modular units
    - unit
    - units
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: c900b95c20649bf314a43e81071badd1bac1987e656fcb5b2e19361fcdb38baf
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/other-products/laundry-cabinetry-and-modular-units
    relationshipId: rel-other-products--laundry-cabinetry-and-modular-units-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/other-products
    type: child_of
x-journeyax-synonyms:
  - modular unit
  - modular units
  - unit
  - units
---
# Laundry Cabinetry & Modular Units

Laundry Cabinetry & Modular Units: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Other products](../other-products.md)
