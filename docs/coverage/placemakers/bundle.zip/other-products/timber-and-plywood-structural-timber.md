---
description: 'Timber & Plywood > Structural Timber: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Timber & Plywood > Structural Timber
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/other-products/timber-and-plywood-structural-timber
  contentHash: fb6f5fcd8d8733d5ca43ee798bcc4ab2555acf316d222883bfb61ea29bfbbfc1
  customerPhrases: []
  description: 'Timber & Plywood > Structural Timber: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Timber & Plywood > Structural Timber
          path:
            - Other products
            - Timber & Plywood > Structural Timber
          products: 1
          scopedBy: name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Timber & Plywood > Structural Timber
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds:
      - Timber & Plywood > Structural Timber
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - plywood structural timber
    - plywood structural timbers
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: c0a021aa83f3cfbd4de9d37ecce87f0e8ce397e059ed70dab77ffca8e05274b6
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/other-products/timber-and-plywood-structural-timber
    relationshipId: rel-other-products--timber-and-plywood-structural-timber-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/other-products
    type: child_of
x-journeyax-synonyms:
  - plywood structural timber
  - plywood structural timbers
---
# Timber & Plywood > Structural Timber

Timber & Plywood > Structural Timber: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Other products](../other-products.md)
