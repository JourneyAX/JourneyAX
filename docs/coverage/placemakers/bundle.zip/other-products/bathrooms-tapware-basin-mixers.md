---
description: 'Bathrooms > Tapware > Basin Mixers: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Bathrooms > Tapware > Basin Mixers
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/other-products/bathrooms-tapware-basin-mixers
  contentHash: 0ed002e0154b90cc7bb7041d5ce6882a456a7c80c205fbd58473ae653988835a
  customerPhrases: []
  description: 'Bathrooms > Tapware > Basin Mixers: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Bathrooms > Tapware > Basin Mixers
          path:
            - Other products
            - Bathrooms > Tapware > Basin Mixers
          products: 1
          scopedBy: name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Bathrooms > Tapware > Basin Mixers
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds:
      - Bathrooms > Tapware > Basin Mixers
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - bathrooms tapware basin mixer
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 8fee462f8bc2b17ea94c0f82103254f7844753384ff18caa946bdb325f4d7061
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/other-products/bathrooms-tapware-basin-mixers
    relationshipId: rel-other-products--bathrooms-tapware-basin-mixers-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/other-products
    type: child_of
x-journeyax-synonyms:
  - bathrooms tapware basin mixer
---
# Bathrooms > Tapware > Basin Mixers

Bathrooms > Tapware > Basin Mixers: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Other products](../other-products.md)
