---
description: 'Services & Packages > Room Solutions > Laundry Packages: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Services & Packages > Room Solutions > Laundry Packages
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/other-products/services-and-packages-room-solutions-laundry-packages
  contentHash: 090e0e0a856c24b69e91f61262590f6aa0a8fcfae48b3768cd17c2a5befa8fc3
  customerPhrases: []
  description: 'Services & Packages > Room Solutions > Laundry Packages: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Services & Packages > Room Solutions > Laundry Packages
          path:
            - Other products
            - Services & Packages > Room Solutions > Laundry Packages
          products: 1
          scopedBy: name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Services & Packages > Room Solutions > Laundry Packages
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds:
      - Services & Packages > Room Solutions > Laundry Packages
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - packages room solutions laundry package
    - packages room solutions laundry packages
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 76369a3e1161b0784acd7eba4b21c528020854c761df4664131d38b9bcadb665
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/other-products/services-and-packages-room-solutions-laundry-packages
    relationshipId: rel-other-products--services-and-packages-room-solutions-laundry-packages-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/other-products
    type: child_of
x-journeyax-synonyms:
  - packages room solutions laundry package
  - packages room solutions laundry packages
---
# Services & Packages > Room Solutions > Laundry Packages

Services & Packages > Room Solutions > Laundry Packages: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Other products](../other-products.md)
