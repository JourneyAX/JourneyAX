---
description: 'Services > Design Consultations > Bathroom Design: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Services > Design Consultations > Bathroom Design
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/other-products/services-design-consultations-bathroom-design
  contentHash: 892a5b731dbebef6f303a9788adf8a3e8be880e41a3c285a17e0f90c8daf5793
  customerPhrases: []
  description: 'Services > Design Consultations > Bathroom Design: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Services > Design Consultations > Bathroom Design
          path:
            - Other products
            - Services > Design Consultations > Bathroom Design
          products: 1
          scopedBy: name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Services > Design Consultations > Bathroom Design
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds:
      - Services > Design Consultations > Bathroom Design
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - design
    - designs
    - services design consultations bathroom designs
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 44f1a8d44cf02887ee298f9781caf1bc513bbca2a90b3d0cf69afd34a818121e
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/other-products/services-design-consultations-bathroom-design
    relationshipId: rel-other-products--services-design-consultations-bathroom-design-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/other-products
    type: child_of
x-journeyax-synonyms:
  - design
  - designs
  - services design consultations bathroom designs
---
# Services > Design Consultations > Bathroom Design

Services > Design Consultations > Bathroom Design: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Other products](../other-products.md)
