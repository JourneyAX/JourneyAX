---
description: 'Building Products > Plasterboard > GIB Aqualine: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Building Products > Plasterboard > GIB Aqualine
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/other-products/building-products-plasterboard-gib-aqualine
  contentHash: e1e7b6fb32412d6f37abd827ddc30c4548dbbb695b876c6c8c0daf6c26fe06e9
  customerPhrases: []
  description: 'Building Products > Plasterboard > GIB Aqualine: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Building Products > Plasterboard > GIB Aqualine
          path:
            - Other products
            - Building Products > Plasterboard > GIB Aqualine
          products: 1
          scopedBy: name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Building Products > Plasterboard > GIB Aqualine
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds:
      - Building Products > Plasterboard > GIB Aqualine
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - aqualine
    - aqualines
    - building products plasterboard gib aqualines
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 324979409597a0fe3fe246fe3d5a1f713ae4e94d5d47b7b06f3335a11697b968
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/other-products/building-products-plasterboard-gib-aqualine
    relationshipId: rel-other-products--building-products-plasterboard-gib-aqualine-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/other-products
    type: child_of
x-journeyax-synonyms:
  - aqualine
  - aqualines
  - building products plasterboard gib aqualines
---
# Building Products > Plasterboard > GIB Aqualine

Building Products > Plasterboard > GIB Aqualine: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Other products](../other-products.md)
