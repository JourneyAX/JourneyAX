---
description: 'Fixings & Fasteners > Screws > Decking Screws: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Fixings & Fasteners > Screws > Decking Screws
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/other-products/fixings-and-fasteners-screws-decking-screws
  contentHash: f353f80bb1f8253ac02a028d3510e578ddfbe02bf32facf6407932979303ecd6
  customerPhrases: []
  description: 'Fixings & Fasteners > Screws > Decking Screws: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Fixings & Fasteners > Screws > Decking Screws
          path:
            - Other products
            - Fixings & Fasteners > Screws > Decking Screws
          products: 1
          scopedBy: name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Fixings & Fasteners > Screws > Decking Screws
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds:
      - Fixings & Fasteners > Screws > Decking Screws
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - fasteners screws decking screw
    - fasteners screws decking screws
    - fixing
    - fixings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 70e1ba99eac766606a123f9eeb2d1fcae86a02cb718ecba05461fa0178b26587
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/other-products/fixings-and-fasteners-screws-decking-screws
    relationshipId: rel-other-products--fixings-and-fasteners-screws-decking-screws-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/other-products
    type: child_of
x-journeyax-synonyms:
  - fasteners screws decking screw
  - fasteners screws decking screws
  - fixing
  - fixings
---
# Fixings & Fasteners > Screws > Decking Screws

Fixings & Fasteners > Screws > Decking Screws: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Other products](../other-products.md)
