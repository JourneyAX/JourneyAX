---
description: 'Laundry Tapware & Plumbing: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Laundry Tapware & Plumbing
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/other-products/laundry-tapware-and-plumbing
  contentHash: 213cf9983b677f33c16b9f1ea09bb56c9d5361b70f3c962909d4da036324aad4
  customerPhrases: []
  description: 'Laundry Tapware & Plumbing: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Laundry Tapware & Plumbing
          path:
            - Other products
            - Laundry Tapware & Plumbing
          products: 1
          scopedBy: name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Laundry Tapware & Plumbing
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds:
      - Laundry Tapware & Plumbing
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - laundry tapware
    - laundry tapwares
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 4c9a2ef8d3a0485fefca55c58e632948c24cce1cf8a1d8ead953e1d7672544ce
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/other-products/laundry-tapware-and-plumbing
    relationshipId: rel-other-products--laundry-tapware-and-plumbing-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/other-products
    type: child_of
x-journeyax-synonyms:
  - laundry tapware
  - laundry tapwares
---
# Laundry Tapware & Plumbing

Laundry Tapware & Plumbing: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Other products](../other-products.md)
