---
description: 'Tools > Tool Kits > Installation Tools: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Tools > Tool Kits > Installation Tools
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/other-products/tools-tool-kits-installation-tools
  contentHash: a81c1fe90b29e81e3beaaac28c8ddb42a530416b34a243e1828fdd88017a6165
  customerPhrases: []
  description: 'Tools > Tool Kits > Installation Tools: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Tools > Tool Kits > Installation Tools
          path:
            - Other products
            - Tools > Tool Kits > Installation Tools
          products: 1
          scopedBy: name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Tools > Tool Kits > Installation Tools
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds:
      - Tools > Tool Kits > Installation Tools
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - tools tool kits installation tool
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: bef53c257ce670c532385fb92f154f708e9324d79f58838aed0d5350a24cc7fd
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/other-products/tools-tool-kits-installation-tools
    relationshipId: rel-other-products--tools-tool-kits-installation-tools-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/other-products
    type: child_of
x-journeyax-synonyms:
  - tools tool kits installation tool
---
# Tools > Tool Kits > Installation Tools

Tools > Tool Kits > Installation Tools: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Other products](../other-products.md)
