---
description: 'Paint & Decorating: 1,347 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Paint & Decorating
type: department
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/paint-and-decorating/paint
      - concept://placemakers/paint-and-decorating/paint-accessories
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_paint_and_decorating
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/paint-and-decorating
  contentHash: 76a3849548e37c3b7914c6b3264c7048c9af6b0207902f130ca5971c36e10574
  customerPhrases: []
  description: 'Paint & Decorating: 1,347 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_paint_and_decorating
      questionRef: q.nav_paint_and_decorating
      valueMap:
        paint: concept://placemakers/paint-and-decorating/paint
        paint-accessories: concept://placemakers/paint-and-decorating/paint-accessories
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-a4a35ac0e673
    - src-doc-faf796828143
    - src-doc-7757144255e8
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Paint & Decorating
          path:
            - Paint & Decorating
          products: 1347
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Paint & Decorating
  requiredFacts:
    - factKey: nav_paint_and_decorating
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Paint & Decorating
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - decorating
    - decoratings
    - paints
  tenantId: placemakers
  type: department
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - decorating
  - decoratings
  - paints
---
# Paint & Decorating

Paint & Decorating: 1,347 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
