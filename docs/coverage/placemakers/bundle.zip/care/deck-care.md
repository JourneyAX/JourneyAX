---
description: Cleaning and maintaining a deck.
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Deck care
type: care
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/care/deck-care
  contentHash: 52ba5cc261b866f6c78c2f76ceffb789e7fe0ecd6fe76a4f249f8091c62a818d
  customerPhrases:
    - deck care
    - clean my deck
    - maintain my deck
    - oil my deck
    - deck maintenance
  description: Cleaning and maintaining a deck.
  discriminators: []
  evidenceRefs:
    - src-authoring-proposal
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          id: deck-care
          section: care
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: care
  lifecycle:
    status: active_draft
  name: Deck care
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Decking
        - Composite Decking
      - - Timber & Plywood
        - Decking
        - Radiata Decking
      - - Timber & Plywood
        - Decking
        - Hardwood Decking
      - - Paint & Decorating
        - Paint
        - Woodcare
      - - Cleaning & Consumables
        - Cleaners & Cleaning Equipment
        - Outdoor Cleaners
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: care
  version: 1
x-journeyax-relationships:
  - claimClasses:
      - care_safety
    confidence: low
    contentHash: 781d49bac04ad48859f77d1b99b052b40b20f49a9232083d6ef54f8ea468e942
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: care
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/care/deck-care
    relationshipId: rel-care-deck_care-placemakers-cleaning-and-consumables-cleaners-and-cleaning-equipment-outdoor-cleaners
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: recommended
    to: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/outdoor-cleaners
    type: care_for
  - claimClasses:
      - care_safety
    confidence: low
    contentHash: fa9884eabaf4d9be4128d5a9dbc2024f015f0cb6d40b428343eb1c51788f5515
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: care
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/care/deck-care
    relationshipId: rel-care-deck_care-placemakers-paint-and-decorating-paint-woodcare
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: recommended
    to: concept://placemakers/paint-and-decorating/paint/woodcare
    type: care_for
  - claimClasses:
      - care_safety
    confidence: low
    contentHash: 049f57345f79b8c13c989d791fbcd374fc8dfbd145b15958fc2a1133928aa532
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: care
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/care/deck-care
    relationshipId: rel-care-deck_care-placemakers-timber-and-plywood-decking-composite-decking
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: recommended
    to: concept://placemakers/timber-and-plywood/decking/composite-decking
    type: care_for
  - claimClasses:
      - care_safety
    confidence: low
    contentHash: e36f269d01e4f6ecf295fb1a9ec5c0c6bc7878f0ac414e3c78b8054b4cc826c7
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: care
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/care/deck-care
    relationshipId: rel-care-deck_care-placemakers-timber-and-plywood-decking-hardwood-decking
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: recommended
    to: concept://placemakers/timber-and-plywood/decking/hardwood-decking
    type: care_for
  - claimClasses:
      - care_safety
    confidence: low
    contentHash: 12550be7e2ede956fe7813ac28c08c04e9c81d425e8b757c41deb1e20a7407a8
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: care
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/care/deck-care
    relationshipId: rel-care-deck_care-placemakers-timber-and-plywood-decking-radiata-decking
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: recommended
    to: concept://placemakers/timber-and-plywood/decking/radiata-decking
    type: care_for
---
# Deck care

Cleaning and maintaining a deck.

## Related concepts

* care for: [Outdoor Cleaners](../cleaning-and-consumables/cleaners-and-cleaning-equipment/outdoor-cleaners.md)
* care for: [Woodcare](../paint-and-decorating/paint/woodcare.md)
* care for: [Composite Decking](../timber-and-plywood/decking/composite-decking.md)
* care for: [Hardwood Decking](../timber-and-plywood/decking/hardwood-decking.md)
* care for: [Radiata Decking](../timber-and-plywood/decking/radiata-decking.md)
