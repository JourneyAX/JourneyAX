---
description: 'Bathrooms & Accessories: 13,478 products across 9 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Bathrooms & Accessories
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/tapware-and-showering
      - concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/vanities
      - concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/showers
      - concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/bathroom-accessories
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_bathrooms_and_plumbing_bathrooms_and_accessories
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories
  contentHash: 5b663b8a029c9dfec5a97af7cabf35ca440f2d9c541a07406e2e8efe520f7d71
  customerPhrases:
    - acrylic bath
    - drop in bath
    - back to wall bath
    - bath with upstand
  description: 'Bathrooms & Accessories: 13,478 products across 9 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_bathrooms_and_plumbing_bathrooms_and_accessories
      questionRef: q.nav_bathrooms_and_plumbing_bathrooms_and_accessories
      valueMap:
        basins: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/basins
        bathroom-accessories: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/bathroom-accessories
        baths: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/baths
        heated-towel-rails: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/heated-towel-rails
        mirrors: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/mirrors
        showers: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/showers
        tapware-and-showering: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/tapware-and-showering
        toilets: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/toilets
        vanities: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/vanities
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-3e7cb73cd07a
    - src-doc-f1dacc8c05db
    - src-doc-d767079fdeff
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Bathrooms & Accessories
          path:
            - Bathrooms & Plumbing
            - Bathrooms & Accessories
          products: 13478
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Bathrooms & Accessories
  requiredFacts:
    - factKey: nav_bathrooms_and_plumbing_bathrooms_and_accessories
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Bathrooms & Plumbing
        - Bathrooms & Accessories
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 86760eb10f6016ba24d3f7b24de2d5c821e37a0ccbf274c138f7c57ab246a854
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories
    relationshipId: rel-bathrooms-and-plumbing--bathrooms-and-accessories-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/bathrooms-and-plumbing
    type: child_of
---
# Bathrooms & Accessories

Bathrooms & Accessories: 13,478 products across 9 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Bathrooms & Plumbing](../bathrooms-and-plumbing.md)
