---
description: 'Plumbing: 1,778 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Plumbing (Bathrooms & Plumbing)
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/bathrooms-and-plumbing/plumbing/pumps-tanks-and-filtration
      - concept://placemakers/bathrooms-and-plumbing/plumbing/pvc-pipe-and-fittings
      - concept://placemakers/bathrooms-and-plumbing/plumbing/traps-and-wastes
      - concept://placemakers/bathrooms-and-plumbing/plumbing/piping-systems-and-fittings
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_bathrooms_and_plumbing_plumbing
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/bathrooms-and-plumbing/plumbing
  contentHash: d4fdcd2710362d4bcef128acb7a50941a82eb951ab930b155eb3c694f65612d6
  customerPhrases:
    - pipe saddle clip
    - floor waste
  description: 'Plumbing: 1,778 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_bathrooms_and_plumbing_plumbing
      questionRef: q.nav_bathrooms_and_plumbing_plumbing
      valueMap:
        hot-water: concept://placemakers/bathrooms-and-plumbing/plumbing/hot-water
        piping-systems-and-fittings: concept://placemakers/bathrooms-and-plumbing/plumbing/piping-systems-and-fittings
        pumps-tanks-and-filtration: concept://placemakers/bathrooms-and-plumbing/plumbing/pumps-tanks-and-filtration
        pvc-pipe-and-fittings: concept://placemakers/bathrooms-and-plumbing/plumbing/pvc-pipe-and-fittings
        spare-parts: concept://placemakers/bathrooms-and-plumbing/plumbing/spare-parts
        surface-drainage: concept://placemakers/bathrooms-and-plumbing/plumbing/surface-drainage
        traps-and-wastes: concept://placemakers/bathrooms-and-plumbing/plumbing/traps-and-wastes
        valves: concept://placemakers/bathrooms-and-plumbing/plumbing/valves
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-43e3368eb3b7
    - src-doc-2cba1ec85428
    - src-doc-33564c23dbc6
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Plumbing
          path:
            - Bathrooms & Plumbing
            - Plumbing
          products: 1778
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Plumbing (Bathrooms & Plumbing)
  requiredFacts:
    - factKey: nav_bathrooms_and_plumbing_plumbing
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Bathrooms & Plumbing
        - Plumbing
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - fitting
    - fittings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 53d6d36d52dc2c65cef0dfef1199af707c6b3c104114986477728bf984a2d662
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/plumbing
    relationshipId: rel-bathrooms-and-plumbing--plumbing-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/bathrooms-and-plumbing
    type: child_of
x-journeyax-synonyms:
  - fitting
  - fittings
---
# Plumbing (Bathrooms & Plumbing)

Plumbing: 1,778 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Bathrooms & Plumbing](../bathrooms-and-plumbing.md)
