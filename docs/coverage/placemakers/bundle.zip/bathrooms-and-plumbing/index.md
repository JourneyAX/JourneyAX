# bathrooms-and-plumbing

* [Bathrooms & Accessories](bathrooms-and-accessories.md) - Bathrooms & Accessories: 13,478 products across 9 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Plumbing (Bathrooms & Plumbing)](plumbing.md) - Plumbing: 1,778 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [bathrooms-and-accessories](bathrooms-and-accessories/) - Knowledge and references
* [plumbing](plumbing/) - Knowledge and references
