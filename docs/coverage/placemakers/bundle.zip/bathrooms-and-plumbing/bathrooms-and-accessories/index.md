# bathrooms-and-plumbing/bathrooms-and-accessories

* [Basins](basins.md) - Basins: 414 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Bathroom Accessories](bathroom-accessories.md) - Bathroom Accessories: 1,264 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Baths](baths.md) - Baths: 301 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Heated Towel Rails](heated-towel-rails.md) - Heated Towel Rails: 183 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Mirrors](mirrors.md) - Mirrors: 165 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Showers](showers.md) - Showers: 2,764 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Tapware & Showering](tapware-and-showering.md) - Tapware & Showering: 4,547 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Toilets](toilets.md) - Toilets: 300 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Vanities](vanities.md) - Vanities: 3,540 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
