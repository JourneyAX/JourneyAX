---
description: 'Vanities: 3,540 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Vanities
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/vanities
  contentHash: c5738b662d605b8908bb7d0da57d22f28192309dac3326708aa4820bbcd21e91
  customerPhrases:
    - floating vanity
    - wall hung vanity
    - floor mounted vanity
    - vanity benchtop
    - bathroom cabinet
    - hand basin cabinet
    - tall bathroom cupboard
    - mirrored medicine cabinet
  description: 'Vanities: 3,540 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-f1dacc8c05db
    - src-doc-13b5eb6f6666
    - src-doc-2608b99baaf2
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:58:08.967Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Vanities
          path:
            - Bathrooms & Plumbing
            - Bathrooms & Accessories
            - Vanities
          products: 3540
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Vanities
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Bathrooms & Plumbing
        - Bathrooms & Accessories
        - Vanities
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - vanity
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: f17e1deb136674611bb6eedfdb7d31088b0072e32a3983cde6c115bc08e326c9
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/vanities
    relationshipId: rel-bathrooms-and-plumbing--bathrooms-and-accessories--vanities-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories
    type: child_of
  - claimClasses: []
    confidence: low
    contentHash: d08bf359194311837e9e90224ab39bfaac2df1e9f58123205d50a0440144967e
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/vanities
    relationshipId: rel-xs-vanity_extras-1
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/tapware-and-showering
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: 2b130c76323fba3be62b9376256d37f6373a308c32f17bdd18c529209259b85a
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/vanities
    relationshipId: rel-xs-vanity_extras-2
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/mirrors
    type: cross_sell
x-journeyax-synonyms:
  - vanity
---
# Vanities

Vanities: 3,540 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Bathrooms & Accessories](../bathrooms-and-accessories.md)
* cross sell: [Tapware & Showering](tapware-and-showering.md)
* cross sell: [Mirrors](mirrors.md)
