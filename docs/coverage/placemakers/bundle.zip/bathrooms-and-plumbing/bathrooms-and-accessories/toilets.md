---
description: 'Toilets: 300 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Toilets
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/toilets
  contentHash: ca16e4457592d97554d11e9b84825dfdc52583d80c45d84d53874758467de179
  customerPhrases:
    - back to wall pan
    - cistern parts
    - soft close seat
    - wall hung pan
    - accessible toilet
    - wall hung toilet pan
    - dual flush cistern
    - in wall cistern
    - loo
    - dunny
    - wc
    - toilet pan
    - toilet pans
    - toilet suite
    - toilet suites
  description: 'Toilets: 300 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-61d9b2b04b9e
    - src-doc-ea7bfe56250c
    - src-doc-3ab9646c7ec7
  extensions:
    x-journeyax-provenance:
      alias_loo:
        detail:
          alias: loo
          reason: Loo, dunny and WC are everyday words for a toilet.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:38.410Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Toilets
          path:
            - Bathrooms & Plumbing
            - Bathrooms & Accessories
            - Toilets
          products: 300
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Toilets
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Bathrooms & Plumbing
        - Bathrooms & Accessories
        - Toilets
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - toilet
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: d36f4ccbe6a6dd291a2e1e6f2babbdc565c8534c4dd73b7e294ba5a8762e0845
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/toilets
    relationshipId: rel-bathrooms-and-plumbing--bathrooms-and-accessories--toilets-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories
    type: child_of
  - claimClasses: []
    confidence: low
    contentHash: 51f8d5b8e95e560e06523976417ae8094a6480a05135f2d89bf46507106618c4
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/toilets
    relationshipId: rel-xs-toilet_extras-1
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/bathrooms-and-plumbing/plumbing/traps-and-wastes
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: 821a0f88c2539a0dde3488d5ff07454df631e7bb9729a59bc856536a903fa55c
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/toilets
    relationshipId: rel-xs-toilet_extras-2
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/bathroom-accessories
    type: cross_sell
x-journeyax-synonyms:
  - toilet
---
# Toilets

Toilets: 300 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Bathrooms & Accessories](../bathrooms-and-accessories.md)
* cross sell: [Traps & Wastes](../plumbing/traps-and-wastes.md)
* cross sell: [Bathroom Accessories](bathroom-accessories.md)
