---
description: 'Mirrors: 165 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Mirrors
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/mirrors
  contentHash: cc4b65a30491bddf6c756c2bb4fb1ef9d7e6edd6073617d869fab7d10cb5dae0
  customerPhrases:
    - round mirror
    - bevelled mirror
    - bevel edge mirror
    - polished edge mirror
    - concealed fixings mirror
    - wall mounted bathroom mirror
    - frameless mirror
    - bathroom vanity mirror
  description: 'Mirrors: 165 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-a1be4474fe0d
    - src-doc-aba3b72a14c7
    - src-doc-3f18329b52ac
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:27.040Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Mirrors
          path:
            - Bathrooms & Plumbing
            - Bathrooms & Accessories
            - Mirrors
          products: 165
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Mirrors
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Bathrooms & Plumbing
        - Bathrooms & Accessories
        - Mirrors
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - mirror
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 7e9f18943b16f0c7dda331c4075ffb92182b97cf1780d82057859e977ab44958
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/mirrors
    relationshipId: rel-bathrooms-and-plumbing--bathrooms-and-accessories--mirrors-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories
    type: child_of
x-journeyax-synonyms:
  - mirror
---
# Mirrors

Mirrors: 165 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Bathrooms & Accessories](../bathrooms-and-accessories.md)
