---
description: 'Tapware & Showering: 4,547 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Tapware & Showering
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/tapware-and-showering
  contentHash: 968fada6022d36d2790eb449c5168968be1eceab29e318b78a5d0ae62ad294c7
  customerPhrases:
    - basin tap
    - replacement shower hose
    - wall tap mixer
    - mixer valve
    - slide rail hand shower
    - wall spout
    - mixer tap set
    - shower column kit
    - tap
    - taps
    - mixer tap
    - bath tap
    - shower head
    - shower mixer
  description: 'Tapware & Showering: 4,547 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-d767079fdeff
    - src-doc-aa3fae10e930
    - src-doc-69ceb2377d43
  extensions:
    x-journeyax-provenance:
      alias_taps:
        detail:
          alias: taps
          reason: Customers ask for taps and mixers.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:58:09.115Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Tapware & Showering
            - Kitchens & Laundry > Laundry > Cabinetry
            - Laundry Cabinetry & Modular Units
            - Laundry Tubs & Sinkware
          path:
            - Bathrooms & Plumbing
            - Bathrooms & Accessories
            - Tapware & Showering
          products: 4547
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Tapware & Showering
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Bathrooms & Plumbing
        - Bathrooms & Accessories
        - Tapware & Showering
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - showering
    - showerings
    - tapware
    - tapwares
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: de43656860413b1c2c73acb0c2ff5299413ae7078f01d83fa14f3ac934199f11
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/tapware-and-showering
    relationshipId: rel-bathrooms-and-plumbing--bathrooms-and-accessories--tapware-and-showering-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories
    type: child_of
  - claimClasses: []
    confidence: low
    contentHash: 3acbfeb989f91c8cd847c114adae0d9eee6b307538fa0d8c60ea7c3dd3d50c45
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/tapware-and-showering
    relationshipId: rel-xs-tapware_installation_extras-1
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/bathrooms-and-plumbing/plumbing/traps-and-wastes
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: 5738a37e8946d4e828210727aa373013f913794e66056a52910e3d827f27a897
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/tapware-and-showering
    relationshipId: rel-xs-tapware_installation_extras-2
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/tools/hand-tools/plumbing-tools
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: 43ff07fde47406e23a4f8dc131789a7bf43ae962c2b5c1e4a11ce353ebb798f4
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/tapware-and-showering
    relationshipId: rel-xs-tapware_installation_extras-3
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/building-products/building-wraps-barriers-underlay-and-tapes/flashing-and-sealing-tapes
    type: cross_sell
x-journeyax-synonyms:
  - showering
  - showerings
  - tapware
  - tapwares
---
# Tapware & Showering

Tapware & Showering: 4,547 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Bathrooms & Accessories](../bathrooms-and-accessories.md)
* cross sell: [Traps & Wastes](../plumbing/traps-and-wastes.md)
* cross sell: [Plumbing Tools](../../tools/hand-tools/plumbing-tools.md)
* cross sell: [Flashing & Sealing Tapes](../../building-products/building-wraps-barriers-underlay-and-tapes/flashing-and-sealing-tapes.md)
