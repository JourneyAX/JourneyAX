---
description: 'Basins: 414 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Basins
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/basins
  contentHash: 038eeacf0b95fd6fe4eaf79ce81afa9bb872a21da52cdb1ccc71ea69de70c60b
  customerPhrases:
    - above counter basin
    - tap hole basin
    - wall hung basin
    - semi recessed basin
    - semi inset basin
    - basin shroud
    - vessel sink
    - no tap hole basin
  description: 'Basins: 414 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-af7a59552c5b
    - src-doc-853bd2619942
    - src-doc-65c8a7b2f994
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:17.980Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Basins
          path:
            - Bathrooms & Plumbing
            - Bathrooms & Accessories
            - Basins
          products: 414
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Basins
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Bathrooms & Plumbing
        - Bathrooms & Accessories
        - Basins
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - basin
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 6d34e831c1100258e27470c822f4e68e9a1b486f0e2ff29a11d13f7e82d6759d
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/basins
    relationshipId: rel-bathrooms-and-plumbing--bathrooms-and-accessories--basins-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories
    type: child_of
  - claimClasses: []
    confidence: low
    contentHash: 4d521640717fde734db52e282f3ae5c046d13bbe6c10eec73765533049c9322c
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/basins
    relationshipId: rel-xs-basin_extras-1
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/tapware-and-showering
    type: cross_sell
x-journeyax-synonyms:
  - basin
---
# Basins

Basins: 414 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Bathrooms & Accessories](../bathrooms-and-accessories.md)
* cross sell: [Tapware & Showering](tapware-and-showering.md)
