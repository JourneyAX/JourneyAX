---
description: 'Bathroom Accessories: 1,264 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Bathroom Accessories
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/bathroom-accessories
  contentHash: 4af5e313fd9df1340bb96f1136df3f5b63bad4e4286dc1687d97912e50bc88ec
  customerPhrases:
    - toilet paper holder
    - grab bar
    - towel hook
    - soap holder
    - loo brush holder
    - bathroom shelf
    - shower caddy corner
    - loo roll holder
  description: 'Bathroom Accessories: 1,264 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-a930bce7cc30
    - src-doc-f34f88f7f948
    - src-doc-076de5b6a896
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:21.642Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Bathroom Accessories
          path:
            - Bathrooms & Plumbing
            - Bathrooms & Accessories
            - Bathroom Accessories
          products: 1264
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Bathroom Accessories
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Bathrooms & Plumbing
        - Bathrooms & Accessories
        - Bathroom Accessories
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - bathroom accessory
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 84d52722bd09716933c0b321470ebfbaf8bca01b82bf4760f09216f8d50e3020
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories/bathroom-accessories
    relationshipId: rel-bathrooms-and-plumbing--bathrooms-and-accessories--bathroom-accessories-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories
    type: child_of
x-journeyax-synonyms:
  - bathroom accessory
---
# Bathroom Accessories

Bathroom Accessories: 1,264 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Bathrooms & Accessories](../bathrooms-and-accessories.md)
