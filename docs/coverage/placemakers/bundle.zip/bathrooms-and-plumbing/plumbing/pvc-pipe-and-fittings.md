---
description: 'PVC Pipe & Fittings: 342 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: PVC Pipe & Fittings
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/bathrooms-and-plumbing/plumbing/pvc-pipe-and-fittings
  contentHash: 0fbcf1bc887330f8ed0c597cf02daaf7dfbee5deac809fe4541c6d2f3b024c76
  customerPhrases:
    - half round spouting
    - drain waste vent
    - gutter guard foam
    - stormwater pipe
    - pressure elbow
    - drain waste vent pipe
    - roof guttering
    - sewer drain fittings
  description: 'PVC Pipe & Fittings: 342 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-2cba1ec85428
    - src-doc-296bc6439588
    - src-doc-a8fd1b25a891
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:19.902Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - PVC Pipe & Fittings
          path:
            - Bathrooms & Plumbing
            - Plumbing
            - PVC Pipe & Fittings
          products: 342
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: PVC Pipe & Fittings
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Bathrooms & Plumbing
        - Plumbing
        - PVC Pipe & Fittings
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - pipe
    - pipes
    - pvc pipe
    - pvc pipes
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 42ee169c977bd208a8838b4bf75938515de27623ca256cb7d932c6457038c333
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/plumbing/pvc-pipe-and-fittings
    relationshipId: rel-bathrooms-and-plumbing--plumbing--pvc-pipe-and-fittings-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/bathrooms-and-plumbing/plumbing
    type: child_of
x-journeyax-synonyms:
  - pipe
  - pipes
  - pvc pipe
  - pvc pipes
---
# PVC Pipe & Fittings

PVC Pipe & Fittings: 342 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Plumbing (Bathrooms & Plumbing)](../plumbing.md)
