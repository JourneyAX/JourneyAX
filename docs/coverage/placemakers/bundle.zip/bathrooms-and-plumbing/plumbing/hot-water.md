---
description: 'Hot Water: 23 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Hot Water
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: requires_professional_confirmation
  compatibilitySensitive: false
  conceptId: concept://placemakers/bathrooms-and-plumbing/plumbing/hot-water
  contentHash: 0dc9f3c59b61d2d5cebe9e3a002c251f30efe6effd88def5816514c97353865e
  customerPhrases:
    - seismic straps
    - hot water cylinder
    - boiling water tap
    - instant hot water gas
    - cylinder strap kit
    - storage cylinder
    - instant boiling unit
    - tankless gas hot water
    - hot water cylinders
    - hwc
    - califont
    - califonts
    - gas califont
    - instant hot water
    - water heater
    - water heaters
    - hot water heater
  description: 'Hot Water: 23 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-43e3368eb3b7
    - src-doc-dd5ac2b39f37
    - src-doc-29f348c6688a
  extensions:
    x-journeyax-provenance:
      alias_califont:
        detail:
          alias: califont
          reason: Califont is the New Zealand word for an instant gas water heater.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:03:58.714Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      policy_confirm_with_a_qualified_person:
        detail:
          overlay: confirm_with_a_qualified_person
          reason: 'Proposed: a qualified person confirms the selection before checkout for products that are normally installed by a licensed trade. PlaceMakers to approve the list.'
          section: overlays
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Hot Water
          path:
            - Bathrooms & Plumbing
            - Plumbing
            - Hot Water
          products: 23
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Hot Water
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Bathrooms & Plumbing
        - Plumbing
        - Hot Water
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - hot waters
    - water
    - waters
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 726f554a39f01911635f04d1ab1fddc741a1eaa3617fe1265d1201e808c3a741
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/plumbing/hot-water
    relationshipId: rel-bathrooms-and-plumbing--plumbing--hot-water-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/bathrooms-and-plumbing/plumbing
    type: child_of
x-journeyax-synonyms:
  - hot waters
  - water
  - waters
---
# Hot Water

Hot Water: 23 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Plumbing (Bathrooms & Plumbing)](../plumbing.md)
