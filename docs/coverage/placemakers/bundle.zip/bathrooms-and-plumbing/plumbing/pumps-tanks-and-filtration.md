---
description: 'Pumps, Tanks & Filtration: 684 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Pumps, Tanks & Filtration
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/bathrooms-and-plumbing/plumbing/pumps-tanks-and-filtration
  contentHash: db4d2e21504d01d1fdbb6c1dae7860460cbac25db109838324138496b50d5709
  customerPhrases:
    - water storage tank
    - booster pump
    - uv water disinfection
    - drinking water filter kit
    - rainwater tank
    - pressure boosting pump
    - uv steriliser
    - underbench water filter
  description: 'Pumps, Tanks & Filtration: 684 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-33564c23dbc6
    - src-doc-a5e9dd1fc25d
    - src-doc-b03f44a7f359
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:16.439Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Pumps, Tanks & Filtration
          path:
            - Bathrooms & Plumbing
            - Plumbing
            - Pumps, Tanks & Filtration
          products: 684
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Pumps, Tanks & Filtration
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Bathrooms & Plumbing
        - Plumbing
        - Pumps, Tanks & Filtration
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - filtration
    - filtrations
    - pump
    - pumps
    - tank
    - tanks
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: a6472388612608e7d5eaa87c3536eb34bfb2c3e70d3e8303d0c2c8dfd70784e4
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/plumbing/pumps-tanks-and-filtration
    relationshipId: rel-bathrooms-and-plumbing--plumbing--pumps-tanks-and-filtration-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/bathrooms-and-plumbing/plumbing
    type: child_of
x-journeyax-synonyms:
  - filtration
  - filtrations
  - pump
  - pumps
  - tank
  - tanks
---
# Pumps, Tanks & Filtration

Pumps, Tanks & Filtration: 684 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Plumbing (Bathrooms & Plumbing)](../plumbing.md)
