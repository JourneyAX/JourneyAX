---
description: 'Spare Parts: 49 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Spare Parts
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/bathrooms-and-plumbing/plumbing/spare-parts
  contentHash: 2fbc2b0c8acff3cf65b470cd5c76aaba060d44a982c612037e149a66c0f2baa9
  customerPhrases:
    - tap washer
    - seal kit
    - ptfe tape
    - rubber pipe joiner
    - pan collar
    - laundry box
    - tap spindle
    - plumbers tape
  description: 'Spare Parts: 49 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:02:05.444Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Spare Parts
          path:
            - Bathrooms & Plumbing
            - Plumbing
            - Spare Parts
          products: 49
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Spare Parts
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Bathrooms & Plumbing
        - Plumbing
        - Spare Parts
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: cec8d1c9df59e80006051c505bd9cf8c1c3c72c92e6ad700a2bee46ede6c7e1b
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/plumbing/spare-parts
    relationshipId: rel-bathrooms-and-plumbing--plumbing--spare-parts-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/bathrooms-and-plumbing/plumbing
    type: child_of
---
# Spare Parts

Spare Parts: 49 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Plumbing (Bathrooms & Plumbing)](../plumbing.md)
