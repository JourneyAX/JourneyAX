---
description: 'Piping Systems & Fittings: 229 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Piping Systems & Fittings
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/bathrooms-and-plumbing/plumbing/piping-systems-and-fittings
  contentHash: 9037eb409f7f74ca1b1d62b9f123af071b0fbfc3b1a3acdaa8562d13c99a0ba1
  customerPhrases:
    - mdpe fittings
    - pb fittings
    - alkathene pipe
    - brass fittings nz
    - brass gas fittings
    - press fit coupling
    - pb pipe
    - ldpe fittings
    - poly pipe
    - polypipe
    - alkathene
    - copper pipe
    - copper tube
    - hdpe pipe
    - push fit
    - pushfit
    - compression fittings
    - pipe fittings
  description: 'Piping Systems & Fittings: 229 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-83e7bc56e077
    - src-doc-ea011edfc56b
    - src-doc-d5cbbd35a749
  extensions:
    x-journeyax-provenance:
      alias_poly_pipe:
        detail:
          alias: poly_pipe
          reason: Alkathene and poly pipe are the same pipe.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:29.484Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Piping Systems & Fittings
          path:
            - Bathrooms & Plumbing
            - Plumbing
            - Piping Systems & Fittings
          products: 229
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Piping Systems & Fittings
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Bathrooms & Plumbing
        - Plumbing
        - Piping Systems & Fittings
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - piping system
    - piping systems
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: fa83ffdb8101cb8583e7cfe431173559f346b755cb243b1e2e0e9bfae638fc2c
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/plumbing/piping-systems-and-fittings
    relationshipId: rel-bathrooms-and-plumbing--plumbing--piping-systems-and-fittings-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/bathrooms-and-plumbing/plumbing
    type: child_of
x-journeyax-synonyms:
  - piping system
  - piping systems
---
# Piping Systems & Fittings

Piping Systems & Fittings: 229 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Plumbing (Bathrooms & Plumbing)](../plumbing.md)
