# bathrooms-and-plumbing/plumbing

* [Hot Water](hot-water.md) - Hot Water: 23 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [PVC Pipe & Fittings](pvc-pipe-and-fittings.md) - PVC Pipe & Fittings: 342 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Piping Systems & Fittings](piping-systems-and-fittings.md) - Piping Systems & Fittings: 229 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Pumps, Tanks & Filtration](pumps-tanks-and-filtration.md) - Pumps, Tanks & Filtration: 684 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Spare Parts](spare-parts.md) - Spare Parts: 49 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Surface Drainage](surface-drainage.md) - Surface Drainage: 96 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Traps & Wastes](traps-and-wastes.md) - Traps & Wastes: 284 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Valves](valves.md) - Valves: 71 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
