---
description: 'Valves: 71 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Valves
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/bathrooms-and-plumbing/plumbing/valves
  contentHash: fd48f6fa04104e3702c1084d72e2b3c7b87110b585260f2b810bad325a1ade3f
  customerPhrases:
    - ballcock seat
    - tank inlet valve
    - air admittance aav
    - mains feed valve
    - aav valve
    - water level control valve
    - high pressure ballcock
    - tank overflow valve
  description: 'Valves: 71 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-4368f500418f
    - src-doc-eed715d63a2b
    - src-doc-5a7c3e153ff7
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:00.270Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Valves
          path:
            - Bathrooms & Plumbing
            - Plumbing
            - Valves
          products: 71
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Valves
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Bathrooms & Plumbing
        - Plumbing
        - Valves
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - valve
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: e5b069b60b6a8b30eb31bbff9ceb98912bce01530e6e37f941983e70c2cdd05e
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/bathrooms-and-plumbing/plumbing/valves
    relationshipId: rel-bathrooms-and-plumbing--plumbing--valves-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/bathrooms-and-plumbing/plumbing
    type: child_of
x-journeyax-synonyms:
  - valve
---
# Valves

Valves: 71 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Plumbing (Bathrooms & Plumbing)](../plumbing.md)
