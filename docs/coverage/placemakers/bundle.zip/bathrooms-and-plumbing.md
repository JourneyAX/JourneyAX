---
description: 'Bathrooms & Plumbing: 15,256 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Bathrooms & Plumbing
type: department
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories
      - concept://placemakers/bathrooms-and-plumbing/plumbing
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_bathrooms_and_plumbing
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/bathrooms-and-plumbing
  contentHash: ba35a655d86a6574175e8dcdcf533d00306c81e0495a61e183ba1a6c385238b5
  customerPhrases:
    - pop up waste
  description: 'Bathrooms & Plumbing: 15,256 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_bathrooms_and_plumbing
      questionRef: q.nav_bathrooms_and_plumbing
      valueMap:
        bathrooms-and-accessories: concept://placemakers/bathrooms-and-plumbing/bathrooms-and-accessories
        plumbing: concept://placemakers/bathrooms-and-plumbing/plumbing
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-3e7cb73cd07a
    - src-doc-f1dacc8c05db
    - src-doc-d767079fdeff
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Bathrooms & Plumbing
          path:
            - Bathrooms & Plumbing
          products: 15256
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Bathrooms & Plumbing
  requiredFacts:
    - factKey: nav_bathrooms_and_plumbing
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Bathrooms & Plumbing
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - bathroom
    - bathrooms
    - plumbing
    - plumbings
  tenantId: placemakers
  type: department
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - bathroom
  - bathrooms
  - plumbing
  - plumbings
---
# Bathrooms & Plumbing

Bathrooms & Plumbing: 15,256 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
