---
description: 'Other products: 395 products across 14 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Other products
type: department
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/other-products/bathrooms-tapware-basin-mixers
      - concept://placemakers/other-products/bathrooms-vanities-and-basins-wall-hung-vanities
      - concept://placemakers/other-products/building-products-plasterboard-gib-aqualine
      - concept://placemakers/other-products/building-products-waterproofing
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_other_products
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/other-products
  contentHash: 68ad9c7a768fa61707ea2d2902523f8e37c08be34f7282d38669b41ffec88278
  customerPhrases: []
  description: 'Other products: 395 products across 14 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_other_products
      questionRef: q.nav_other_products
      valueMap:
        bathrooms-tapware-basin-mixers: concept://placemakers/other-products/bathrooms-tapware-basin-mixers
        bathrooms-vanities-and-basins-wall-hung-vanities: concept://placemakers/other-products/bathrooms-vanities-and-basins-wall-hung-vanities
        building-products-plasterboard-gib-aqualine: concept://placemakers/other-products/building-products-plasterboard-gib-aqualine
        building-products-waterproofing: concept://placemakers/other-products/building-products-waterproofing
        fixings-and-fasteners-screws-decking-screws: concept://placemakers/other-products/fixings-and-fasteners-screws-decking-screws
        laundry-accessories-and-storage: concept://placemakers/other-products/laundry-accessories-and-storage
        laundry-cabinetry-and-modular-units: concept://placemakers/other-products/laundry-cabinetry-and-modular-units
        laundry-tapware-and-plumbing: concept://placemakers/other-products/laundry-tapware-and-plumbing
        services-and-packages-room-solutions-bathroom-packages: concept://placemakers/other-products/services-and-packages-room-solutions-bathroom-packages
        services-and-packages-room-solutions-laundry-packages: concept://placemakers/other-products/services-and-packages-room-solutions-laundry-packages
        services-design-consultations-bathroom-design: concept://placemakers/other-products/services-design-consultations-bathroom-design
        services-installed-solutions-trade-installation: concept://placemakers/other-products/services-installed-solutions-trade-installation
        timber-and-plywood-structural-timber: concept://placemakers/other-products/timber-and-plywood-structural-timber
        tools-tool-kits-installation-tools: concept://placemakers/other-products/tools-tool-kits-installation-tools
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Other products
          path:
            - Other products
          products: 395
          scopedBy: name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Other products
  requiredFacts:
    - factKey: nav_other_products
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds:
      - Laundry Cabinetry & Modular Units
      - Building Products > Plasterboard > GIB Aqualine
      - Bathrooms > Tapware > Basin Mixers
      - Laundry Tapware & Plumbing
      - Building Products > Waterproofing
      - Services & Packages > Room Solutions > Laundry Packages
      - Laundry Accessories & Storage
      - Bathrooms > Vanities & Basins > Wall Hung Vanities
      - Services > Installed Solutions > Trade Installation
      - Services > Design Consultations > Bathroom Design
      - Fixings & Fasteners > Screws > Decking Screws
      - Timber & Plywood > Structural Timber
      - Tools > Tool Kits > Installation Tools
      - Services & Packages > Room Solutions > Bathroom Packages
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - other product
    - package
    - packages
    - service
    - services
  tenantId: placemakers
  type: department
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - other product
  - package
  - packages
  - service
  - services
---
# Other products

Other products: 395 products across 14 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
