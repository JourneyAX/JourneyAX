# doors-windows-and-joinery-hardware

* [Doors](doors.md) - Doors: 45 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Joinery Hardware](joinery-hardware.md) - Joinery Hardware: 1,401 products across 14 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Window Furnishings & Hardware](window-furnishings-and-hardware.md) - Window Furnishings & Hardware: 7 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Windows](windows.md) - Windows: 5 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [doors](doors/) - Knowledge and references
* [joinery-hardware](joinery-hardware/) - Knowledge and references
* [window-furnishings-and-hardware](window-furnishings-and-hardware/) - Knowledge and references
* [windows](windows/) - Knowledge and references
