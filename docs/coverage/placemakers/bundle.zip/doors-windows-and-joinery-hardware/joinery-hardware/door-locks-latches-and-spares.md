---
description: 'Door Locks, Latches & Spares: 129 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Door Locks, Latches & Spares
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/door-locks-latches-and-spares
  contentHash: 3f814b7c57a1dc1667a549667634881e67329b2b49c5cb0447afebf088140783
  customerPhrases:
    - stainless steel cylinder
    - shed lock
    - deadlock
    - spindle bar
    - mortice lock replacement
    - patio bolt
    - bathroom lock
    - rim night latch
    - deadbolt
    - deadlatch
    - dead latch
    - door lock
    - door locks
    - lockset
    - lock set
    - mortice lock
    - night latch
  description: 'Door Locks, Latches & Spares: 129 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-f85f7cd1a269
    - src-doc-cfdb7843b91c
    - src-doc-43d88b706915
  extensions:
    x-journeyax-provenance:
      alias_deadlock:
        detail:
          alias: deadlock
          reason: Deadlock, deadbolt and deadlatch are how customers ask for door locks.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:02:18.569Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Door Locks, Latches & Spares
          path:
            - Doors, Windows & Joinery Hardware
            - Joinery Hardware
            - Door Locks, Latches & Spares
          products: 129
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Door Locks, Latches & Spares
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Doors, Windows & Joinery Hardware
        - Joinery Hardware
        - Door Locks, Latches & Spares
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - door lock
    - door locks
    - latch
    - latches
    - lock
    - locks
    - spare
    - spares
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 19a72a2a6f74cc0973109fc225d3585e752082ad06eb05d8a770645077bef313
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/door-locks-latches-and-spares
    relationshipId: rel-doors-windows-and-joinery-hardware--joinery-hardware--door-locks-latches-and-spares-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware
    type: child_of
x-journeyax-synonyms:
  - door lock
  - door locks
  - latch
  - latches
  - lock
  - locks
  - spare
  - spares
---
# Door Locks, Latches & Spares

Door Locks, Latches & Spares: 129 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Joinery Hardware](../joinery-hardware.md)
