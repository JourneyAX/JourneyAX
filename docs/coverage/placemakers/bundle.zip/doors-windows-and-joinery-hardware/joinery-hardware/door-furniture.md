---
description: 'Door Furniture: 582 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Door Furniture
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/door-furniture
  contentHash: beffff11683629ee064200c51757a793e32bdb379551f50eb32646734b6d7635
  customerPhrases:
    - door pull
    - door latch
    - privacy lever set
    - passage latch set
    - dummy handle
    - entry lever
    - privacy knob
    - bathroom knob
    - door handle
    - door handles
    - door knob
    - door knobs
    - lever handle
    - passage set
    - privacy set
  description: 'Door Furniture: 582 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-ce16af054426
    - src-doc-6b469132af64
    - src-doc-00aac303d141
  extensions:
    x-journeyax-provenance:
      alias_door_handles:
        detail:
          alias: door_handles
          reason: Customers ask for door handles and knobs.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:26.892Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Door Furniture
          path:
            - Doors, Windows & Joinery Hardware
            - Joinery Hardware
            - Door Furniture
          products: 582
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Door Furniture
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Doors, Windows & Joinery Hardware
        - Joinery Hardware
        - Door Furniture
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - door furnitures
    - furnitures
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: cafa016f6ce7c7eedbef2d8b696098adc875ed46c0a05222b24b0c580f39c7dd
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/door-furniture
    relationshipId: rel-doors-windows-and-joinery-hardware--joinery-hardware--door-furniture-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware
    type: child_of
x-journeyax-synonyms:
  - door furnitures
  - furnitures
---
# Door Furniture

Door Furniture: 582 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Joinery Hardware](../joinery-hardware.md)
