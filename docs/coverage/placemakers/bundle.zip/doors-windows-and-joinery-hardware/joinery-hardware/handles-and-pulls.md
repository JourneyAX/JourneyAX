---
description: 'Handles & Pulls: 144 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Handles & Pulls
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/handles-and-pulls
  contentHash: 475d05ca17b73a27abc9d64e87dd821be714290713902f8f1ec7c5d1809446d8
  customerPhrases:
    - cupboard pull
    - recessed pull
    - cupboard knob
    - door push plate
    - cabinet bar pull
    - pocket door pull
    - cabinet handle
    - cabinet pull handle
  description: 'Handles & Pulls: 144 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:02.162Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Handles & Pulls
          path:
            - Doors, Windows & Joinery Hardware
            - Joinery Hardware
            - Handles & Pulls
          products: 144
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Handles & Pulls
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Doors, Windows & Joinery Hardware
        - Joinery Hardware
        - Handles & Pulls
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - handle
    - handles
    - pull
    - pulls
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 6f34b0663b9ee19309a2fbd2e59699a20be8b62e6e0b4b383b8c1e4ea0b22a4a
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/handles-and-pulls
    relationshipId: rel-doors-windows-and-joinery-hardware--joinery-hardware--handles-and-pulls-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware
    type: child_of
x-journeyax-synonyms:
  - handle
  - handles
  - pull
  - pulls
---
# Handles & Pulls

Handles & Pulls: 144 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Joinery Hardware](../joinery-hardware.md)
