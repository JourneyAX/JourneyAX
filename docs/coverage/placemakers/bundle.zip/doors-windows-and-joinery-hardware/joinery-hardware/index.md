# doors-windows-and-joinery-hardware/joinery-hardware

* [Bannister Brackets](bannister-brackets.md) - Bannister Brackets: 24 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Bolts & Cabin Hooks](bolts-and-cabin-hooks.md) - Bolts & Cabin Hooks: 57 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Catch](catch.md) - Catch: 19 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Door Closer](door-closer.md) - Door Closer: 11 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Door Furniture](door-furniture.md) - Door Furniture: 582 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Door Locks, Latches & Spares](door-locks-latches-and-spares.md) - Door Locks, Latches & Spares: 129 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Door Stops](door-stops.md) - Door Stops: 79 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Door Track](door-track.md) - Door Track: 100 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Handles & Pulls](handles-and-pulls.md) - Handles & Pulls: 144 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Hinge](hinge.md) - Hinge: 75 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Keyless Entry](keyless-entry.md) - Keyless Entry: 19 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Keys](keys.md) - Keys: 21 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Seals](seals.md) - Seals: 40 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Window Hardware](window-hardware.md) - Window Hardware: 101 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
