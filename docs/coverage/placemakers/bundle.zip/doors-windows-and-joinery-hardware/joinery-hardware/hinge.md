---
description: 'Hinge: 75 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Hinge
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/hinge
  contentHash: 794e935b5e453b60bf88f80722ce0a4a6458aef6cb39bd81f35923430c796749
  customerPhrases:
    - butt hinge fixed pin
    - loose pin hinge
    - butt hinge
    - parliament hinge
    - fixed pin butt hinge
    - butt hinge radius
    - narrow butt hinge
    - butt hinge wide throw
    - hinges
    - butt hinges
    - piano hinge
  description: 'Hinge: 75 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_hinges:
        detail:
          alias: hinges
          reason: Customers ask for butt hinges and tee hinges.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:49.744Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Hinge
          path:
            - Doors, Windows & Joinery Hardware
            - Joinery Hardware
            - Hinge
          products: 75
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Hinge
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Doors, Windows & Joinery Hardware
        - Joinery Hardware
        - Hinge
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - hinges
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 3058b87b5c6a5d228be072c13329b391c3bdfcefdca60adffaea2a35f68439e7
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/hinge
    relationshipId: rel-doors-windows-and-joinery-hardware--joinery-hardware--hinge-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware
    type: child_of
x-journeyax-synonyms:
  - hinges
---
# Hinge

Hinge: 75 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Joinery Hardware](../joinery-hardware.md)
