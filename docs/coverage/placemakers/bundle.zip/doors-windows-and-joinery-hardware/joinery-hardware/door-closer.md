---
description: 'Door Closer: 11 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Door Closer
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/door-closer
  contentHash: b7c0d3cd3c9868c80fe5fed422a926ae5a998ed87dfd42e58a1a7cebd2c21762
  customerPhrases:
    - light duty door closer
    - commercial door closer heavy duty
    - child safety catch
    - door closer white
    - adjustable closing speed closer
    - adjustable closing speed door
    - spring closer
    - rack and pinion closer
  description: 'Door Closer: 11 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-ea0add255186
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:04:29.752Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Door Closer
          path:
            - Doors, Windows & Joinery Hardware
            - Joinery Hardware
            - Door Closer
          products: 11
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Door Closer
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Doors, Windows & Joinery Hardware
        - Joinery Hardware
        - Door Closer
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - closer
    - closers
    - door closers
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 780923f3c949d010136f9c4e32f637dfece6e30a00f0118a131082d7f1ebbbc1
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/door-closer
    relationshipId: rel-doors-windows-and-joinery-hardware--joinery-hardware--door-closer-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware
    type: child_of
x-journeyax-synonyms:
  - closer
  - closers
  - door closers
---
# Door Closer

Door Closer: 11 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Joinery Hardware](../joinery-hardware.md)
