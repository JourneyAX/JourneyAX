---
description: 'Window Furnishings & Hardware: 7 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Window Furnishings & Hardware
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/doors-windows-and-joinery-hardware/window-furnishings-and-hardware
  contentHash: 879b2716166a3114c0ae78b047d932044b02c654f8e7a3928cd1128014d9e3e0
  customerPhrases: []
  description: 'Window Furnishings & Hardware: 7 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Window Furnishings & Hardware
          path:
            - Doors, Windows & Joinery Hardware
            - Window Furnishings & Hardware
          products: 7
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Window Furnishings & Hardware
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Doors, Windows & Joinery Hardware
        - Window Furnishings & Hardware
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - furnishing
    - furnishings
    - window furnishing
    - window furnishings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 43039ce350b0eebeb6ce721412403e572efe6860cd1aff6d89178d71743129e2
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/doors-windows-and-joinery-hardware/window-furnishings-and-hardware
    relationshipId: rel-doors-windows-and-joinery-hardware--window-furnishings-and-hardware-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/doors-windows-and-joinery-hardware
    type: child_of
x-journeyax-synonyms:
  - furnishing
  - furnishings
  - window furnishing
  - window furnishings
---
# Window Furnishings & Hardware

Window Furnishings & Hardware: 7 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Doors, Windows & Joinery Hardware](../doors-windows-and-joinery-hardware.md)
