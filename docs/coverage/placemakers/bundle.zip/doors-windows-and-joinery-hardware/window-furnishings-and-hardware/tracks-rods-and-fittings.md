---
description: 'Tracks, Rods & Fittings: 7 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Tracks, Rods & Fittings
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/doors-windows-and-joinery-hardware/window-furnishings-and-hardware/tracks-rods-and-fittings
  contentHash: 97e70d5c5e9c9d44956e8f088dd0b96d79c4cf0b15a74adb81ac8e841bfdd67b
  customerPhrases:
    - brick reinforcement rods
    - masonry reinforcement
    - bricklaying reinforcing bars
    - wall tie alternative
    - stainless steel reinforcing rod
    - galvanised reinforcing rod
    - stackbond reinforcement
    - block veneer reinforcement
  description: 'Tracks, Rods & Fittings: 7 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:04:30.547Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Tracks, Rods & Fittings
          path:
            - Doors, Windows & Joinery Hardware
            - Window Furnishings & Hardware
            - Tracks, Rods & Fittings
          products: 7
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Tracks, Rods & Fittings
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Doors, Windows & Joinery Hardware
        - Window Furnishings & Hardware
        - Tracks, Rods & Fittings
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - rod
    - rods
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: dbbb2a935d9f4ca3e624d866685f9a9d985376c3bec620c73c8902a8be204767
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/doors-windows-and-joinery-hardware/window-furnishings-and-hardware/tracks-rods-and-fittings
    relationshipId: rel-doors-windows-and-joinery-hardware--window-furnishings-and-hardware--tracks-rods-and-fittings-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/doors-windows-and-joinery-hardware/window-furnishings-and-hardware
    type: child_of
x-journeyax-synonyms:
  - rod
  - rods
---
# Tracks, Rods & Fittings

Tracks, Rods & Fittings: 7 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Window Furnishings & Hardware](../window-furnishings-and-hardware.md)
