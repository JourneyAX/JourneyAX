---
description: 'Window Accessories: 5 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Window Accessories
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/doors-windows-and-joinery-hardware/windows/window-accessories
  contentHash: 8bc36a6fb5b2fd8d0367681d3536f145fffb096c382e68ebdab236363b0b1def
  customerPhrases:
    - cavity closer flashing
    - weatherboard starter strip
    - upvc flashing trim
    - horizontal z flashing
    - drainage flashing
    - weatherboard edge support
    - vermin proof cavity
    - cavity ventilation flashings
    - flyscreen
    - fly screen
    - flyscreens
    - window screen
    - insect screen
  description: 'Window Accessories: 5 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_flyscreen:
        detail:
          alias: flyscreen
          reason: Flyscreen is written as one word or two.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:04:58.764Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Window Accessories
          path:
            - Doors, Windows & Joinery Hardware
            - Windows
            - Window Accessories
          products: 5
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Window Accessories
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Doors, Windows & Joinery Hardware
        - Windows
        - Window Accessories
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - window accessory
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 6db9d278762fd21248aaa04a127c57c495072ac756586f04ebc92e1aa2da7c53
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/doors-windows-and-joinery-hardware/windows/window-accessories
    relationshipId: rel-doors-windows-and-joinery-hardware--windows--window-accessories-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/doors-windows-and-joinery-hardware/windows
    type: child_of
x-journeyax-synonyms:
  - window accessory
---
# Window Accessories

Window Accessories: 5 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Windows](../windows.md)
