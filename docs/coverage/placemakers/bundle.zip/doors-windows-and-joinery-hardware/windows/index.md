# doors-windows-and-joinery-hardware/windows

* [Window Accessories](window-accessories.md) - Window Accessories: 5 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
