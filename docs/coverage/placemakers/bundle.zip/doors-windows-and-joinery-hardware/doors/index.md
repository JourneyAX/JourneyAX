# doors-windows-and-joinery-hardware/doors

* [Cavity Slider](cavity-slider.md) - Cavity Slider: 8 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Entrance Doors](entrance-doors.md) - Entrance Doors: 9 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Exterior Doors](exterior-doors.md) - Exterior Doors: 3 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Interior Doors](interior-doors.md) - Interior Doors: 25 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
