---
description: 'Entrance Doors: 9 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Entrance Doors
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/doors-windows-and-joinery-hardware/doors/entrance-doors
  contentHash: b084876b688e89f14f11418f316126c5dfee9d0df3feb4724f6fa257702b3acd
  customerPhrases:
    - porch door core
    - solid core entrance door
    - pre primed exterior door
    - 40mm door core
    - tempered hardboard door
    - particle board door core
    - eps poly core door
    - high density core door
    - front door
    - front doors
    - entry door
    - entry doors
  description: 'Entrance Doors: 9 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_front_door:
        detail:
          alias: front_door
          reason: Front door is the everyday word for an entrance door.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:03:52.025Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Entrance Doors
          path:
            - Doors, Windows & Joinery Hardware
            - Doors
            - Entrance Doors
          products: 9
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Entrance Doors
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Doors, Windows & Joinery Hardware
        - Doors
        - Entrance Doors
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - entrance door
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: e04f8c446a6f88fe836593461839a5204ea7eddcfc4ec1a3c78e501be4904218
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/doors-windows-and-joinery-hardware/doors/entrance-doors
    relationshipId: rel-doors-windows-and-joinery-hardware--doors--entrance-doors-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/doors-windows-and-joinery-hardware/doors
    type: child_of
x-journeyax-synonyms:
  - entrance door
---
# Entrance Doors

Entrance Doors: 9 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Doors](../doors.md)
