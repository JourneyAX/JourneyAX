---
description: 'Exterior Doors: 3 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Exterior Doors
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/doors-windows-and-joinery-hardware/doors/exterior-doors
  contentHash: 0a25404ceb52fe48e6eaaed8e99ddc951078a3e7fced522daa884337c8c10725
  customerPhrases:
    - fibreglass entry door
    - composite exterior door
    - fibreglass front door
    - duramax door
    - residential entry door
    - external fibreglass door
    - fibreglass door 1980mm high
    - prefinished fibreglass door
  description: 'Exterior Doors: 3 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:05:46.362Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Exterior Doors
          path:
            - Doors, Windows & Joinery Hardware
            - Doors
            - Exterior Doors
          products: 3
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Exterior Doors
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Doors, Windows & Joinery Hardware
        - Doors
        - Exterior Doors
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - exterior door
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: a4d0ca6d5fc7cdcb80ffb3d04962a4379381d64fdacc6f3888196a15208bc9d7
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/doors-windows-and-joinery-hardware/doors/exterior-doors
    relationshipId: rel-doors-windows-and-joinery-hardware--doors--exterior-doors-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/doors-windows-and-joinery-hardware/doors
    type: child_of
x-journeyax-synonyms:
  - exterior door
---
# Exterior Doors

Exterior Doors: 3 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Doors](../doors.md)
