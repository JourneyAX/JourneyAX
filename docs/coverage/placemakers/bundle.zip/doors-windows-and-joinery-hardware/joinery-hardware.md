---
description: 'Joinery Hardware: 1,401 products across 14 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Joinery Hardware
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/door-furniture
      - concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/handles-and-pulls
      - concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/door-locks-latches-and-spares
      - concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/window-hardware
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_doors_windows_and_joinery_hardware_joinery_hardware
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware
  contentHash: 76cc43a4e0cb04b7ddf3fc83306ed42ec15b7ecce30f378e8d6aaf324dab1db9
  customerPhrases:
    - pull handle
    - euro cylinder
    - privacy thumbturn
    - rose cover
    - door bolt
    - satin chrome privacy
    - cupboard catch
    - door catch
  description: 'Joinery Hardware: 1,401 products across 14 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_doors_windows_and_joinery_hardware_joinery_hardware
      questionRef: q.nav_doors_windows_and_joinery_hardware_joinery_hardware
      valueMap:
        bannister-brackets: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/bannister-brackets
        bolts-and-cabin-hooks: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/bolts-and-cabin-hooks
        catch: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/catch
        door-closer: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/door-closer
        door-furniture: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/door-furniture
        door-locks-latches-and-spares: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/door-locks-latches-and-spares
        door-stops: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/door-stops
        door-track: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/door-track
        handles-and-pulls: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/handles-and-pulls
        hinge: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/hinge
        keyless-entry: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/keyless-entry
        keys: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/keys
        seals: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/seals
        window-hardware: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware/window-hardware
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-8cbdaa7f185b
    - src-doc-2558b68c2b6f
    - src-doc-b4fc38861c9d
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Joinery Hardware
          path:
            - Doors, Windows & Joinery Hardware
            - Joinery Hardware
          products: 1401
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Joinery Hardware
  requiredFacts:
    - factKey: nav_doors_windows_and_joinery_hardware_joinery_hardware
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Doors, Windows & Joinery Hardware
        - Joinery Hardware
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 2e777cef8026d2a90901eb6893d255add7e9229a6ebd9ccc34a892832efe987c
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware
    relationshipId: rel-doors-windows-and-joinery-hardware--joinery-hardware-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/doors-windows-and-joinery-hardware
    type: child_of
---
# Joinery Hardware

Joinery Hardware: 1,401 products across 14 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Doors, Windows & Joinery Hardware](../doors-windows-and-joinery-hardware.md)
