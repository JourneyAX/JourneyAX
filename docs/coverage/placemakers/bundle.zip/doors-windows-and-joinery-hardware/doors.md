---
description: 'Doors: 45 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Doors
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/doors-windows-and-joinery-hardware/doors/interior-doors
      - concept://placemakers/doors-windows-and-joinery-hardware/doors/entrance-doors
      - concept://placemakers/doors-windows-and-joinery-hardware/doors/cavity-slider
      - concept://placemakers/doors-windows-and-joinery-hardware/doors/exterior-doors
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_doors_windows_and_joinery_hardware_doors
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/doors-windows-and-joinery-hardware/doors
  contentHash: f7bf553568b50fee213f764bf314faa2a913d49cdc74cea7d9ca145ca0cc8548
  customerPhrases: []
  description: 'Doors: 45 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_doors_windows_and_joinery_hardware_doors
      questionRef: q.nav_doors_windows_and_joinery_hardware_doors
      valueMap:
        cavity-slider: concept://placemakers/doors-windows-and-joinery-hardware/doors/cavity-slider
        entrance-doors: concept://placemakers/doors-windows-and-joinery-hardware/doors/entrance-doors
        exterior-doors: concept://placemakers/doors-windows-and-joinery-hardware/doors/exterior-doors
        interior-doors: concept://placemakers/doors-windows-and-joinery-hardware/doors/interior-doors
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-b6c73ac8da88
    - src-doc-5d65512f79d1
    - src-doc-be01eefe8444
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Doors
          path:
            - Doors, Windows & Joinery Hardware
            - Doors
          products: 45
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Doors
  requiredFacts:
    - factKey: nav_doors_windows_and_joinery_hardware_doors
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Doors, Windows & Joinery Hardware
        - Doors
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 0524fff32c05801eb5e73c737113b82e244bce37ee0c540b0870500c3c58d8c7
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/doors-windows-and-joinery-hardware/doors
    relationshipId: rel-doors-windows-and-joinery-hardware--doors-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/doors-windows-and-joinery-hardware
    type: child_of
---
# Doors

Doors: 45 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Doors, Windows & Joinery Hardware](../doors-windows-and-joinery-hardware.md)
