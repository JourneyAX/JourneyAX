---
description: 'Site Consumables: 13 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Site Consumables
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/cleaning-and-consumables/site-consumables/food-and-beverage
      - concept://placemakers/cleaning-and-consumables/site-consumables/personal-hygiene-and-other-consumables
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_cleaning_and_consumables_site_consumables
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cleaning-and-consumables/site-consumables
  contentHash: fcea39266432ba69285a9c7b107ecb80a51e9ef613b6adfaff7d94b328f3cfe7
  customerPhrases: []
  description: 'Site Consumables: 13 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_cleaning_and_consumables_site_consumables
      questionRef: q.nav_cleaning_and_consumables_site_consumables
      valueMap:
        food-and-beverage: concept://placemakers/cleaning-and-consumables/site-consumables/food-and-beverage
        personal-hygiene-and-other-consumables: concept://placemakers/cleaning-and-consumables/site-consumables/personal-hygiene-and-other-consumables
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Site Consumables
          path:
            - Cleaning & Consumables
            - Site Consumables
          products: 13
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Site Consumables
  requiredFacts:
    - factKey: nav_cleaning_and_consumables_site_consumables
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cleaning & Consumables
        - Site Consumables
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - site consumable
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 64bcaa890a158febc6165313f0ecca8d47f6f4b8d093be5505db1fcfddcecff5
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cleaning-and-consumables/site-consumables
    relationshipId: rel-cleaning-and-consumables--site-consumables-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cleaning-and-consumables
    type: child_of
x-journeyax-synonyms:
  - site consumable
---
# Site Consumables

Site Consumables: 13 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Cleaning & Consumables](../cleaning-and-consumables.md)
