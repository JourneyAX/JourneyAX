---
description: 'Automotive: 41 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Automotive
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/cleaning-and-consumables/automotive/car-cleaning
      - concept://placemakers/cleaning-and-consumables/automotive/petrol-cans
      - concept://placemakers/cleaning-and-consumables/automotive/battery-chargers-and-accessories
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_cleaning_and_consumables_automotive
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cleaning-and-consumables/automotive
  contentHash: 71afd0dfe8df66685c6f0660568d1e959818a7ff06c69c4e8da9c5233b01bf89
  customerPhrases: []
  description: 'Automotive: 41 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_cleaning_and_consumables_automotive
      questionRef: q.nav_cleaning_and_consumables_automotive
      valueMap:
        battery-chargers-and-accessories: concept://placemakers/cleaning-and-consumables/automotive/battery-chargers-and-accessories
        car-cleaning: concept://placemakers/cleaning-and-consumables/automotive/car-cleaning
        petrol-cans: concept://placemakers/cleaning-and-consumables/automotive/petrol-cans
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-6d28cb493414
    - src-doc-bf56f01b365d
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Automotive
          path:
            - Cleaning & Consumables
            - Automotive
          products: 41
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Automotive
  requiredFacts:
    - factKey: nav_cleaning_and_consumables_automotive
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cleaning & Consumables
        - Automotive
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - automotives
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: f09a159de39fea5a41c8c93b3a25c8061c2e4dbe0921ffe10fecb31ab8cf9343
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cleaning-and-consumables/automotive
    relationshipId: rel-cleaning-and-consumables--automotive-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cleaning-and-consumables
    type: child_of
x-journeyax-synonyms:
  - automotives
---
# Automotive

Automotive: 41 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Cleaning & Consumables](../cleaning-and-consumables.md)
