---
description: 'Household & Pets: 40 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Household & Pets
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/cleaning-and-consumables/household-and-pets/household
      - concept://placemakers/cleaning-and-consumables/household-and-pets/pet-care
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_cleaning_and_consumables_household_and_pets
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cleaning-and-consumables/household-and-pets
  contentHash: f0788f7e40cf5b59c9df6b957f8d6135f5dd7febc9036955dcf2f66cee35ad57
  customerPhrases: []
  description: 'Household & Pets: 40 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_cleaning_and_consumables_household_and_pets
      questionRef: q.nav_cleaning_and_consumables_household_and_pets
      valueMap:
        household: concept://placemakers/cleaning-and-consumables/household-and-pets/household
        pet-care: concept://placemakers/cleaning-and-consumables/household-and-pets/pet-care
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Household & Pets
          path:
            - Cleaning & Consumables
            - Household & Pets
          products: 40
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Household & Pets
  requiredFacts:
    - factKey: nav_cleaning_and_consumables_household_and_pets
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cleaning & Consumables
        - Household & Pets
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - households
    - pet
    - pets
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: e5b4bd7d47d73467d18119ce20f858878893b4e35dfda406e31b7ad4641bd27b
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cleaning-and-consumables/household-and-pets
    relationshipId: rel-cleaning-and-consumables--household-and-pets-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cleaning-and-consumables
    type: child_of
x-journeyax-synonyms:
  - households
  - pet
  - pets
---
# Household & Pets

Household & Pets: 40 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Cleaning & Consumables](../cleaning-and-consumables.md)
