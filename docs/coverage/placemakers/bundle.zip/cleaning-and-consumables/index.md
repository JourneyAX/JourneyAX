# cleaning-and-consumables

* [Automotive](automotive.md) - Automotive: 41 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Cleaners & Cleaning Equipment](cleaners-and-cleaning-equipment.md) - Cleaners & Cleaning Equipment: 168 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Household & Pets](household-and-pets.md) - Household & Pets: 40 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Site Consumables](site-consumables.md) - Site Consumables: 13 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [automotive](automotive/) - Knowledge and references
* [cleaners-and-cleaning-equipment](cleaners-and-cleaning-equipment/) - Knowledge and references
* [household-and-pets](household-and-pets/) - Knowledge and references
* [site-consumables](site-consumables/) - Knowledge and references
