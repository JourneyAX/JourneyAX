---
description: 'Indoor Cleaners: 82 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Indoor Cleaners
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/indoor-cleaners
  contentHash: 73bd1a3084ee8c6cb69b23693908a1c922ac429c35ef11a549948dc9e58501ce
  customerPhrases:
    - degreaser for paint prep
    - sugar soap wipes
    - laundry powder bulk
    - damp rid refills
    - soap scum remover
    - pre impregnated wipes
    - top loader powder
    - wardrobe dehumidifier
    - sugar soap
    - bleach
    - degreaser
    - disinfectant
    - spray and wipe
    - toilet cleaner
    - bathroom cleaner
    - kitchen cleaner
    - detergent
  description: 'Indoor Cleaners: 82 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-d4cab89b6595
  extensions:
    x-journeyax-provenance:
      alias_sugar_soap:
        detail:
          alias: sugar_soap
          reason: Sugar soap, bleach and degreaser are indoor cleaners.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:58.322Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Indoor Cleaners
          path:
            - Cleaning & Consumables
            - Cleaners & Cleaning Equipment
            - Indoor Cleaners
          products: 82
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Indoor Cleaners
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cleaning & Consumables
        - Cleaners & Cleaning Equipment
        - Indoor Cleaners
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - indoor cleaner
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 52110607fec3bbd52e69a4de29d1e815b83ca16adbbc0a220bbaf226b104e3f0
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/indoor-cleaners
    relationshipId: rel-cleaning-and-consumables--cleaners-and-cleaning-equipment--indoor-cleaners-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment
    type: child_of
  - claimClasses: []
    confidence: medium
    contentHash: be4434c99775c4e43f229e44b89303077c87e842959a98bf2a2cc741e6c36715
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: families
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/indoor-cleaners
    relationshipId: rel-family-cleaning_supplies-indoor-cleaners
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/families/cleaning-supplies
    type: child_of
x-journeyax-synonyms:
  - indoor cleaner
---
# Indoor Cleaners

Indoor Cleaners: 82 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Cleaners & Cleaning Equipment](../cleaners-and-cleaning-equipment.md)
* child of: [Cleaning supplies](../../families/cleaning-supplies.md)
