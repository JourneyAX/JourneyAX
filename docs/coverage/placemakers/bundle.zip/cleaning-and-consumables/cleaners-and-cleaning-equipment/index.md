# cleaning-and-consumables/cleaners-and-cleaning-equipment

* [Indoor Cleaners](indoor-cleaners.md) - Indoor Cleaners: 82 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Mops & Brooms](mops-and-brooms.md) - Mops & Brooms: 75 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Outdoor Cleaners](outdoor-cleaners.md) - Outdoor Cleaners: 11 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
