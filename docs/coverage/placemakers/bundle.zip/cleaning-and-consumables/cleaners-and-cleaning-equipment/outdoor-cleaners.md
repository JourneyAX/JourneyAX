---
description: 'Outdoor Cleaners: 11 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Outdoor Cleaners
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/outdoor-cleaners
  contentHash: 745efeffe62d2131255f231861483609fcf7957a46e51f0b434eb11bca4745fd
  customerPhrases:
    - mould remover
    - concrete degreaser
    - concrete residue remover
    - moss killer
    - oil stain remover
    - acid free concrete stripper
    - driveway cleaner
    - organic concrete cleaner
    - deck wash
    - house wash
    - moss and lichen
    - roof wash
    - concrete cleaner
  description: 'Outdoor Cleaners: 11 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_deck_wash:
        detail:
          alias: deck_wash
          reason: Deck wash and moss killer are outdoor cleaners.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:04:45.924Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Outdoor Cleaners
          path:
            - Cleaning & Consumables
            - Cleaners & Cleaning Equipment
            - Outdoor Cleaners
          products: 11
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Outdoor Cleaners
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cleaning & Consumables
        - Cleaners & Cleaning Equipment
        - Outdoor Cleaners
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - outdoor cleaner
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 5bebaa6ed420a5eb823768a9d32bcf5e53126c6138ece97bf96ab374bf7c0a07
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/outdoor-cleaners
    relationshipId: rel-cleaning-and-consumables--cleaners-and-cleaning-equipment--outdoor-cleaners-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment
    type: child_of
  - claimClasses: []
    confidence: medium
    contentHash: 28545ea7dfba639e4a69e4ad534db27ebd9eab968847087ec1241ae8067848a2
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: families
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/outdoor-cleaners
    relationshipId: rel-family-cleaning_supplies-outdoor-cleaners
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/families/cleaning-supplies
    type: child_of
x-journeyax-synonyms:
  - outdoor cleaner
---
# Outdoor Cleaners

Outdoor Cleaners: 11 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Cleaners & Cleaning Equipment](../cleaners-and-cleaning-equipment.md)
* child of: [Cleaning supplies](../../families/cleaning-supplies.md)
