---
description: 'Mops & Brooms: 75 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Mops & Brooms
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/mops-and-brooms
  contentHash: 784fd1b564df86b4f71d167de18f6ecaac70859898e84f6bbe533d8356e3950f
  customerPhrases:
    - window squeegee
    - yard broom
    - scrub brush
    - house wash brush
    - house broom
    - telescopic broom handle
    - squeegee t bar
    - microfibre window pad
  description: 'Mops & Brooms: 75 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-5227deb9031d
    - src-doc-f87dc1483360
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:41.210Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Mops & Brooms
          path:
            - Cleaning & Consumables
            - Cleaners & Cleaning Equipment
            - Mops & Brooms
          products: 75
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Mops & Brooms
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cleaning & Consumables
        - Cleaners & Cleaning Equipment
        - Mops & Brooms
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - broom
    - brooms
    - mop
    - mops
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: d3d6aa46f8eebc37a9772a8558ea867758920fc9a8041ce0b12eae17d454e351
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/mops-and-brooms
    relationshipId: rel-cleaning-and-consumables--cleaners-and-cleaning-equipment--mops-and-brooms-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment
    type: child_of
  - claimClasses: []
    confidence: medium
    contentHash: f8ed3c1f51bdc44d66e273f6cd1c9aef7daae710062bc7ce6263671b4ba3527d
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: families
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/mops-and-brooms
    relationshipId: rel-family-cleaning_supplies-mops-and-brooms
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/families/cleaning-supplies
    type: child_of
x-journeyax-synonyms:
  - broom
  - brooms
  - mop
  - mops
---
# Mops & Brooms

Mops & Brooms: 75 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Cleaners & Cleaning Equipment](../cleaners-and-cleaning-equipment.md)
* child of: [Cleaning supplies](../../families/cleaning-supplies.md)
