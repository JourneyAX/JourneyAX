---
description: 'Cleaners & Cleaning Equipment: 168 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Cleaners & Cleaning Equipment
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/indoor-cleaners
      - concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/mops-and-brooms
      - concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/outdoor-cleaners
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_cleaning_and_consumables_cleaners_and_cleaning_equipment
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment
  contentHash: 7d8b74df29f1f6314db8e7ce2ffb08957ccf174347f668bb419d1e41b37a026f
  customerPhrases: []
  description: 'Cleaners & Cleaning Equipment: 168 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_cleaning_and_consumables_cleaners_and_cleaning_equipment
      questionRef: q.nav_cleaning_and_consumables_cleaners_and_cleaning_equipment
      valueMap:
        indoor-cleaners: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/indoor-cleaners
        mops-and-brooms: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/mops-and-brooms
        outdoor-cleaners: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/outdoor-cleaners
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-5227deb9031d
    - src-doc-f87dc1483360
    - src-doc-d4cab89b6595
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Cleaners & Cleaning Equipment
          path:
            - Cleaning & Consumables
            - Cleaners & Cleaning Equipment
          products: 168
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Cleaners & Cleaning Equipment
  requiredFacts:
    - factKey: nav_cleaning_and_consumables_cleaners_and_cleaning_equipment
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cleaning & Consumables
        - Cleaners & Cleaning Equipment
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - cleaner
    - cleaners
    - cleaning equipments
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 1684327bcdffd4a4005f69bf3f70fd8e826032435d56c5b4d281fec9eea5ac8b
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment
    relationshipId: rel-cleaning-and-consumables--cleaners-and-cleaning-equipment-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cleaning-and-consumables
    type: child_of
x-journeyax-synonyms:
  - cleaner
  - cleaners
  - cleaning equipments
---
# Cleaners & Cleaning Equipment

Cleaners & Cleaning Equipment: 168 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Cleaning & Consumables](../cleaning-and-consumables.md)
