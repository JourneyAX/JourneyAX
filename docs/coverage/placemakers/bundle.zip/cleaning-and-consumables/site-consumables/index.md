# cleaning-and-consumables/site-consumables

* [Food & Beverage](food-and-beverage.md) - Food & Beverage: 9 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Personal Hygiene & Other Consumables](personal-hygiene-and-other-consumables.md) - Personal Hygiene & Other Consumables: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
