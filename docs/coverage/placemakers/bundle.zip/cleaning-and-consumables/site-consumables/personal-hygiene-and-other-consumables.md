---
description: 'Personal Hygiene & Other Consumables: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Personal Hygiene & Other Consumables
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cleaning-and-consumables/site-consumables/personal-hygiene-and-other-consumables
  contentHash: d7c0da749ba96b96260171688468b0574dab107aa8bbbf537069f8e748881c84
  customerPhrases:
    - vacuum insulated tumbler
    - double wall flask
    - swig lid bottle
    - magnetic slider lid
    - worksite drink bottle
    - large water jug insulated
    - thermal coffee cup
    - hot cold flask
  description: 'Personal Hygiene & Other Consumables: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:05:38.148Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Personal Hygiene & Other Consumables
          path:
            - Cleaning & Consumables
            - Site Consumables
            - Personal Hygiene & Other Consumables
          products: 4
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Personal Hygiene & Other Consumables
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cleaning & Consumables
        - Site Consumables
        - Personal Hygiene & Other Consumables
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - hygiene
    - hygienes
    - other consumable
    - other consumables
    - personal hygiene
    - personal hygienes
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: c28b487ff06a983b380bb7572dd454554baadd760a97723c324eca8d47d8653a
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cleaning-and-consumables/site-consumables/personal-hygiene-and-other-consumables
    relationshipId: rel-cleaning-and-consumables--site-consumables--personal-hygiene-and-other-consumables-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cleaning-and-consumables/site-consumables
    type: child_of
x-journeyax-synonyms:
  - hygiene
  - hygienes
  - other consumable
  - other consumables
  - personal hygiene
  - personal hygienes
---
# Personal Hygiene & Other Consumables

Personal Hygiene & Other Consumables: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Site Consumables](../site-consumables.md)
