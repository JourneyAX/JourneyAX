---
description: 'Food & Beverage: 9 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Food & Beverage
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cleaning-and-consumables/site-consumables/food-and-beverage
  contentHash: 4b021dbf758c63aeba6ef0a956550422385b66df5810e71b434d524f5f95b205
  customerPhrases:
    - energy drink
    - sugar free drink
    - diet energy
    - canned energy
    - energy can 500ml
    - vitamin energy
    - guarana drink
    - wide neck bottle energy
  description: 'Food & Beverage: 9 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:03:41.487Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Food & Beverage
          path:
            - Cleaning & Consumables
            - Site Consumables
            - Food & Beverage
          products: 9
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Food & Beverage
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cleaning & Consumables
        - Site Consumables
        - Food & Beverage
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - beverage
    - beverages
    - food
    - foods
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 013f53812453da197e9b9505e3c6807b7a680ae95da5f93f287e8118a8e7e021
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cleaning-and-consumables/site-consumables/food-and-beverage
    relationshipId: rel-cleaning-and-consumables--site-consumables--food-and-beverage-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cleaning-and-consumables/site-consumables
    type: child_of
x-journeyax-synonyms:
  - beverage
  - beverages
  - food
  - foods
---
# Food & Beverage

Food & Beverage: 9 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Site Consumables](../site-consumables.md)
