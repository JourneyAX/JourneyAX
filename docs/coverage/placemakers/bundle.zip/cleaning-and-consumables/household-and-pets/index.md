# cleaning-and-consumables/household-and-pets

* [Household](household.md) - Household: 39 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Pet Care](pet-care.md) - Pet Care: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
