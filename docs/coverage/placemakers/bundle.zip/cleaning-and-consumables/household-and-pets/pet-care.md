---
description: 'Pet Care: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Pet Care
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cleaning-and-consumables/household-and-pets/pet-care
  contentHash: f4da1a64d78e17eac0a93d653786e7fdc96cef40933a3bb40a7085f0a5e2a6f8
  customerPhrases:
    - layer pellets
    - chicken pellets
    - poultry feed
    - laying hen feed
    - egg layer pellets
    - feed for layers
    - hen food
    - backyard chicken feed
  description: 'Pet Care: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:07:34.457Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Pet Care
          path:
            - Cleaning & Consumables
            - Household & Pets
            - Pet Care
          products: 1
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Pet Care
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cleaning & Consumables
        - Household & Pets
        - Pet Care
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - pet cares
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: df66aad4e2501b30175087dad210f976a0e35f550135906338e4907d6a4a6b81
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cleaning-and-consumables/household-and-pets/pet-care
    relationshipId: rel-cleaning-and-consumables--household-and-pets--pet-care-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cleaning-and-consumables/household-and-pets
    type: child_of
x-journeyax-synonyms:
  - pet cares
---
# Pet Care

Pet Care: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Household & Pets](../household-and-pets.md)
