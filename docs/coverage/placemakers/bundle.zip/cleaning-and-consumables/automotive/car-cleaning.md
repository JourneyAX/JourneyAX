---
description: 'Car Cleaning: 35 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Car Cleaning
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cleaning-and-consumables/automotive/car-cleaning
  contentHash: bd520a799c209ab2de68312719634712c27e084b69a5db24811657b1af3de825
  customerPhrases:
    - adhesive remover
    - wash brush with hose
    - paint stripper gel
    - boat wash brush
    - degreaser 5l
    - car washing brush
    - biodegradable cleaner
    - silicone spray lubricant
  description: 'Car Cleaning: 35 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-6d28cb493414
    - src-doc-bf56f01b365d
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:07.761Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Car Cleaning
          path:
            - Cleaning & Consumables
            - Automotive
            - Car Cleaning
          products: 35
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Car Cleaning
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cleaning & Consumables
        - Automotive
        - Car Cleaning
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - car cleanings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 8556b52e7b3f1f978dae94d54eb571949e702c7c6ef4615a5ea9ef9e879a3238
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cleaning-and-consumables/automotive/car-cleaning
    relationshipId: rel-cleaning-and-consumables--automotive--car-cleaning-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cleaning-and-consumables/automotive
    type: child_of
  - claimClasses: []
    confidence: medium
    contentHash: 0176ee869d4c3b579f7f545e70a1f17a63005b4dd7b71a7e7eb8e2b372616099
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: families
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cleaning-and-consumables/automotive/car-cleaning
    relationshipId: rel-family-cleaning_supplies-car-cleaning
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/families/cleaning-supplies
    type: child_of
x-journeyax-synonyms:
  - car cleanings
---
# Car Cleaning

Car Cleaning: 35 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Automotive](../automotive.md)
* child of: [Cleaning supplies](../../families/cleaning-supplies.md)
