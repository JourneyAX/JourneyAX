---
description: 'Petrol Cans: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Petrol Cans
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cleaning-and-consumables/automotive/petrol-cans
  contentHash: 26fa228e6408030e141f6e1ebbde95c63ebe3025a3bdc130e7f362e263c7e826
  customerPhrases:
    - fuel container
    - jerry can
    - plastic fuel can
    - diesel can yellow
    - petrol jug
    - self venting can
    - spill proof fuel can
    - crush proof can
  description: 'Petrol Cans: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:05:32.414Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Petrol Cans
          path:
            - Cleaning & Consumables
            - Automotive
            - Petrol Cans
          products: 4
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Petrol Cans
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cleaning & Consumables
        - Automotive
        - Petrol Cans
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - can
    - cans
    - petrol can
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: ad10499ced0d7b674010a3728ca4a18a3c5201cf510a51f0103a52ac134659e3
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cleaning-and-consumables/automotive/petrol-cans
    relationshipId: rel-cleaning-and-consumables--automotive--petrol-cans-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cleaning-and-consumables/automotive
    type: child_of
x-journeyax-synonyms:
  - can
  - cans
  - petrol can
---
# Petrol Cans

Petrol Cans: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Automotive](../automotive.md)
