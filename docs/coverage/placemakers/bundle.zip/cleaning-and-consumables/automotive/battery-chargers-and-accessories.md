---
description: 'Battery Chargers & Accessories: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Battery Chargers & Accessories
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cleaning-and-consumables/automotive/battery-chargers-and-accessories
  contentHash: 1244b5ed4ac61ccf4c7f10415992603d2e972bb482712935bae0fdf75fdea3d8
  customerPhrases:
    - battery adapter
    - tool battery connector
    - 18v battery plug
    - 20v battery lead
    - power tool battery adapter
    - battery conversion connector
    - brand specific battery adapter
    - battery pack connector
  description: 'Battery Chargers & Accessories: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:06:53.279Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Battery Chargers & Accessories
          path:
            - Cleaning & Consumables
            - Automotive
            - Battery Chargers & Accessories
          products: 2
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Battery Chargers & Accessories
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cleaning & Consumables
        - Automotive
        - Battery Chargers & Accessories
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - battery chargers
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 3bc49b87e937eed33027688b984d942152d33495b7e6780909d6d5ec7be09729
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cleaning-and-consumables/automotive/battery-chargers-and-accessories
    relationshipId: rel-cleaning-and-consumables--automotive--battery-chargers-and-accessories-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cleaning-and-consumables/automotive
    type: child_of
x-journeyax-synonyms:
  - battery chargers
---
# Battery Chargers & Accessories

Battery Chargers & Accessories: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Automotive](../automotive.md)
