# cleaning-and-consumables/automotive

* [Battery Chargers & Accessories](battery-chargers-and-accessories.md) - Battery Chargers & Accessories: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Car Cleaning](car-cleaning.md) - Car Cleaning: 35 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Petrol Cans](petrol-cans.md) - Petrol Cans: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
