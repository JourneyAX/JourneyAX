# problems

* [Bathroom leak](bathroom-leak.md) - Water leaking in or around a bathroom.
* [Blocked drain](blocked-drain.md) - A blocked sink, toilet or drain.
* [Electrical hazard](electrical-hazard.md) - A sparking, hot, damaged or wet electrical fitting.
* [Gas hazard](gas-hazard.md) - A suspected gas leak or smell.
* [Leaking tap or pipe](leaking-tap-or-pipe.md) - A dripping tap or leaking pipe.
* [Mould and damp](mould-and-damp.md) - Mould, damp or condensation in the home.
