---
description: A sparking, hot, damaged or wet electrical fitting.
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Electrical hazard
type: symptom
x-journeyax-concept:
  commercePolicy:
    addToCart: blocked
    checkout: blocked
  compatibilitySensitive: false
  conceptId: concept://placemakers/problems/electrical-hazard
  contentHash: a0f2a2864bfecfebc236461b06b1443927d944df4c1ef3def5b1b160534928cf
  customerPhrases:
    - electrical fault
    - power point sparking
    - switch is hot
    - water near power points
    - exposed wiring
    - burning smell from outlet
  description: A sparking, hot, damaged or wet electrical fitting.
  discriminators: []
  evidenceRefs:
    - src-authoring-proposal
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          id: electrical-hazard
          section: problems
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: problem
  lifecycle:
    status: active_draft
  name: Electrical hazard
  requiredFacts: []
  riskClass: safety_critical
  safety:
    blocksProducts: true
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: symptom
  version: 1
x-journeyax-relationships: []
---
# Electrical hazard

A sparking, hot, damaged or wet electrical fitting.
