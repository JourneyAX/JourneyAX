---
description: A dripping tap or leaking pipe.
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Leaking tap or pipe
type: symptom
x-journeyax-concept:
  commercePolicy:
    addToCart: blocked
    checkout: blocked
  compatibilitySensitive: false
  conceptId: concept://placemakers/problems/leaking-tap-or-pipe
  contentHash: 20fc85bc5d5f3372ff14cdeef061edebb80d32cb0cc9bfd7229d5beabb1067de
  customerPhrases:
    - tap is dripping
    - dripping tap
    - leaking pipe
    - burst pipe
    - pipe is leaking
    - tap is leaking
  description: A dripping tap or leaking pipe.
  discriminators: []
  evidenceRefs:
    - src-authoring-proposal
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          id: leaking-tap-or-pipe
          section: problems
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: problem
  lifecycle:
    status: active_draft
  name: Leaking tap or pipe
  requiredFacts:
    - factKey: tap_fixture_type
      importance: high
  riskClass: safety_critical
  safety:
    blocksProducts: true
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: symptom
  version: 1
x-journeyax-relationships: []
---
# Leaking tap or pipe

A dripping tap or leaking pipe.
