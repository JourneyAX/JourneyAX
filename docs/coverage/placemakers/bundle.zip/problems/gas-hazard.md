---
description: A suspected gas leak or smell.
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Gas hazard
type: symptom
x-journeyax-concept:
  commercePolicy:
    addToCart: blocked
    checkout: blocked
  compatibilitySensitive: false
  conceptId: concept://placemakers/problems/gas-hazard
  contentHash: a0c8dcc950097b2bdce66c226af63a49373eefe807e270bfc62206181613b592
  customerPhrases:
    - gas leak
    - smell gas
    - smells like gas
    - gas smell
  description: A suspected gas leak or smell.
  discriminators: []
  evidenceRefs:
    - src-authoring-proposal
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          id: gas-hazard
          section: problems
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: problem
  lifecycle:
    status: active_draft
  name: Gas hazard
  requiredFacts: []
  riskClass: safety_critical
  safety:
    blocksProducts: true
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: symptom
  version: 1
x-journeyax-relationships: []
---
# Gas hazard

A suspected gas leak or smell.
