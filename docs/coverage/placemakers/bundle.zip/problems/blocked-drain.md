---
description: A blocked sink, toilet or drain.
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Blocked drain
type: symptom
x-journeyax-concept:
  commercePolicy:
    addToCart: blocked
    checkout: blocked
  compatibilitySensitive: false
  conceptId: concept://placemakers/problems/blocked-drain
  contentHash: 19b706c795670552c58dabab3c3f9a79a00fa150987e359fca3abb7495aa038a
  customerPhrases:
    - blocked drain
    - drain is blocked
    - toilet is blocked
    - sink is blocked
    - slow draining sink
  description: A blocked sink, toilet or drain.
  discriminators: []
  evidenceRefs:
    - src-authoring-proposal
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          id: blocked-drain
          section: problems
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: problem
  lifecycle:
    status: active_draft
  name: Blocked drain
  requiredFacts:
    - factKey: blocked_drain_location
      importance: high
  riskClass: safety_critical
  safety:
    blocksProducts: true
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: symptom
  version: 1
x-journeyax-relationships: []
---
# Blocked drain

A blocked sink, toilet or drain.
