---
description: Mould, damp or condensation in the home.
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Mould and damp
type: symptom
x-journeyax-concept:
  commercePolicy:
    addToCart: blocked
    checkout: blocked
  compatibilitySensitive: false
  conceptId: concept://placemakers/problems/mould-and-damp
  contentHash: 2476cf4e2870cfbde90086545bee3c585c29914c423fe9755b3670ab0a055fc7
  customerPhrases:
    - mouldy walls
    - damp walls
    - mould in my bathroom
    - condensation problem
    - damp problem
  description: Mould, damp or condensation in the home.
  discriminators: []
  evidenceRefs:
    - src-authoring-proposal
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          id: mould-and-damp
          section: problems
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: problem
  lifecycle:
    status: active_draft
  name: Mould and damp
  requiredFacts:
    - factKey: mould_area
      importance: high
  riskClass: safety_critical
  safety:
    blocksProducts: true
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - mould problem
  tenantId: placemakers
  type: symptom
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - mould problem
---
# Mould and damp

Mould, damp or condensation in the home.
