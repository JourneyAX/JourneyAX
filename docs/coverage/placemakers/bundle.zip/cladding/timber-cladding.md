---
description: 'Timber Cladding: 126 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Timber Cladding
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/cladding/timber-cladding/weatherboard-radiata
      - concept://placemakers/cladding/timber-cladding/fascia-radiata
      - concept://placemakers/cladding/timber-cladding/cladding-plywood-exterior
      - concept://placemakers/cladding/timber-cladding/timber-cladding-other
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_cladding_timber_cladding
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cladding/timber-cladding
  contentHash: c418699d09f47ad5087653166ed71b5d5385df94f09f598fe5afe087257c632a
  customerPhrases: []
  description: 'Timber Cladding: 126 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_cladding_timber_cladding
      questionRef: q.nav_cladding_timber_cladding
      valueMap:
        cladding-plywood-exterior: concept://placemakers/cladding/timber-cladding/cladding-plywood-exterior
        fascia-radiata: concept://placemakers/cladding/timber-cladding/fascia-radiata
        timber-cladding-other: concept://placemakers/cladding/timber-cladding/timber-cladding-other
        weatherboard-radiata: concept://placemakers/cladding/timber-cladding/weatherboard-radiata
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-f923359526dc
    - src-doc-fc4f75744900
    - src-doc-1df7f8ec3c8a
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Timber Cladding
          path:
            - Cladding
            - Timber Cladding
          products: 126
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Timber Cladding
  requiredFacts:
    - factKey: nav_cladding_timber_cladding
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cladding
        - Timber Cladding
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - radiata
    - radiatas
    - timber claddings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 7acab2e2927c343bf4948a6b48135d68a68b6238eaca472817966b9aa4065ac6
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cladding/timber-cladding
    relationshipId: rel-cladding--timber-cladding-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cladding
    type: child_of
x-journeyax-synonyms:
  - radiata
  - radiatas
  - timber claddings
---
# Timber Cladding

Timber Cladding: 126 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Cladding](../cladding.md)
