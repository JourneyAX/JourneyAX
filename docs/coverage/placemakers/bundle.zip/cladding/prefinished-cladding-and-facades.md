---
description: 'Prefinished Cladding & Facades: 125 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Prefinished Cladding & Facades
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/cladding/prefinished-cladding-and-facades/panelised-cladding-systems
      - concept://placemakers/cladding/prefinished-cladding-and-facades/pvc
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_cladding_prefinished_cladding_and_facades
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cladding/prefinished-cladding-and-facades
  contentHash: 208b7148abce232721ad4bcd355fcfc241eeed81c44dfe9054c3e1066923b95e
  customerPhrases: []
  description: 'Prefinished Cladding & Facades: 125 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_cladding_prefinished_cladding_and_facades
      questionRef: q.nav_cladding_prefinished_cladding_and_facades
      valueMap:
        panelised-cladding-systems: concept://placemakers/cladding/prefinished-cladding-and-facades/panelised-cladding-systems
        pvc: concept://placemakers/cladding/prefinished-cladding-and-facades/pvc
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-a992d27e75a9
    - src-doc-329c66923019
    - src-doc-9415f1a81333
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Prefinished Cladding & Facades
          path:
            - Cladding
            - Prefinished Cladding & Facades
          products: 125
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Prefinished Cladding & Facades
  requiredFacts:
    - factKey: nav_cladding_prefinished_cladding_and_facades
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cladding
        - Prefinished Cladding & Facades
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - facade
    - facades
    - prefinished cladding
    - prefinished claddings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 937b10ea32bb02a6c8167fcf1156d7118d4c5200bb67935678e2d200500e49a5
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cladding/prefinished-cladding-and-facades
    relationshipId: rel-cladding--prefinished-cladding-and-facades-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cladding
    type: child_of
x-journeyax-synonyms:
  - facade
  - facades
  - prefinished cladding
  - prefinished claddings
---
# Prefinished Cladding & Facades

Prefinished Cladding & Facades: 125 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Cladding](../cladding.md)
