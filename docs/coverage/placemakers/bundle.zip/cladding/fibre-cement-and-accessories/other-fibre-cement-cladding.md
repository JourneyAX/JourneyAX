---
description: 'Other Fibre Cement Cladding: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Other Fibre Cement Cladding
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cladding/fibre-cement-and-accessories/other-fibre-cement-cladding
  contentHash: 9d80bdc65df8196a1fa4d6a9ee8c957e94603c15c1a8247e438939d7253db1a9
  customerPhrases:
    - shera board sheets
    - fibre cement board 12mm
    - fibre cement board 20mm
    - square edge cement sheet
    - medium density fibre cement
    - expressed joint cladding
    - butt joint cladding
    - special order cement board
  description: 'Other Fibre Cement Cladding: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:06:47.511Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Other Fibre Cement Cladding
          path:
            - Cladding
            - Fibre Cement & Accessories
            - Other Fibre Cement Cladding
          products: 2
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Other Fibre Cement Cladding
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cladding
        - Fibre Cement & Accessories
        - Other Fibre Cement Cladding
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - other fibre cement claddings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 60e77e5a9e1fb6ff8d54fdb2ca9397d21e549a8ba5c19dcf6c692504076e1288
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cladding/fibre-cement-and-accessories/other-fibre-cement-cladding
    relationshipId: rel-cladding--fibre-cement-and-accessories--other-fibre-cement-cladding-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cladding/fibre-cement-and-accessories
    type: child_of
x-journeyax-synonyms:
  - other fibre cement claddings
---
# Other Fibre Cement Cladding

Other Fibre Cement Cladding: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Fibre Cement & Accessories (Cladding)](../fibre-cement-and-accessories.md)
