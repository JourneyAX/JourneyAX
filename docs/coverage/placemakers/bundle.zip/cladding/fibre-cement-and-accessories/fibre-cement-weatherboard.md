---
description: 'Fibre Cement Weatherboard: 74 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Fibre Cement Weatherboard
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cladding/fibre-cement-and-accessories/fibre-cement-weatherboard
  contentHash: f9bdb4254dcd9a5a7dd35eeb461ef0387da071ef5b1a17eb166976a235fd8f25
  customerPhrases:
    - fire resistant cladding
    - cement cladding
    - hardie lookalike
    - cladding planks
    - external cladding boards
    - horizontal weatherboard
    - vertical cladding
    - grooved board
  description: 'Fibre Cement Weatherboard: 74 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-bc58398fce55
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:49.882Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Fibre Cement Weatherboard
          path:
            - Cladding
            - Fibre Cement & Accessories
            - Fibre Cement Weatherboard
          products: 74
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Fibre Cement Weatherboard
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cladding
        - Fibre Cement & Accessories
        - Fibre Cement Weatherboard
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - fibre cement weatherboards
    - weatherboard
    - weatherboards
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 94a638d5caf75212cb60648aab56eecb1a1758fb6e6f11c29f1417c0d8604e0a
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cladding/fibre-cement-and-accessories/fibre-cement-weatherboard
    relationshipId: rel-cladding--fibre-cement-and-accessories--fibre-cement-weatherboard-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cladding/fibre-cement-and-accessories
    type: child_of
x-journeyax-synonyms:
  - fibre cement weatherboards
  - weatherboard
  - weatherboards
---
# Fibre Cement Weatherboard

Fibre Cement Weatherboard: 74 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Fibre Cement & Accessories (Cladding)](../fibre-cement-and-accessories.md)
