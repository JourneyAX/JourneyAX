---
description: 'PVC: 54 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: PVC
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cladding/prefinished-cladding-and-facades/pvc
  contentHash: 02df3a1ae01cb3122c8a223e5636980bd8b6cbcffcd7079feadea377ac3a1d02
  customerPhrases:
    - vented cavity strip
    - cavity closer vent
    - vinyl weatherboard
    - upvc cavity seal
    - upvc cladding
    - wall cavity vent strip
    - plastic weatherboard
    - cavity tie pack
  description: 'PVC: 54 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-a992d27e75a9
    - src-doc-329c66923019
    - src-doc-9415f1a81333
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:30.602Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - PVC
          path:
            - Cladding
            - Prefinished Cladding & Facades
            - PVC
          products: 54
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: PVC
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cladding
        - Prefinished Cladding & Facades
        - PVC
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - pvcs
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 3e10934d08bdee4a7402fc1266da4f9242228c1cc446ddbfbd61f801a276f727
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cladding/prefinished-cladding-and-facades/pvc
    relationshipId: rel-cladding--prefinished-cladding-and-facades--pvc-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cladding/prefinished-cladding-and-facades
    type: child_of
x-journeyax-synonyms:
  - pvcs
---
# PVC

PVC: 54 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Prefinished Cladding & Facades](../prefinished-cladding-and-facades.md)
