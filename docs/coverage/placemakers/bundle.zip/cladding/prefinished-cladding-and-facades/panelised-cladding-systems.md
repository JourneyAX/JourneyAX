---
description: 'Panelised Cladding Systems: 71 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Panelised Cladding Systems
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cladding/prefinished-cladding-and-facades/panelised-cladding-systems
  contentHash: cd310c3ff3870e1e84dd67a911bb502bbc7c85495544c51b27c09ed2d2e135bf
  customerPhrases:
    - panelised facade panels
    - clip system cladding
    - prefinished facade panels
    - woodgrain facade boards
    - composite facade panels
    - quick install cladding
    - seamless cladding panels
    - architectural cladding panels
  description: 'Panelised Cladding Systems: 71 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:52.162Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Panelised Cladding Systems
          path:
            - Cladding
            - Prefinished Cladding & Facades
            - Panelised Cladding Systems
          products: 71
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Panelised Cladding Systems
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cladding
        - Prefinished Cladding & Facades
        - Panelised Cladding Systems
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - panelised cladding system
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 22336873f72b84bcde1b0cde31b015956ebc4c312a8cc8f5d2a319ee80477d02
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cladding/prefinished-cladding-and-facades/panelised-cladding-systems
    relationshipId: rel-cladding--prefinished-cladding-and-facades--panelised-cladding-systems-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cladding/prefinished-cladding-and-facades
    type: child_of
x-journeyax-synonyms:
  - panelised cladding system
---
# Panelised Cladding Systems

Panelised Cladding Systems: 71 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Prefinished Cladding & Facades](../prefinished-cladding-and-facades.md)
