# cladding/prefinished-cladding-and-facades

* [PVC](pvc.md) - PVC: 54 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Panelised Cladding Systems](panelised-cladding-systems.md) - Panelised Cladding Systems: 71 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
