---
description: 'Fibre Cement & Accessories: 76 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Fibre Cement & Accessories (Cladding)
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/cladding/fibre-cement-and-accessories/fibre-cement-weatherboard
      - concept://placemakers/cladding/fibre-cement-and-accessories/other-fibre-cement-cladding
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_cladding_fibre_cement_and_accessories
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cladding/fibre-cement-and-accessories
  contentHash: f231edd0c4e25d4322e4ddfa7161d3547839e4eb8b5c6cb720b37e1ede2254ad
  customerPhrases: []
  description: 'Fibre Cement & Accessories: 76 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_cladding_fibre_cement_and_accessories
      questionRef: q.nav_cladding_fibre_cement_and_accessories
      valueMap:
        fibre-cement-weatherboard: concept://placemakers/cladding/fibre-cement-and-accessories/fibre-cement-weatherboard
        other-fibre-cement-cladding: concept://placemakers/cladding/fibre-cement-and-accessories/other-fibre-cement-cladding
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-bc58398fce55
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Fibre Cement & Accessories
          path:
            - Cladding
            - Fibre Cement & Accessories
          products: 76
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Fibre Cement & Accessories (Cladding)
  requiredFacts:
    - factKey: nav_cladding_fibre_cement_and_accessories
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cladding
        - Fibre Cement & Accessories
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: cf1fcc79c02a58e13862d4fba2ac2f859b3c98029b47f6ba526b0890d46d0cde
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cladding/fibre-cement-and-accessories
    relationshipId: rel-cladding--fibre-cement-and-accessories-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cladding
    type: child_of
---
# Fibre Cement & Accessories (Cladding)

Fibre Cement & Accessories: 76 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Cladding](../cladding.md)
