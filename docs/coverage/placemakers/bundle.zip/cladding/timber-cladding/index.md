# cladding/timber-cladding

* [Cladding Plywood Exterior](cladding-plywood-exterior.md) - Cladding Plywood Exterior: 15 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Fascia Radiata](fascia-radiata.md) - Fascia Radiata: 23 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Timber Cladding Other](timber-cladding-other.md) - Timber Cladding Other: 13 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Weatherboard Radiata](weatherboard-radiata.md) - Weatherboard Radiata: 75 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
