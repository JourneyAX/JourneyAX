---
description: 'Weatherboard Radiata: 75 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Weatherboard Radiata
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cladding/timber-cladding/weatherboard-radiata
  contentHash: 53fcd13e70f73ed9dba78b6f1cb91ab75b1b3ef7832aa4c30b4065de3b630737
  customerPhrases:
    - bevel back weatherboard
    - radiata shiplap
    - timber weatherboards
    - shiplap cladding
    - pine weatherboard
    - radiata pine cladding
    - radiata weatherboard
    - clearwood cladding
    - bevel back
    - bevelback
    - bevel back weatherboards
    - rusticated
    - rusticated weatherboards
  description: 'Weatherboard Radiata: 75 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-fc4f75744900
    - src-doc-1df7f8ec3c8a
    - src-doc-bf13e7f1f5b5
  extensions:
    x-journeyax-provenance:
      alias_bevel_back:
        detail:
          alias: bevel_back
          reason: Bevel back and rusticated are the common names for weatherboards.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:36.591Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Weatherboard Radiata
          path:
            - Cladding
            - Timber Cladding
            - Weatherboard Radiata
          products: 75
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Weatherboard Radiata
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cladding
        - Timber Cladding
        - Weatherboard Radiata
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - weatherboard radiatas
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 0d786a74e8e34f61dbf6c0858a3529d0674294e91da5b01969f56f22b9698074
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cladding/timber-cladding/weatherboard-radiata
    relationshipId: rel-cladding--timber-cladding--weatherboard-radiata-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cladding/timber-cladding
    type: child_of
x-journeyax-synonyms:
  - weatherboard radiatas
---
# Weatherboard Radiata

Weatherboard Radiata: 75 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Timber Cladding](../timber-cladding.md)
