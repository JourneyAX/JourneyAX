---
description: 'Timber Cladding Other: 13 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Timber Cladding Other
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cladding/timber-cladding/timber-cladding-other
  contentHash: f8b13110ba7d3c037923a53351ff5e4891ec39cc14ca2dea090909fe46f237cf
  customerPhrases: []
  description: 'Timber Cladding Other: 13 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Timber Cladding Other
          path:
            - Cladding
            - Timber Cladding
            - Timber Cladding Other
          products: 13
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Timber Cladding Other
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cladding
        - Timber Cladding
        - Timber Cladding Other
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - timber cladding others
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 600e178b73de0396e3f25d102b1274aeaa5f67cc43c01de8c46f5cf4c549a565
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cladding/timber-cladding/timber-cladding-other
    relationshipId: rel-cladding--timber-cladding--timber-cladding-other-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cladding/timber-cladding
    type: child_of
x-journeyax-synonyms:
  - timber cladding others
---
# Timber Cladding Other

Timber Cladding Other: 13 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Timber Cladding](../timber-cladding.md)
