---
description: 'Cladding Plywood Exterior: 15 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Cladding Plywood Exterior
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cladding/timber-cladding/cladding-plywood-exterior
  contentHash: fe54fe12071410db0c9deb6b8c5dcad860144d548bb2fd59c9dfff5a9177a0e5
  customerPhrases:
    - v groove cladding
    - shadowclad groove
    - grooved plywood cladding
    - band sawn cladding
    - radiata plywood cladding
    - exterior plywood panels
    - texture plywood cladding
    - downgrade cladding plywood
  description: 'Cladding Plywood Exterior: 15 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-f923359526dc
    - src-doc-153a8b9ec708
    - src-doc-ff7905851e04
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:02:25.392Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Cladding Plywood Exterior
          path:
            - Cladding
            - Timber Cladding
            - Cladding Plywood Exterior
          products: 15
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Cladding Plywood Exterior
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cladding
        - Timber Cladding
        - Cladding Plywood Exterior
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - cladding plywood exteriors
    - exterior
    - exteriors
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 5b0eae2597fda1d7a987d0bdf4b91100dc745c199f0c98a5d63d37f64d805340
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cladding/timber-cladding/cladding-plywood-exterior
    relationshipId: rel-cladding--timber-cladding--cladding-plywood-exterior-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cladding/timber-cladding
    type: child_of
x-journeyax-synonyms:
  - cladding plywood exteriors
  - exterior
  - exteriors
---
# Cladding Plywood Exterior

Cladding Plywood Exterior: 15 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Timber Cladding](../timber-cladding.md)
