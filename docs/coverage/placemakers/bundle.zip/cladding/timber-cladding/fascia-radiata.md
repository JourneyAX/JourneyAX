---
description: 'Fascia Radiata: 23 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Fascia Radiata
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/cladding/timber-cladding/fascia-radiata
  contentHash: 5f123b8abffba137cbc3d9115d3635ed43a450d95b41b0492524827dddda6c06
  customerPhrases:
    - barge board
    - fascia board 40mm
    - roofline trim
    - radiata timber board
    - rim board
    - gutter support board
    - pre primed fascia
    - soffit groove fascia
  description: 'Fascia Radiata: 23 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:03:39.249Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Fascia Radiata
          path:
            - Cladding
            - Timber Cladding
            - Fascia Radiata
          products: 23
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Fascia Radiata
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Cladding
        - Timber Cladding
        - Fascia Radiata
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - fascia radiatas
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 65da6838dc3c2ef2db3c854f28ee522be3991c51c63fb649923a6961192f9b2c
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/cladding/timber-cladding/fascia-radiata
    relationshipId: rel-cladding--timber-cladding--fascia-radiata-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/cladding/timber-cladding
    type: child_of
x-journeyax-synonyms:
  - fascia radiatas
---
# Fascia Radiata

Fascia Radiata: 23 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Timber Cladding](../timber-cladding.md)
