# cladding

* [Fibre Cement & Accessories (Cladding)](fibre-cement-and-accessories.md) - Fibre Cement & Accessories: 76 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Prefinished Cladding & Facades](prefinished-cladding-and-facades.md) - Prefinished Cladding & Facades: 125 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Timber Cladding](timber-cladding.md) - Timber Cladding: 126 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [fibre-cement-and-accessories](fibre-cement-and-accessories/) - Knowledge and references
* [prefinished-cladding-and-facades](prefinished-cladding-and-facades/) - Knowledge and references
* [timber-cladding](timber-cladding/) - Knowledge and references
