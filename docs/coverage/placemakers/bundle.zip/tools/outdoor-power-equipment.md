---
description: 'Outdoor Power Equipment: 291 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Outdoor Power Equipment
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/tools/outdoor-power-equipment/line-trimmers
      - concept://placemakers/tools/outdoor-power-equipment/chain-saws
      - concept://placemakers/tools/outdoor-power-equipment/hedge-trimmers
      - concept://placemakers/tools/outdoor-power-equipment/blower-vacuums
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_tools_outdoor_power_equipment
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/tools/outdoor-power-equipment
  contentHash: c8d8756b43facb7aebe101b54b715dcc62a68a79e053f366a1c22c59faedf9cb
  customerPhrases:
    - pole saw attachment
    - battery powered brushcutter
    - quik lok attachment
    - kit with battery
  description: 'Outdoor Power Equipment: 291 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_tools_outdoor_power_equipment
      questionRef: q.nav_tools_outdoor_power_equipment
      valueMap:
        blower-vacuums: concept://placemakers/tools/outdoor-power-equipment/blower-vacuums
        brushcutters: concept://placemakers/tools/outdoor-power-equipment/brushcutters
        chain-saws: concept://placemakers/tools/outdoor-power-equipment/chain-saws
        garden-shredders: concept://placemakers/tools/outdoor-power-equipment/garden-shredders
        hedge-trimmers: concept://placemakers/tools/outdoor-power-equipment/hedge-trimmers
        lawn-mowers: concept://placemakers/tools/outdoor-power-equipment/lawn-mowers
        line-trimmers: concept://placemakers/tools/outdoor-power-equipment/line-trimmers
        waterblasters: concept://placemakers/tools/outdoor-power-equipment/waterblasters
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-a1dc54e41510
    - src-doc-ff2948cceda4
    - src-doc-9f9b5bb20879
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Outdoor Power Equipment
          path:
            - Tools
            - Outdoor Power Equipment
          products: 291
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Outdoor Power Equipment
  requiredFacts:
    - factKey: nav_tools_outdoor_power_equipment
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Tools
        - Outdoor Power Equipment
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - equipment
    - equipments
    - outdoor power equipments
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 1bb7525c4d84bb5849e36c20ccf9f001910c0e24d19ac43a31ac046c9cf53344
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/tools/outdoor-power-equipment
    relationshipId: rel-tools--outdoor-power-equipment-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/tools
    type: child_of
x-journeyax-synonyms:
  - equipment
  - equipments
  - outdoor power equipments
---
# Outdoor Power Equipment

Outdoor Power Equipment: 291 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Tools](../tools.md)
