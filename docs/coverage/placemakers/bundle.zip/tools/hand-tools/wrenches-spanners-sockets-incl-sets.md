---
description: 'Wrenches/Spanners/Sockets (Incl Sets): 312 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Wrenches/Spanners/Sockets (Incl Sets)
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/tools/hand-tools/wrenches-spanners-sockets-incl-sets
  contentHash: 25eedba4b0454f1611f2e59c5edbf4a962a7d156a2dc8bfd3cb713bb8d43e0b3
  customerPhrases:
    - spanner set
    - ratchet sockets
    - allen keys
    - tube spanner
    - impact driver bit set
    - ratchet spanner
    - hex key set
    - tap spanner
    - shifter
    - shifters
    - adjustable spanner
    - adjustable wrench
    - crescent wrench
    - socket set
    - ring spanner
    - allen key
    - hex key
    - hex keys
  description: 'Wrenches/Spanners/Sockets (Incl Sets): 312 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_shifter:
        detail:
          alias: shifter
          reason: Shifter is the New Zealand word for an adjustable spanner.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:19.921Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Wrenches/Spanners/Sockets (Incl Sets)
          path:
            - Tools
            - Hand Tools
            - Wrenches/Spanners/Sockets (Incl Sets)
          products: 312
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Wrenches/Spanners/Sockets (Incl Sets)
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Tools
        - Hand Tools
        - Wrenches/Spanners/Sockets (Incl Sets)
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - sockets incl set
    - sockets incl sets
    - spanner
    - spanners
    - wrench
    - wrenches
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 29a3515b9e03ebd861d82aaa2a5d2314ef85ec94f2488b243ac4d5bd37a89671
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/tools/hand-tools/wrenches-spanners-sockets-incl-sets
    relationshipId: rel-tools--hand-tools--wrenches-spanners-sockets-incl-sets-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/tools/hand-tools
    type: child_of
x-journeyax-synonyms:
  - sockets incl set
  - sockets incl sets
  - spanner
  - spanners
  - wrench
  - wrenches
---
# Wrenches/Spanners/Sockets (Incl Sets)

Wrenches/Spanners/Sockets (Incl Sets): 312 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Hand Tools](../hand-tools.md)
