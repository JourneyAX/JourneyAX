---
description: 'Staple Guns/Hand Tackers: 26 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Staple Guns/Hand Tackers
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/tools/hand-tools/staple-guns-hand-tackers
  contentHash: fa37467e55e0217ad0d37da2c9121b7ac4774cbffda8ade3ae8ad873a4c911cf
  customerPhrases:
    - hand grease gun
    - texture sprayer
    - lever grease gun
    - plaster sprayer
    - manual stapler gun
    - cordless greasegun
    - stucco sprayer
    - upholstery stapler
    - staple gun
    - staple guns
    - tacker
    - hand tacker
  description: 'Staple Guns/Hand Tackers: 26 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_staple_gun:
        detail:
          alias: staple_gun
          reason: Customers say staple gun or tacker.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:02:03.939Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Staple Guns/Hand Tackers
          path:
            - Tools
            - Hand Tools
            - Staple Guns/Hand Tackers
          products: 26
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Staple Guns/Hand Tackers
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Tools
        - Hand Tools
        - Staple Guns/Hand Tackers
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - hand tacker
    - hand tackers
    - staple gun
    - staple guns
    - tacker
    - tackers
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: f958833b46d35eef813660a8ffd9ee79c6fc56985e75ea93d4d231428bc8a210
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/tools/hand-tools/staple-guns-hand-tackers
    relationshipId: rel-tools--hand-tools--staple-guns-hand-tackers-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/tools/hand-tools
    type: child_of
x-journeyax-synonyms:
  - hand tacker
  - hand tackers
  - staple gun
  - staple guns
  - tacker
  - tackers
---
# Staple Guns/Hand Tackers

Staple Guns/Hand Tackers: 26 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Hand Tools](../hand-tools.md)
