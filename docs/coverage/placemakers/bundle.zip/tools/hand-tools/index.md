# tools/hand-tools

* [Chisels](chisels.md) - Chisels: 96 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Clamps](clamps.md) - Clamps: 115 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Cutting / Bending](cutting-bending.md) - Cutting / Bending: 48 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Files & Planers](files-and-planers.md) - Files & Planers: 62 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Hammers & Mallets](hammers-and-mallets.md) - Hammers & Mallets: 179 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Knifes & Blades](knifes-and-blades.md) - Knifes & Blades: 183 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Landscape & Gardening](landscape-and-gardening.md) - Landscape & Gardening: 160 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Measuring Tools](measuring-tools.md) - Measuring Tools: 588 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Other Hand Tools](other-hand-tools.md) - Other Hand Tools: 56 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Plastering/Concrete/Brick Tools](plastering-concrete-brick-tools.md) - Plastering/Concrete/Brick Tools: 303 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Pliers](pliers.md) - Pliers: 196 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Plumbing Tools](plumbing-tools.md) - Plumbing Tools: 47 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Punches](punches.md) - Punches: 10 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Saws](saws.md) - Saws: 71 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Screwdrivers](screwdrivers.md) - Screwdrivers: 124 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Staple Guns/Hand Tackers](staple-guns-hand-tackers.md) - Staple Guns/Hand Tackers: 26 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Tool Storage](tool-storage.md) - Tool Storage: 331 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Vices](vices.md) - Vices: 3 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Workbenches](workbenches.md) - Workbenches: 50 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Wrenches/Spanners/Sockets (Incl Sets)](wrenches-spanners-sockets-incl-sets.md) - Wrenches/Spanners/Sockets (Incl Sets): 312 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
