---
description: 'Landscape & Gardening: 160 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Landscape & Gardening
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/tools/hand-tools/landscape-and-gardening
  contentHash: 8174a07ad2f3187637cf70e4a892cbe0ff6303418cd2d8ef3c7f3b5bc018ae09
  customerPhrases:
    - round point shovel
    - pruning lopper
    - d handle replacement
    - d grip shovel
    - post rammer
    - spare axe handle
    - hedge trimmers manual
    - landscaper rake
  description: 'Landscape & Gardening: 160 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-f72fe528fe98
    - src-doc-38818ad14ae6
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:51.684Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Landscape & Gardening
          path:
            - Tools
            - Hand Tools
            - Landscape & Gardening
          products: 160
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Landscape & Gardening
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Tools
        - Hand Tools
        - Landscape & Gardening
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - gardening
    - gardenings
    - landscape
    - landscapes
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 2fb68be7e9ed222537eb5d0edfb214286f59f54b3fb119fa82403c538111e6d5
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/tools/hand-tools/landscape-and-gardening
    relationshipId: rel-tools--hand-tools--landscape-and-gardening-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/tools/hand-tools
    type: child_of
x-journeyax-synonyms:
  - gardening
  - gardenings
  - landscape
  - landscapes
---
# Landscape & Gardening

Landscape & Gardening: 160 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Hand Tools](../hand-tools.md)
