---
description: 'Plastering/Concrete/Brick Tools: 303 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Plastering/Concrete/Brick Tools
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/tools/hand-tools/plastering-concrete-brick-tools
  contentHash: 26c3f54f5305a0765d1e876a89cc037277c0db18b28ec3033d3845c8422c8b4c
  customerPhrases:
    - filler knife
    - brickie trowel
    - plastering tools
    - concrete edger
    - concrete screed board
    - walking trowel
    - render float
    - drywall taping knife
  description: 'Plastering/Concrete/Brick Tools: 303 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-4c434cd24069
    - src-doc-fc84b5ff057d
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:00.499Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Plastering/Concrete/Brick Tools
          path:
            - Tools
            - Hand Tools
            - Plastering/Concrete/Brick Tools
          products: 303
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Plastering/Concrete/Brick Tools
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Tools
        - Hand Tools
        - Plastering/Concrete/Brick Tools
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - brick tool
    - brick tools
    - plastering
    - plasterings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: a20413d203696ed8c75b3cdb1eee449a03abf4125e58a641804c343cd96ddb39
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/tools/hand-tools/plastering-concrete-brick-tools
    relationshipId: rel-tools--hand-tools--plastering-concrete-brick-tools-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/tools/hand-tools
    type: child_of
x-journeyax-synonyms:
  - brick tool
  - brick tools
  - plastering
  - plasterings
---
# Plastering/Concrete/Brick Tools

Plastering/Concrete/Brick Tools: 303 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Hand Tools](../hand-tools.md)
