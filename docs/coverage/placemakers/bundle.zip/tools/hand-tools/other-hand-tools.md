---
description: 'Other Hand Tools: 56 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Other Hand Tools
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/tools/hand-tools/other-hand-tools
  contentHash: 4530d71e8306cc9d07763bc22be3c9bbcf5934cf2f1261fcec0f52df84db383e
  customerPhrases:
    - insulated drink mug
    - dowel jig
    - pipe die set
    - hose pick set
    - drywall lifter
    - lifting jack
    - worksite tumbler
    - dowel kit
    - crowbar
    - pry bar
    - wrecking bar
    - nail puller
    - cats paw
    - jemmy bar
  description: 'Other Hand Tools: 56 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-e5979ddb6b1f
    - src-doc-331c72198930
    - src-doc-13ddd9041404
  extensions:
    x-journeyax-provenance:
      alias_crowbar:
        detail:
          alias: crowbar
          reason: Crowbar, pry bar and jemmy bar are the same tool.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:37.748Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Other Hand Tools
          path:
            - Tools
            - Hand Tools
            - Other Hand Tools
          products: 56
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Other Hand Tools
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Tools
        - Hand Tools
        - Other Hand Tools
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - other hand tool
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: b3f4e28aa45d8de42e899d2ca92cc097edc939f8783b06428ea764d448bc5ec4
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/tools/hand-tools/other-hand-tools
    relationshipId: rel-tools--hand-tools--other-hand-tools-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/tools/hand-tools
    type: child_of
x-journeyax-synonyms:
  - other hand tool
---
# Other Hand Tools

Other Hand Tools: 56 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Hand Tools](../hand-tools.md)
