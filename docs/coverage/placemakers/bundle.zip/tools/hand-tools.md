---
description: 'Hand Tools: 2,960 products across 20 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Hand Tools
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/tools/hand-tools/measuring-tools
      - concept://placemakers/tools/hand-tools/tool-storage
      - concept://placemakers/tools/hand-tools/wrenches-spanners-sockets-incl-sets
      - concept://placemakers/tools/hand-tools/plastering-concrete-brick-tools
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_tools_hand_tools
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/tools/hand-tools
  contentHash: b427b35d4abff6fa61b5f2bb9b9c8fc7ed2b13d7de29ba172f68bb6537173ad9
  customerPhrases:
    - timber marker
    - panel lifter
    - sheet lifter
    - plasterboard lifter
    - board jack
    - utility scissors
    - left handed scissors
    - heavy duty scissors
  description: 'Hand Tools: 2,960 products across 20 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_tools_hand_tools
      questionRef: q.nav_tools_hand_tools
      valueMap:
        chisels: concept://placemakers/tools/hand-tools/chisels
        clamps: concept://placemakers/tools/hand-tools/clamps
        cutting-bending: concept://placemakers/tools/hand-tools/cutting-bending
        files-and-planers: concept://placemakers/tools/hand-tools/files-and-planers
        hammers-and-mallets: concept://placemakers/tools/hand-tools/hammers-and-mallets
        knifes-and-blades: concept://placemakers/tools/hand-tools/knifes-and-blades
        landscape-and-gardening: concept://placemakers/tools/hand-tools/landscape-and-gardening
        measuring-tools: concept://placemakers/tools/hand-tools/measuring-tools
        other-hand-tools: concept://placemakers/tools/hand-tools/other-hand-tools
        plastering-concrete-brick-tools: concept://placemakers/tools/hand-tools/plastering-concrete-brick-tools
        pliers: concept://placemakers/tools/hand-tools/pliers
        plumbing-tools: concept://placemakers/tools/hand-tools/plumbing-tools
        punches: concept://placemakers/tools/hand-tools/punches
        saws: concept://placemakers/tools/hand-tools/saws
        screwdrivers: concept://placemakers/tools/hand-tools/screwdrivers
        staple-guns-hand-tackers: concept://placemakers/tools/hand-tools/staple-guns-hand-tackers
        tool-storage: concept://placemakers/tools/hand-tools/tool-storage
        vices: concept://placemakers/tools/hand-tools/vices
        workbenches: concept://placemakers/tools/hand-tools/workbenches
        wrenches-spanners-sockets-incl-sets: concept://placemakers/tools/hand-tools/wrenches-spanners-sockets-incl-sets
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-e5979ddb6b1f
    - src-doc-933ed9cb6795
    - src-doc-331c72198930
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Hand Tools
          path:
            - Tools
            - Hand Tools
          products: 2960
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Hand Tools
  requiredFacts:
    - factKey: nav_tools_hand_tools
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Tools
        - Hand Tools
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - hand tool
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 83c9c22d843b7c4cb3f401bc6f42b9a35297f56130ddf13de6a8904d522785cd
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/tools/hand-tools
    relationshipId: rel-tools--hand-tools-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/tools
    type: child_of
x-journeyax-synonyms:
  - hand tool
---
# Hand Tools

Hand Tools: 2,960 products across 20 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Tools](../tools.md)
