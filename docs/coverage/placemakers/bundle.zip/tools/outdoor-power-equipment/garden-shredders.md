---
description: 'Garden Shredders: 3 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Garden Shredders
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/tools/outdoor-power-equipment/garden-shredders
  contentHash: 2acf0146c1c481b887f67d8d556470d2a43e5edf16c14f805a105617dea79fb5
  customerPhrases:
    - petrol chipper
    - petrol wood chipper
    - garden chipper
    - wood shredder
    - brush chipper
    - garden mulch maker
    - lifestyle block chipper
    - domestic wood chipper
  description: 'Garden Shredders: 3 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:06:07.940Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Garden Shredders
          path:
            - Tools
            - Outdoor Power Equipment
            - Garden Shredders
          products: 3
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Garden Shredders
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Tools
        - Outdoor Power Equipment
        - Garden Shredders
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - garden shredder
    - shredder
    - shredders
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 73de027824069a5cd2390ef948925ac561351e1444d967554430b7cbf2cfed50
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/tools/outdoor-power-equipment/garden-shredders
    relationshipId: rel-tools--outdoor-power-equipment--garden-shredders-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/tools/outdoor-power-equipment
    type: child_of
x-journeyax-synonyms:
  - garden shredder
  - shredder
  - shredders
---
# Garden Shredders

Garden Shredders: 3 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Outdoor Power Equipment](../outdoor-power-equipment.md)
