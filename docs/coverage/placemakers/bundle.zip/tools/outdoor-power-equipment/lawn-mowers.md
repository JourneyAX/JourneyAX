---
description: 'Lawn Mowers: 34 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Lawn Mowers
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/tools/outdoor-power-equipment/lawn-mowers
  contentHash: 93b8ee6aa0b2ffb78a6d6109c77fc29f8c6a3fbaf31ffe718846b5b50428f22f
  customerPhrases:
    - battery mower
    - flail blades
    - petrol mower
    - cordless push mower
    - gas lawn mower
    - self propelled battery mower
    - lawn scarifier blades
    - push mower petrol
    - lawnmower
    - lawnmowers
    - mower
    - mowers
    - lawn mower
  description: 'Lawn Mowers: 34 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-9005cc1284b0
  extensions:
    x-journeyax-provenance:
      alias_lawnmower:
        detail:
          alias: lawnmower
          reason: Lawnmower is written as one word as often as two.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:51.571Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Lawn Mowers
          path:
            - Tools
            - Outdoor Power Equipment
            - Lawn Mowers
          products: 34
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Lawn Mowers
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Tools
        - Outdoor Power Equipment
        - Lawn Mowers
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - lawn mower
    - mower
    - mowers
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 0d3a44943ca679b818afdf41cdd35bd190e1621b93ddd10cd055f1ded1c3d0c7
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/tools/outdoor-power-equipment/lawn-mowers
    relationshipId: rel-tools--outdoor-power-equipment--lawn-mowers-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/tools/outdoor-power-equipment
    type: child_of
x-journeyax-synonyms:
  - lawn mower
  - mower
  - mowers
---
# Lawn Mowers

Lawn Mowers: 34 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Outdoor Power Equipment](../outdoor-power-equipment.md)
