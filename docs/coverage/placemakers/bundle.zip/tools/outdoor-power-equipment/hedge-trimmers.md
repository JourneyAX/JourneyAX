---
description: 'Hedge Trimmers: 59 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Hedge Trimmers
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/tools/outdoor-power-equipment/hedge-trimmers
  contentHash: 6ed77e8f31e8a50fbc2363a0415bb6dcbacf59e913e4869544a72de4715b66ca
  customerPhrases:
    - battery hedge trimmer
    - split shaft powerhead
    - cordless hedge trimmer
    - cordless hedgetrimmer
    - pole hedge attachment
    - rechargeable trimmer
    - power head kit
    - brushless hedge trimmer
  description: 'Hedge Trimmers: 59 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-ff2948cceda4
    - src-doc-9f9b5bb20879
    - src-doc-5c7644932946
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:22.504Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Hedge Trimmers
          path:
            - Tools
            - Outdoor Power Equipment
            - Hedge Trimmers
          products: 59
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Hedge Trimmers
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Tools
        - Outdoor Power Equipment
        - Hedge Trimmers
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - hedge trimmer
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: a2ac7c97b7bf0b4043bd4cbcff6aef500644cfe17f1393b08baee6871a67f8f3
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/tools/outdoor-power-equipment/hedge-trimmers
    relationshipId: rel-tools--outdoor-power-equipment--hedge-trimmers-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/tools/outdoor-power-equipment
    type: child_of
x-journeyax-synonyms:
  - hedge trimmer
---
# Hedge Trimmers

Hedge Trimmers: 59 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Outdoor Power Equipment](../outdoor-power-equipment.md)
