# tools/outdoor-power-equipment

* [Blower/Vacuums](blower-vacuums.md) - Blower/Vacuums: 43 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Brushcutters](brushcutters.md) - Brushcutters: 8 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Chain Saws](chain-saws.md) - Chain Saws: 64 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Garden Shredders](garden-shredders.md) - Garden Shredders: 3 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Hedge Trimmers](hedge-trimmers.md) - Hedge Trimmers: 59 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Lawn Mowers](lawn-mowers.md) - Lawn Mowers: 34 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Line Trimmers](line-trimmers.md) - Line Trimmers: 66 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Waterblasters](waterblasters.md) - Waterblasters: 14 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
