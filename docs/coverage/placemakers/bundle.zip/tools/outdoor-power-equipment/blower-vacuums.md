---
description: 'Blower/Vacuums: 43 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Blower/Vacuums
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/tools/outdoor-power-equipment/blower-vacuums
  contentHash: 7ce3a33ca67f8ade2efcbd6f07ed40a41da18509412346642b9a3d125a434ae5
  customerPhrases:
    - cordless leaf blower
    - cordless blower
    - gutter blower attachment
    - battery blower
    - leaf blower gutter kit
    - wireless blower
    - 18v blower
    - blower extension nozzle
  description: 'Blower/Vacuums: 43 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-8ec36b70032a
    - src-doc-c88992cada21
    - src-doc-b523758017f4
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:54.560Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Blower/Vacuums
          path:
            - Tools
            - Outdoor Power Equipment
            - Blower/Vacuums
          products: 43
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Blower/Vacuums
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Tools
        - Outdoor Power Equipment
        - Blower/Vacuums
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - blower
    - blowers
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 0acc6619a0effd43b75802a3f75eae2e382323e13ee0075dc8470789ed460c07
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/tools/outdoor-power-equipment/blower-vacuums
    relationshipId: rel-tools--outdoor-power-equipment--blower-vacuums-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/tools/outdoor-power-equipment
    type: child_of
x-journeyax-synonyms:
  - blower
  - blowers
---
# Blower/Vacuums

Blower/Vacuums: 43 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Outdoor Power Equipment](../outdoor-power-equipment.md)
