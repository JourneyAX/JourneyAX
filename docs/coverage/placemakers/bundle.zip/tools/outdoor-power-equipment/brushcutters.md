---
description: 'Brushcutters: 8 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Brushcutters
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/tools/outdoor-power-equipment/brushcutters
  contentHash: 967823762ba0ae64b9f01c07fe7c084ca4a7817ea2d55d9a2eb78b30a30ceee1
  customerPhrases:
    - split boom attachment
    - battery brushcutter
    - splitboom adaptor
    - 36v brush cutter
    - brush trimmer
    - 54v brushcutter accessory
    - lxt brushless cutter
    - brushcutter blade 4 tooth
  description: 'Brushcutters: 8 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:05:21.677Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Brushcutters
          path:
            - Tools
            - Outdoor Power Equipment
            - Brushcutters
          products: 8
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Brushcutters
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Tools
        - Outdoor Power Equipment
        - Brushcutters
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - brushcutter
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: e2f6032954d1a4a609a398308ecfb1b2687869773592748f8d8b6558cf505f5d
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/tools/outdoor-power-equipment/brushcutters
    relationshipId: rel-tools--outdoor-power-equipment--brushcutters-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/tools/outdoor-power-equipment
    type: child_of
x-journeyax-synonyms:
  - brushcutter
---
# Brushcutters

Brushcutters: 8 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Outdoor Power Equipment](../outdoor-power-equipment.md)
