---
description: 'Chain Saws: 64 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Chain Saws
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/tools/outdoor-power-equipment/chain-saws
  contentHash: a507debe69f18bafdd9c297d34e8689ab054a65bd752e4e5706817bb49ff9dbe
  customerPhrases:
    - battery chainsaw
    - sprocket nose bar
    - cordless chainsaw
    - 2 stroke oil
    - top handle chainsaw
    - cordless saw
    - guide bar replacement
    - two stroke mix oil
    - chainsaw
    - chainsaws
    - chain saw
  description: 'Chain Saws: 64 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-a1dc54e41510
    - src-doc-d99111c23f66
    - src-doc-fb795fe28c27
  extensions:
    x-journeyax-provenance:
      alias_chainsaw:
        detail:
          alias: chainsaw
          reason: Chainsaw is written as one word.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:36.500Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Chain Saws
          path:
            - Tools
            - Outdoor Power Equipment
            - Chain Saws
          products: 64
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Chain Saws
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Tools
        - Outdoor Power Equipment
        - Chain Saws
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - chain saw
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 7b98f61fef0d258894f328c039c9f4dbe34d0e43e7a688fcfd6d728057a43f61
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/tools/outdoor-power-equipment/chain-saws
    relationshipId: rel-tools--outdoor-power-equipment--chain-saws-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/tools/outdoor-power-equipment
    type: child_of
x-journeyax-synonyms:
  - chain saw
---
# Chain Saws

Chain Saws: 64 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Outdoor Power Equipment](../outdoor-power-equipment.md)
