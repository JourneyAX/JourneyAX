# tools

* [Hand Tools](hand-tools.md) - Hand Tools: 2,960 products across 20 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Outdoor Power Equipment](outdoor-power-equipment.md) - Outdoor Power Equipment: 291 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Power Tool Accessories](power-tool-accessories.md) - Power Tool Accessories: 3,614 products across 16 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Power Tools](power-tools.md) - Power Tools: 1,224 products across 28 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [hand-tools](hand-tools/) - Knowledge and references
* [outdoor-power-equipment](outdoor-power-equipment/) - Knowledge and references
* [power-tool-accessories](power-tool-accessories/) - Knowledge and references
* [power-tools](power-tools/) - Knowledge and references
