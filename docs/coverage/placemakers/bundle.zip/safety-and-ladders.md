---
description: 'Safety & Ladders: 1,919 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Safety & Ladders
type: department
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/safety-and-ladders/safety
      - concept://placemakers/safety-and-ladders/ladders-and-scaffolding
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_safety_and_ladders
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/safety-and-ladders
  contentHash: eb73c35415f528a4eebdf297ca6cce413cb89280235aa13a9061337bb8077d44
  customerPhrases: []
  description: 'Safety & Ladders: 1,919 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_safety_and_ladders
      questionRef: q.nav_safety_and_ladders
      valueMap:
        ladders-and-scaffolding: concept://placemakers/safety-and-ladders/ladders-and-scaffolding
        safety: concept://placemakers/safety-and-ladders/safety
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-95540e927e21
    - src-doc-261fbc37726d
    - src-doc-c176063b5c77
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Safety & Ladders
          path:
            - Safety & Ladders
          products: 1919
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Safety & Ladders
  requiredFacts:
    - factKey: nav_safety_and_ladders
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Safety & Ladders
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - ladder
    - safeties
  tenantId: placemakers
  type: department
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - ladder
  - safeties
---
# Safety & Ladders

Safety & Ladders: 1,919 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
