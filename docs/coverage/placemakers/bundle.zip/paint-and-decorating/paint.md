---
description: 'Paint: 716 products across 7 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Paint
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/paint-and-decorating/paint/interior-paint
      - concept://placemakers/paint-and-decorating/paint/woodcare
      - concept://placemakers/paint-and-decorating/paint/aerosol-paint
      - concept://placemakers/paint-and-decorating/paint/exterior-paint
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_paint_and_decorating_paint
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/paint-and-decorating/paint
  contentHash: 5bd44eeb6a1b18b9fa2a79a8e3ab879454675c611349f46b80b46b196bc7acad
  customerPhrases:
    - waterbased enamel
  description: 'Paint: 716 products across 7 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_paint_and_decorating_paint
      questionRef: q.nav_paint_and_decorating_paint
      valueMap:
        aerosol-paint: concept://placemakers/paint-and-decorating/paint/aerosol-paint
        exterior-paint: concept://placemakers/paint-and-decorating/paint/exterior-paint
        interior-paint: concept://placemakers/paint-and-decorating/paint/interior-paint
        primers-sealers-and-undercoats: concept://placemakers/paint-and-decorating/paint/primers-sealers-and-undercoats
        protective-coatings: concept://placemakers/paint-and-decorating/paint/protective-coatings
        tinters: concept://placemakers/paint-and-decorating/paint/tinters
        woodcare: concept://placemakers/paint-and-decorating/paint/woodcare
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-a4a35ac0e673
    - src-doc-faf796828143
    - src-doc-7757144255e8
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Paint
          path:
            - Paint & Decorating
            - Paint
          products: 716
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Paint
  requiredFacts:
    - factKey: nav_paint_and_decorating_paint
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Paint & Decorating
        - Paint
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 17566ee12672014f5bb23afb274c252aa9043bb356cc950e7f3db533372fbca4
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint
    relationshipId: rel-paint-and-decorating--paint-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/paint-and-decorating
    type: child_of
---
# Paint

Paint: 716 products across 7 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Paint & Decorating](../paint-and-decorating.md)
