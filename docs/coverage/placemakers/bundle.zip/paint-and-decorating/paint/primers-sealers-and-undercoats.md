---
description: 'Primers Sealers & Undercoats: 32 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Primers Sealers & Undercoats
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/paint-and-decorating/paint/primers-sealers-and-undercoats
  contentHash: 92cf0d858d375bea1818035965b11442a09ac58cba23dfa503ef9674cca51043
  customerPhrases:
    - stain blocker
    - adhesion primer
    - tannin blocker
    - rust primer
    - tile primer
    - sealer undercoat
    - glaze blocker
    - prepcoat
    - undercoat
    - undercoats
    - primer
    - primers
    - sealer
    - stain block
  description: 'Primers Sealers & Undercoats: 32 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-8b6615d538a7
    - src-doc-b3758f51c684
    - src-doc-e65e9a27e12b
  extensions:
    x-journeyax-provenance:
      alias_undercoat:
        detail:
          alias: undercoat
          reason: Customers ask for primer, undercoat and sealer.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:02:18.489Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Primers Sealers & Undercoats
          path:
            - Paint & Decorating
            - Paint
            - Primers Sealers & Undercoats
          products: 32
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Primers Sealers & Undercoats
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Paint & Decorating
        - Paint
        - Primers Sealers & Undercoats
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - primers sealer
    - primers sealers
    - sealer
    - sealers
    - undercoat
    - undercoats
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: df0012daa00de340d97942e1f4567f439327a69a15634a6ce010f555c70e2d4c
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint/primers-sealers-and-undercoats
    relationshipId: rel-paint-and-decorating--paint--primers-sealers-and-undercoats-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/paint-and-decorating/paint
    type: child_of
x-journeyax-synonyms:
  - primers sealer
  - primers sealers
  - sealer
  - sealers
  - undercoat
  - undercoats
---
# Primers Sealers & Undercoats

Primers Sealers & Undercoats: 32 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Paint](../paint.md)
