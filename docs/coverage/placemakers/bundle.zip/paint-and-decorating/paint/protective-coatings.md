---
description: 'Protective Coatings: 96 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Protective Coatings
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/paint-and-decorating/paint/protective-coatings
  contentHash: f9159767908787d583b260d17e3aaf88ee327ddb32f558cd31942cf337bbaa51
  customerPhrases:
    - rust converter
    - marine varnish
    - anti corrosion paint
    - boat varnish
    - metal primer
    - teak oil
    - rust inhibiting primer
    - spar varnish
  description: 'Protective Coatings: 96 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-a4a35ac0e673
    - src-doc-e202bb56a0d5
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:44.969Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Protective Coatings
          path:
            - Paint & Decorating
            - Paint
            - Protective Coatings
          products: 96
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Protective Coatings
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Paint & Decorating
        - Paint
        - Protective Coatings
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - coating
    - coatings
    - protective coating
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 0e6ed8abc3f6f1af2ee1089905a96dc56664b27c71f213f3e9dd001a1ebe574c
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint/protective-coatings
    relationshipId: rel-paint-and-decorating--paint--protective-coatings-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/paint-and-decorating/paint
    type: child_of
x-journeyax-synonyms:
  - coating
  - coatings
  - protective coating
---
# Protective Coatings

Protective Coatings: 96 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Paint](../paint.md)
