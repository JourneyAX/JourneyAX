---
description: 'Interior Paint: 181 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Interior Paint
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/paint-and-decorating/paint/interior-paint
  contentHash: b05daa8871abd32de94c8afd5d6d084e63a536a29a6c993d17cf6e83ddb45998
  customerPhrases:
    - interior enamel paint
    - paint tester
    - ceiling paint flat finish
    - colour sample pot
    - dead flat ceiling paint
    - water based enamel
    - high gloss paint
    - trial pot
  description: 'Interior Paint: 181 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-faf796828143
    - src-doc-d0286c9b9262
    - src-doc-d3b25776f3db
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:33.228Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Interior Paint
          path:
            - Paint & Decorating
            - Paint
            - Interior Paint
          products: 181
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Interior Paint
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Paint & Decorating
        - Paint
        - Interior Paint
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - interior paints
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 207355589b598a174921a9834e8e672bfb0ca31781c86e601bd9fabd11cae33f
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint/interior-paint
    relationshipId: rel-paint-and-decorating--paint--interior-paint-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/paint-and-decorating/paint
    type: child_of
  - claimClasses: []
    confidence: low
    contentHash: 9adaea514972789b08c2b8a606f367ef6f8624a03c6f0d8148f2588696c3b56c
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint/interior-paint
    relationshipId: rel-xs-interior_paint_extras-1
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/paint-and-decorating/paint-accessories/brushes-and-rollers
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: dc635ff2ef1497f322c4d523ef2adf7c442bf1c0322a513563291108431d705f
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint/interior-paint
    relationshipId: rel-xs-interior_paint_extras-2
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/paint-and-decorating/paint-accessories/masking
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: f147abf2db965f1c1f6f4963d42ea4d24f5f8e899ed036624ed740bc7fabcfef
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint/interior-paint
    relationshipId: rel-xs-interior_paint_extras-3
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/paint-and-decorating/paint/primers-sealers-and-undercoats
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: eadbdb2f9ec1e7e188d861d58966b35a40179ee636e896cb9ed4281d94ea5506
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint/interior-paint
    relationshipId: rel-xs-interior_paint_extras-4
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/paint-and-decorating/paint-accessories/protective-wear-and-coverings
    type: cross_sell
x-journeyax-synonyms:
  - interior paints
---
# Interior Paint

Interior Paint: 181 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Paint](../paint.md)
* cross sell: [Brushes & Rollers](../paint-accessories/brushes-and-rollers.md)
* cross sell: [Masking](../paint-accessories/masking.md)
* cross sell: [Primers Sealers & Undercoats](primers-sealers-and-undercoats.md)
* cross sell: [Protective Wear & Coverings](../paint-accessories/protective-wear-and-coverings.md)
