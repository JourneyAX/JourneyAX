---
description: 'Exterior Paint: 113 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Exterior Paint
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/paint-and-decorating/paint/exterior-paint
  contentHash: 098b1237842ed7bfa85103c6370c50b7d2baad9095cb00a18fd0e7b433d2ff71
  customerPhrases:
    - exterior acrylic paint
    - concrete etch
    - exterior timber paint
    - weatherproof paint
    - driveway paint prep
    - deck and fence paint
    - all weather exterior paint
    - non slip granules
  description: 'Exterior Paint: 113 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-c4d4e145aa2f
    - src-doc-594ebd756145
    - src-doc-3285690e2316
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:56.477Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Exterior Paint
          path:
            - Paint & Decorating
            - Paint
            - Exterior Paint
          products: 113
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Exterior Paint
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Paint & Decorating
        - Paint
        - Exterior Paint
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - exterior paints
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 61c49963fa72be7e2e157f1c6c985238cdb4fd48563be869380f1344fc3df5de
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint/exterior-paint
    relationshipId: rel-paint-and-decorating--paint--exterior-paint-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/paint-and-decorating/paint
    type: child_of
  - claimClasses: []
    confidence: low
    contentHash: 1603ddc5fbeab3f539f841920e43043e7f1b71993301bf4070a79508887d85a9
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint/exterior-paint
    relationshipId: rel-xs-exterior_paint_extras-1
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/paint-and-decorating/paint/primers-sealers-and-undercoats
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: ec53eac51e9cb9700549611ad07bb2fb4a704b73627c7180f9e4e4a7b089b230
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint/exterior-paint
    relationshipId: rel-xs-exterior_paint_extras-2
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/paint-and-decorating/paint-accessories/brushes-and-rollers
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: 6e4db6f73c5312846790d5e845ce249a8f6cd7e32e915f3673e3f5d6ec689847
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint/exterior-paint
    relationshipId: rel-xs-exterior_paint_extras-3
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/paint-and-decorating/paint-accessories/masking
    type: cross_sell
  - claimClasses: []
    confidence: low
    contentHash: 364a7f332c46f42d83f9756d1cfc9429c01623471bdc2d7ec1517837f0310084
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint/exterior-paint
    relationshipId: rel-xs-exterior_paint_extras-4
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/cleaning-and-consumables/cleaners-and-cleaning-equipment/outdoor-cleaners
    type: cross_sell
x-journeyax-synonyms:
  - exterior paints
---
# Exterior Paint

Exterior Paint: 113 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Paint](../paint.md)
* cross sell: [Primers Sealers & Undercoats](primers-sealers-and-undercoats.md)
* cross sell: [Brushes & Rollers](../paint-accessories/brushes-and-rollers.md)
* cross sell: [Masking](../paint-accessories/masking.md)
* cross sell: [Outdoor Cleaners](../../cleaning-and-consumables/cleaners-and-cleaning-equipment/outdoor-cleaners.md)
