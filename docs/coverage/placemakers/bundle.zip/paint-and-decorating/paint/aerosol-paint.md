---
description: 'Aerosol Paint: 117 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Aerosol Paint
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/paint-and-decorating/paint/aerosol-paint
  contentHash: d768c8562f25280c6d975c2c1c160e31462683aaffea2b53f7163290c2352ad5
  customerPhrases:
    - concrete sealer
    - zinc spray
    - spray can paint
    - penetrating sealer
    - cold galvanising
    - aerosol enamel
    - concrete stain
    - galv touch up
    - spray paint
    - spray can
    - spray cans
    - rattle can
    - rattle cans
    - aerosol
    - aerosols
  description: 'Aerosol Paint: 117 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-e63e36fc2472
    - src-doc-5c6e6a785473
    - src-doc-75b5d89972d4
  extensions:
    x-journeyax-provenance:
      alias_spray_paint:
        detail:
          alias: spray_paint
          reason: Spray can and rattle can are aerosol paint.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:49.922Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Aerosol Paint
          path:
            - Paint & Decorating
            - Paint
            - Aerosol Paint
          products: 117
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Aerosol Paint
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Paint & Decorating
        - Paint
        - Aerosol Paint
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - aerosol paints
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 5d05aeb64142b0db5bf6c830bbcf5cf048c66e675e7180ecb1d54d0cb52535a4
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint/aerosol-paint
    relationshipId: rel-paint-and-decorating--paint--aerosol-paint-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/paint-and-decorating/paint
    type: child_of
x-journeyax-synonyms:
  - aerosol paints
---
# Aerosol Paint

Aerosol Paint: 117 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Paint](../paint.md)
