---
description: 'Woodcare: 176 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Woodcare
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/paint-and-decorating/paint/woodcare
  contentHash: 81076f75118b2849cecad76986fe7a4a3eb44b4077ed29bcff7e9356124ea7f1
  customerPhrases:
    - deck stain
    - polyurethane clear coat
    - exterior timber stain
    - waterbased poly
    - wood decking stain
    - flooring sealer
    - wood deck coating
    - deck sealer
    - decking oil
    - deck oil
    - wood stain
    - timber stain
    - timber oil
    - wood oil
    - varnish
    - polyurethane
    - danish oil
  description: 'Woodcare: 176 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-7757144255e8
    - src-doc-4c80d32afc93
    - src-doc-6d9803db2ea1
  extensions:
    x-journeyax-provenance:
      alias_wood_stain:
        detail:
          alias: wood_stain
          reason: Customers ask for stain, oil and varnish for timber.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:45.516Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Woodcare
          path:
            - Paint & Decorating
            - Paint
            - Woodcare
          products: 176
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Woodcare
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Paint & Decorating
        - Paint
        - Woodcare
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - woodcares
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 0996421dc046377a41718cdc554dd5de09d8e7bc63d5ec20ac48da238e78eedf
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint/woodcare
    relationshipId: rel-paint-and-decorating--paint--woodcare-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/paint-and-decorating/paint
    type: child_of
x-journeyax-synonyms:
  - woodcares
---
# Woodcare

Woodcare: 176 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Paint](../paint.md)
