# paint-and-decorating/paint

* [Aerosol Paint](aerosol-paint.md) - Aerosol Paint: 117 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Exterior Paint](exterior-paint.md) - Exterior Paint: 113 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Interior Paint](interior-paint.md) - Interior Paint: 181 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Primers Sealers & Undercoats](primers-sealers-and-undercoats.md) - Primers Sealers & Undercoats: 32 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Protective Coatings](protective-coatings.md) - Protective Coatings: 96 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Tinters](tinters.md) - Tinters: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Woodcare](woodcare.md) - Woodcare: 176 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
