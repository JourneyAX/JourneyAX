---
description: 'Thinners & Cleanup: 76 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Thinners & Cleanup
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/paint-and-decorating/paint-accessories/thinners-and-cleanup
  contentHash: 4f95da56eed45e35512afc795732193787571880932d356fe209f8df0e5e30da
  customerPhrases:
    - skimming compound
    - wall repair patch
    - stockinette rag
    - paint thinner
    - sugar soap cleaner
    - aluminium repair patch
    - cotton rags
    - paint remover gel
  description: 'Thinners & Cleanup: 76 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-b9e9c4ca9e66
    - src-doc-53c9f95cea9d
    - src-doc-14b66f2c334a
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:54.287Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Thinners & Cleanup
          path:
            - Paint & Decorating
            - Paint Accessories
            - Thinners & Cleanup
          products: 76
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Thinners & Cleanup
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Paint & Decorating
        - Paint Accessories
        - Thinners & Cleanup
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - cleanup
    - cleanups
    - thinner
    - thinners
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 8c99462a28b3f9247171f5c41c0c5ed65653b90d045fd4cd39b534d285d6590c
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint-accessories/thinners-and-cleanup
    relationshipId: rel-paint-and-decorating--paint-accessories--thinners-and-cleanup-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/paint-and-decorating/paint-accessories
    type: child_of
x-journeyax-synonyms:
  - cleanup
  - cleanups
  - thinner
  - thinners
---
# Thinners & Cleanup

Thinners & Cleanup: 76 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Paint Accessories](../paint-accessories.md)
