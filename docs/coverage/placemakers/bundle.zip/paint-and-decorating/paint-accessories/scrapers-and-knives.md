---
description: 'Scrapers & Knives: 61 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Scrapers & Knives
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/paint-and-decorating/paint-accessories/scrapers-and-knives
  contentHash: 81b4f8fba2a7122836b1cd10c1159c7f2e82464ec835255e4e61b94c6e13b85d
  customerPhrases:
    - wire brush
    - paint prep brush
    - scrubbing brush for paint
    - flaky paint remover
    - corrugated roof brush
    - roof cleaning pole brush
    - arch wire brush
    - wire bristle brush
  description: 'Scrapers & Knives: 61 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:57.952Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Scrapers & Knives
          path:
            - Paint & Decorating
            - Paint Accessories
            - Scrapers & Knives
          products: 61
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Scrapers & Knives
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Paint & Decorating
        - Paint Accessories
        - Scrapers & Knives
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - knive
    - knives
    - scraper
    - scrapers
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: b5575b43440c504cdf3a36de08e6954c8b31ec8f2fad062cf2c158bd10aed170
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint-accessories/scrapers-and-knives
    relationshipId: rel-paint-and-decorating--paint-accessories--scrapers-and-knives-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/paint-and-decorating/paint-accessories
    type: child_of
x-journeyax-synonyms:
  - knive
  - knives
  - scraper
  - scrapers
---
# Scrapers & Knives

Scrapers & Knives: 61 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Paint Accessories](../paint-accessories.md)
