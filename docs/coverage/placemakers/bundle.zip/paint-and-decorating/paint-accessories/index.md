# paint-and-decorating/paint-accessories

* [Abrasives](abrasives.md) - Abrasives: 60 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Brushes & Rollers](brushes-and-rollers.md) - Brushes & Rollers: 248 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Extension Poles](extension-poles.md) - Extension Poles: 10 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Masking](masking.md) - Masking: 101 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Mixers, Cleaners & Brush Care](mixers-cleaners-and-brush-care.md) - Mixers, Cleaners & Brush Care: 19 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Other Painting Accessories](other-painting-accessories.md) - Other Painting Accessories: 18 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Protective Wear & Coverings](protective-wear-and-coverings.md) - Protective Wear & Coverings: 24 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Scrapers & Knives](scrapers-and-knives.md) - Scrapers & Knives: 61 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Spraying Equipment](spraying-equipment.md) - Spraying Equipment: 12 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Thinners & Cleanup](thinners-and-cleanup.md) - Thinners & Cleanup: 76 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Wallpaper & Accessories](wallpaper-and-accessories.md) - Wallpaper & Accessories: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
