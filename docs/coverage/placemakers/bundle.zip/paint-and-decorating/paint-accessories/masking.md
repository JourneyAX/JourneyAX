---
description: 'Masking: 101 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Masking
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/paint-and-decorating/paint-accessories/masking
  contentHash: e6d648b9e5556d4d3e58a8fe4676ae3d27ea6b8e2b3c62b4b966c850dd381251
  customerPhrases:
    - washi tape for painting
    - carpet protector film
    - decking applicator
    - painter s tape
    - self adhesive carpet film
    - wool roller refill
    - exterior masking tape
    - ply protection film
    - masking tape
    - painters tape
    - frog tape
    - blue tape
  description: 'Masking: 101 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_masking_tape:
        detail:
          alias: masking_tape
          reason: Painters tape and Frog Tape are masking tape.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:52.053Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Masking
          path:
            - Paint & Decorating
            - Paint Accessories
            - Masking
          products: 101
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Masking
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Paint & Decorating
        - Paint Accessories
        - Masking
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - maskings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: a647e05d74606fecbc2f59cb32e75226697f7e92551eca55770382cfeb411523
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint-accessories/masking
    relationshipId: rel-paint-and-decorating--paint-accessories--masking-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/paint-and-decorating/paint-accessories
    type: child_of
x-journeyax-synonyms:
  - maskings
---
# Masking

Masking: 101 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Paint Accessories](../paint-accessories.md)
