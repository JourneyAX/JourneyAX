---
description: 'Extension Poles: 10 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Extension Poles
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/paint-and-decorating/paint-accessories/extension-poles
  contentHash: bb91718444becaf4ba95da9e9713e0754e96092d173e2a3e2e1a26d220bac568
  customerPhrases:
    - paint roller pole
    - roller extension pole
    - telescopic roller handle
    - paint extension handle
    - long reach pole
    - roller reach pole
    - threaded pole for roller
    - twist lock extension pole
  description: 'Extension Poles: 10 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:03:28.317Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Extension Poles
          path:
            - Paint & Decorating
            - Paint Accessories
            - Extension Poles
          products: 10
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Extension Poles
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Paint & Decorating
        - Paint Accessories
        - Extension Poles
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - extension pole
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 9dfe8e708baf317b3883b8b1d3b2c48a6d17be20823a6eb5f28e46fdbd932927
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint-accessories/extension-poles
    relationshipId: rel-paint-and-decorating--paint-accessories--extension-poles-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/paint-and-decorating/paint-accessories
    type: child_of
x-journeyax-synonyms:
  - extension pole
---
# Extension Poles

Extension Poles: 10 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Paint Accessories](../paint-accessories.md)
