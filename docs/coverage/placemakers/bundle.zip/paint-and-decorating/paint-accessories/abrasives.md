---
description: 'Abrasives: 60 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Abrasives
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/paint-and-decorating/paint-accessories/abrasives
  contentHash: c0f00782dbc4abf3a6099eff50de1a1c336f430008cac62f75acc92b9dd9118e
  customerPhrases:
    - sanding sponge
    - sanding sheets
    - sanding roll
    - steel wool pads
    - sanding block alternative
    - sand paper sheets
    - sandpaper roll 115mm
    - 0000 grade
    - sandpaper
    - sand paper
    - wet and dry
    - sanding block
  description: 'Abrasives: 60 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_sandpaper:
        detail:
          alias: sandpaper
          reason: Sandpaper is written as one word or two.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:35.700Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Abrasives
          path:
            - Paint & Decorating
            - Paint Accessories
            - Abrasives
          products: 60
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Abrasives
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Paint & Decorating
        - Paint Accessories
        - Abrasives
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - abrasive
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 25889f947c73ba2698fdcf8827516af70d49dadcb220ef24a0515aa9fa6d4ee9
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/paint-and-decorating/paint-accessories/abrasives
    relationshipId: rel-paint-and-decorating--paint-accessories--abrasives-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/paint-and-decorating/paint-accessories
    type: child_of
x-journeyax-synonyms:
  - abrasive
---
# Abrasives

Abrasives: 60 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Paint Accessories](../paint-accessories.md)
