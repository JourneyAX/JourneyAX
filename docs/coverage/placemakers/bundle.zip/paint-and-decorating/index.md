# paint-and-decorating

* [Paint Accessories](paint-accessories.md) - Paint Accessories: 631 products across 11 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Paint](paint.md) - Paint: 716 products across 7 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [paint-accessories](paint-accessories/) - Knowledge and references
* [paint](paint/) - Knowledge and references
