---
description: 'Ladders & Scaffolding: 279 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Ladders & Scaffolding
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/safety-and-ladders/ladders-and-scaffolding/scaffold
      - concept://placemakers/safety-and-ladders/ladders-and-scaffolding/ladders
      - concept://placemakers/safety-and-ladders/ladders-and-scaffolding/platforms-and-stools
      - concept://placemakers/safety-and-ladders/ladders-and-scaffolding/attic-access
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_safety_and_ladders_ladders_and_scaffolding
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/safety-and-ladders/ladders-and-scaffolding
  contentHash: 2b28e6741f9412b9439b2f0a02a93c3ffe717c9c18ef3b94774b9e5d92722256
  customerPhrases:
    - trade ladder
  description: 'Ladders & Scaffolding: 279 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_safety_and_ladders_ladders_and_scaffolding
      questionRef: q.nav_safety_and_ladders_ladders_and_scaffolding
      valueMap:
        attic-access: concept://placemakers/safety-and-ladders/ladders-and-scaffolding/attic-access
        ladders: concept://placemakers/safety-and-ladders/ladders-and-scaffolding/ladders
        platforms-and-stools: concept://placemakers/safety-and-ladders/ladders-and-scaffolding/platforms-and-stools
        scaffold: concept://placemakers/safety-and-ladders/ladders-and-scaffolding/scaffold
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-95540e927e21
    - src-doc-261fbc37726d
    - src-doc-c176063b5c77
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Ladders & Scaffolding
          path:
            - Safety & Ladders
            - Ladders & Scaffolding
          products: 279
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Ladders & Scaffolding
  requiredFacts:
    - factKey: nav_safety_and_ladders_ladders_and_scaffolding
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Safety & Ladders
        - Ladders & Scaffolding
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - scaffolding
    - scaffoldings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: c867f592921b815cdddc962c6f501341c885f00698d1f933b09bce867be1c61c
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/safety-and-ladders/ladders-and-scaffolding
    relationshipId: rel-safety-and-ladders--ladders-and-scaffolding-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/safety-and-ladders
    type: child_of
x-journeyax-synonyms:
  - scaffolding
  - scaffoldings
---
# Ladders & Scaffolding

Ladders & Scaffolding: 279 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Safety & Ladders](../safety-and-ladders.md)
