---
description: 'Height Protection: 15 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Height Protection
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/safety-and-ladders/safety/height-protection
  contentHash: 88a5a5f3b48b94477e89e24000602dd0795b05c7a04f7e16c62ea6780db0338e
  customerPhrases:
    - tool tether rings
    - tool tether
    - fall arrest lanyard
    - tool lanyard attachments
    - tool lanyard tether
    - tethering split rings
    - dropped tool prevention
    - safety tie off
    - harness
    - safety harness
    - fall arrest
    - lanyard
  description: 'Height Protection: 15 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_harness:
        detail:
          alias: harness
          reason: Harness and fall arrest are height protection.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:04:36.762Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Height Protection
          path:
            - Safety & Ladders
            - Safety
            - Height Protection
          products: 15
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Height Protection
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Safety & Ladders
        - Safety
        - Height Protection
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - height protections
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 78bd019d462b4b95be45df3a8bf512427a3389600371e9bcde32d1bd88100968
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/safety-and-ladders/safety/height-protection
    relationshipId: rel-safety-and-ladders--safety--height-protection-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/safety-and-ladders/safety
    type: child_of
x-journeyax-synonyms:
  - height protections
---
# Height Protection

Height Protection: 15 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Safety](../safety.md)
