---
description: 'Footwear: 288 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Footwear
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/safety-and-ladders/safety/footwear
  contentHash: 611bba56b24631f1b48f649e6258441e166a0f8f48b3baf3dd5d67a83aa348ce
  customerPhrases:
    - steelcap boots
    - slip on safety boots
    - steel toe gumboots
    - steel cap boots
    - work socks
    - boot laces
    - gaiters
    - safety lace boots
    - safety boots
    - work boots
    - steel caps
    - steelcaps
    - gumboots
    - gum boots
    - boots
  description: 'Footwear: 288 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-a889e2cd8f7a
    - src-doc-915da982ff19
    - src-doc-dc2bcb259513
  extensions:
    x-journeyax-provenance:
      alias_work_boots:
        detail:
          alias: work_boots
          reason: Steel caps and gumboots are work footwear.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:33.184Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Footwear
          path:
            - Safety & Ladders
            - Safety
            - Footwear
          products: 288
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Footwear
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Safety & Ladders
        - Safety
        - Footwear
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - footwears
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: b4578f1adcfceed4b485b1850d1403c2ed46fc01f290ee71673c323656a982ee
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/safety-and-ladders/safety/footwear
    relationshipId: rel-safety-and-ladders--safety--footwear-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/safety-and-ladders/safety
    type: child_of
x-journeyax-synonyms:
  - footwears
---
# Footwear

Footwear: 288 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Safety](../safety.md)
