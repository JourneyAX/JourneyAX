---
description: 'Respiratory Protection: 52 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Respiratory Protection
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/safety-and-ladders/safety/respiratory-protection
  contentHash: b1c99a1cea6fffbb6760c418db304108a92a0bb12d569524c36596bed564e7e7
  customerPhrases:
    - half face mask
    - p3 filters replacement
    - respirator case
    - reusable respirator
    - p2 filter cartridges
    - n95 respirator
    - mask storage box
    - silicone half mask
    - dust mask
    - dust masks
    - respirator
    - respirators
    - p2 mask
    - p2 masks
    - face mask
  description: 'Respiratory Protection: 52 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-fa0105194537
    - src-doc-b4936a7a61f7
    - src-doc-ed3fa4084c71
  extensions:
    x-journeyax-provenance:
      alias_dust_mask:
        detail:
          alias: dust_mask
          reason: Dust masks and respirators are one category.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:41.439Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Respiratory Protection
          path:
            - Safety & Ladders
            - Safety
            - Respiratory Protection
          products: 52
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Respiratory Protection
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Safety & Ladders
        - Safety
        - Respiratory Protection
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - respiratory protections
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 6229463daaf8b7c4c3e80f17b974f2042c8b7b4d5ae61927439680fa6b92443e
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/safety-and-ladders/safety/respiratory-protection
    relationshipId: rel-safety-and-ladders--safety--respiratory-protection-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/safety-and-ladders/safety
    type: child_of
x-journeyax-synonyms:
  - respiratory protections
---
# Respiratory Protection

Respiratory Protection: 52 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Safety](../safety.md)
