---
description: 'Sun & Skin Protection: 10 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Sun & Skin Protection
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/safety-and-ladders/safety/sun-and-skin-protection
  contentHash: b1b55ff52f7120842d6262895138b50c978490654fac1c428d93d9b53b5c12c9
  customerPhrases:
    - spf 50 sunscreen
    - paint remover wipes
    - broad spectrum sunscreen
    - adhesive cleaning wipes
    - water resistant sun lotion
    - glue remover wipes
    - sunscreen pump bottle
    - hand and tool wipes
    - sunscreen
    - sun screen
    - sunblock
    - sun block
    - sun hat
  description: 'Sun & Skin Protection: 10 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_sunscreen:
        detail:
          alias: sunscreen
          reason: Sunscreen is written as one word or two.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:04:06.677Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Sun & Skin Protection
          path:
            - Safety & Ladders
            - Safety
            - Sun & Skin Protection
          products: 10
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Sun & Skin Protection
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Safety & Ladders
        - Safety
        - Sun & Skin Protection
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - skin protection
    - skin protections
    - sun
    - suns
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: a5626e22f98826333e988d0b411ac20cf997aa6adeb37d5d045581a0e9816d9f
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/safety-and-ladders/safety/sun-and-skin-protection
    relationshipId: rel-safety-and-ladders--safety--sun-and-skin-protection-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/safety-and-ladders/safety
    type: child_of
x-journeyax-synonyms:
  - skin protection
  - skin protections
  - sun
  - suns
---
# Sun & Skin Protection

Sun & Skin Protection: 10 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Safety](../safety.md)
