---
description: 'Eye Protection: 108 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Eye Protection
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/safety-and-ladders/safety/eye-protection
  contentHash: 333f5ca16226ecd5fbdfcbaa0e4c9e8090052f4397b9e2a7de116bffcce5d28f
  customerPhrases:
    - visor replacement
    - goggle cleaner
    - goggles foam sealed
    - clear face shield
    - anti fog spray
    - padded goggles
    - anti fog shield
    - shammy cloth
    - safety glasses
    - safety goggles
    - goggles
    - eye protection
    - face shield
  description: 'Eye Protection: 108 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-f76814dcb46f
    - src-doc-c3b943637db3
    - src-doc-526f98a5d45b
  extensions:
    x-journeyax-provenance:
      alias_safety_glasses:
        detail:
          alias: safety_glasses
          reason: Customers ask for safety glasses or goggles.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:05:34.095Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Eye Protection
          path:
            - Safety & Ladders
            - Safety
            - Eye Protection
          products: 108
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Eye Protection
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Safety & Ladders
        - Safety
        - Eye Protection
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - eye protections
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: debe6493809de4af35878931754a82ee78acfd2a5d5e736e08fab5c3cbc91a82
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/safety-and-ladders/safety/eye-protection
    relationshipId: rel-safety-and-ladders--safety--eye-protection-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/safety-and-ladders/safety
    type: child_of
x-journeyax-synonyms:
  - eye protections
---
# Eye Protection

Eye Protection: 108 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Safety](../safety.md)
