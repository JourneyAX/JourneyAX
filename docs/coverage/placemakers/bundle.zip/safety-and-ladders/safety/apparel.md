---
description: 'Apparel: 761 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Apparel
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/safety-and-ladders/safety/apparel
  contentHash: 6c430f455b345ea1a0415805c8c730d5e57b8d58a4d22407f68449b393af19a9
  customerPhrases:
    - heated work jacket
    - hi vis tee
    - work jacket womens
    - work polo
    - bucket hat
    - hi vis fleece
    - disposable overalls
    - polyester fleece
    - hi vis
    - hivis
    - high vis
    - high visibility
    - safety vest
    - work shirt
    - work shirts
    - work pants
  description: 'Apparel: 761 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-6544628108fc
    - src-doc-9d7619d44c3f
    - src-doc-931a4f445e1a
  extensions:
    x-journeyax-provenance:
      alias_hi_vis:
        detail:
          alias: hi_vis
          reason: Hi vis is how customers ask for high-visibility clothing.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:21.668Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Apparel
          path:
            - Safety & Ladders
            - Safety
            - Apparel
          products: 761
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Apparel
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Safety & Ladders
        - Safety
        - Apparel
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - apparels
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 6edbb7d0b19f9e20618e9f753bacf1165d655fc70c0795c2a053aac6fcaab064
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/safety-and-ladders/safety/apparel
    relationshipId: rel-safety-and-ladders--safety--apparel-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/safety-and-ladders/safety
    type: child_of
x-journeyax-synonyms:
  - apparels
---
# Apparel

Apparel: 761 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Safety](../safety.md)
