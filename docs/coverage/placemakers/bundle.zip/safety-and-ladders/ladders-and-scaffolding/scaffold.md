---
description: 'Scaffold: 146 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Scaffold
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/safety-and-ladders/ladders-and-scaffolding/scaffold
  contentHash: 6cdbd00fa9a9376e8a10d1efbae4a24fbfed523b4291571c4af55fcadf9330f3
  customerPhrases:
    - mobile scaffold tower
    - scaffold plank
    - tower scaffold
    - work platform plank
    - rolling scaffold
    - timber scaffold board
    - scaffold tower hire
    - lvl plank
  description: 'Scaffold: 146 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-95540e927e21
    - src-doc-12839346a8bb
    - src-doc-f31536a558f8
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:25.144Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Scaffold
          path:
            - Safety & Ladders
            - Ladders & Scaffolding
            - Scaffold
          products: 146
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Scaffold
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Safety & Ladders
        - Ladders & Scaffolding
        - Scaffold
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - scaffolds
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 3d1aa5737043af95833435b215a9f8ae7e9b397cfb2408aae1a8392c9cfc8dfe
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/safety-and-ladders/ladders-and-scaffolding/scaffold
    relationshipId: rel-safety-and-ladders--ladders-and-scaffolding--scaffold-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/safety-and-ladders/ladders-and-scaffolding
    type: child_of
x-journeyax-synonyms:
  - scaffolds
---
# Scaffold

Scaffold: 146 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Ladders & Scaffolding](../ladders-and-scaffolding.md)
