---
description: 'Attic Access: 14 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Attic Access
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/safety-and-ladders/ladders-and-scaffolding/attic-access
  contentHash: 7ef829aaedb1c2c7fa7987046b4ab6fe480b334b5bb5bc6015967ac1ba6159a4
  customerPhrases:
    - loft ladder
    - attic access ladder
    - folding attic ladder
    - timber attic stairs
    - insulated attic hatch
    - attic stair folding
    - loft hatch ladder
    - attic pull down ladder
  description: 'Attic Access: 14 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-261fbc37726d
    - src-doc-c176063b5c77
    - src-doc-dc35ed177ee4
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:02:33.424Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Attic Access
          path:
            - Safety & Ladders
            - Ladders & Scaffolding
            - Attic Access
          products: 14
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Attic Access
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Safety & Ladders
        - Ladders & Scaffolding
        - Attic Access
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - access
    - accesses
    - attic accesses
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 2264ed7fc0ad9b6653ec784da4ed56403614894169bbe0f63a7b85ae0ff52e67
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/safety-and-ladders/ladders-and-scaffolding/attic-access
    relationshipId: rel-safety-and-ladders--ladders-and-scaffolding--attic-access-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/safety-and-ladders/ladders-and-scaffolding
    type: child_of
x-journeyax-synonyms:
  - access
  - accesses
  - attic accesses
---
# Attic Access

Attic Access: 14 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Ladders & Scaffolding](../ladders-and-scaffolding.md)
