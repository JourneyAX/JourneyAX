# safety-and-ladders/ladders-and-scaffolding

* [Attic Access](attic-access.md) - Attic Access: 14 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Ladders](ladders.md) - Ladders: 103 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Platforms & Stools](platforms-and-stools.md) - Platforms & Stools: 16 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Scaffold](scaffold.md) - Scaffold: 146 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
