---
description: 'Ladders: 103 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Ladders
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/safety-and-ladders/ladders-and-scaffolding/ladders
  contentHash: f3bc3b44414462830620180ad0956ae5471ed1557587273999b4269158060d16
  customerPhrases:
    - step platform ladder
    - multi use ladder
    - step stool
    - telescopic ladder
    - work trestle
    - ladder work platform
    - work platform step
    - combination ladder
    - step ladder
    - step ladders
    - stepladder
    - extension ladder
    - ladders
    - a frame ladder
  description: 'Ladders: 103 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_step_ladder:
        detail:
          alias: step_ladder
          reason: Customers ask for a step ladder or an extension ladder.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:05.725Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Ladders
          path:
            - Safety & Ladders
            - Ladders & Scaffolding
            - Ladders
          products: 103
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Ladders
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Safety & Ladders
        - Ladders & Scaffolding
        - Ladders
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 70f73ccbf32479a7bcd4030a2f22d9dddee8f1d037b67a69d3f29c9405c891be
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/safety-and-ladders/ladders-and-scaffolding/ladders
    relationshipId: rel-safety-and-ladders--ladders-and-scaffolding--ladders-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/safety-and-ladders/ladders-and-scaffolding
    type: child_of
---
# Ladders

Ladders: 103 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Ladders & Scaffolding](../ladders-and-scaffolding.md)
