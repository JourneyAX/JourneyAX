---
description: 'Platforms & Stools: 16 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Platforms & Stools
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/safety-and-ladders/ladders-and-scaffolding/platforms-and-stools
  contentHash: a3ff60c2ea7fd5797f220e404b171e52fa525b91c143b97c9d4c22182b3275c6
  customerPhrases:
    - ladder platform
    - work platform stand
    - work platform
    - adjustable platform
    - standing platform
    - folding platform
    - portable saw stand
    - ladder accessory tray
  description: 'Platforms & Stools: 16 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:04:40.113Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Platforms & Stools
          path:
            - Safety & Ladders
            - Ladders & Scaffolding
            - Platforms & Stools
          products: 16
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Platforms & Stools
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Safety & Ladders
        - Ladders & Scaffolding
        - Platforms & Stools
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - platform
    - platforms
    - stool
    - stools
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: d7fb20886b83d1326263278e22811a36395bcddaa3a29312d08bcec2aa0b0841
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/safety-and-ladders/ladders-and-scaffolding/platforms-and-stools
    relationshipId: rel-safety-and-ladders--ladders-and-scaffolding--platforms-and-stools-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/safety-and-ladders/ladders-and-scaffolding
    type: child_of
x-journeyax-synonyms:
  - platform
  - platforms
  - stool
  - stools
---
# Platforms & Stools

Platforms & Stools: 16 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Ladders & Scaffolding](../ladders-and-scaffolding.md)
