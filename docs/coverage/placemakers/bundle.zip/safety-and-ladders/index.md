# safety-and-ladders

* [Ladders & Scaffolding](ladders-and-scaffolding.md) - Ladders & Scaffolding: 279 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Safety](safety.md) - Safety: 1,640 products across 13 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [ladders-and-scaffolding](ladders-and-scaffolding/) - Knowledge and references
* [safety](safety/) - Knowledge and references
