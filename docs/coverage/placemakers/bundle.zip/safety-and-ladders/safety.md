---
description: 'Safety: 1,640 products across 13 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Safety
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/safety-and-ladders/safety/apparel
      - concept://placemakers/safety-and-ladders/safety/footwear
      - concept://placemakers/safety-and-ladders/safety/hand-protection
      - concept://placemakers/safety-and-ladders/safety/eye-protection
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_safety_and_ladders_safety
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/safety-and-ladders/safety
  contentHash: fcb62b83254b6239482875f6d130e64d6b3a0d78b45c21d7191909943f5defe3
  customerPhrases:
    - p2 respirator
  description: 'Safety: 1,640 products across 13 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_safety_and_ladders_safety
      questionRef: q.nav_safety_and_ladders_safety
      valueMap:
        apparel: concept://placemakers/safety-and-ladders/safety/apparel
        eye-protection: concept://placemakers/safety-and-ladders/safety/eye-protection
        footwear: concept://placemakers/safety-and-ladders/safety/footwear
        hand-protection: concept://placemakers/safety-and-ladders/safety/hand-protection
        head-protection: concept://placemakers/safety-and-ladders/safety/head-protection
        hearing-protection: concept://placemakers/safety-and-ladders/safety/hearing-protection
        height-protection: concept://placemakers/safety-and-ladders/safety/height-protection
        personal-safety: concept://placemakers/safety-and-ladders/safety/personal-safety
        respiratory-protection: concept://placemakers/safety-and-ladders/safety/respiratory-protection
        signage: concept://placemakers/safety-and-ladders/safety/signage
        site-safety: concept://placemakers/safety-and-ladders/safety/site-safety
        sun-and-skin-protection: concept://placemakers/safety-and-ladders/safety/sun-and-skin-protection
        traffic-safety: concept://placemakers/safety-and-ladders/safety/traffic-safety
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-f76814dcb46f
    - src-doc-c3b943637db3
    - src-doc-526f98a5d45b
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Safety
          path:
            - Safety & Ladders
            - Safety
          products: 1640
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Safety
  requiredFacts:
    - factKey: nav_safety_and_ladders_safety
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Safety & Ladders
        - Safety
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - protection
    - protections
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 68afa82395e1cc60ad5f7b4be5d565621b4ecb0f9df982665369d8a9d02db729
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/safety-and-ladders/safety
    relationshipId: rel-safety-and-ladders--safety-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/safety-and-ladders
    type: child_of
x-journeyax-synonyms:
  - protection
  - protections
---
# Safety

Safety: 1,640 products across 13 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Safety & Ladders](../safety-and-ladders.md)
