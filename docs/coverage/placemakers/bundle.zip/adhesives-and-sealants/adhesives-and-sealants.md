---
description: 'Adhesives & Sealants: 420 products across 7 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Adhesives & Sealants (Adhesives & Sealants)
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/caulks-and-sealants
      - concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/adhesives
      - concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/repair-products
      - concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/foam-products
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_adhesives_and_sealants_adhesives_and_sealants
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants
  contentHash: be5eff36a3b6d197dbe10eafc58e952d9f35a4737247eee03dc7e30c5122b5c4
  customerPhrases: []
  description: 'Adhesives & Sealants: 420 products across 7 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_adhesives_and_sealants_adhesives_and_sealants
      questionRef: q.nav_adhesives_and_sealants_adhesives_and_sealants
      valueMap:
        adhesives: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/adhesives
        caulks-and-sealants: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/caulks-and-sealants
        foam-products: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/foam-products
        grouting-and-anchoring: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/grouting-and-anchoring
        repair-products: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/repair-products
        solvents-and-strippers: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/solvents-and-strippers
        waterproofing: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/waterproofing
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-619e187c3e84
    - src-doc-c0c065ec1dc2
    - src-doc-0dc46e04e722
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Adhesives & Sealants
          path:
            - Adhesives & Sealants
            - Adhesives & Sealants
          products: 420
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Adhesives & Sealants (Adhesives & Sealants)
  requiredFacts:
    - factKey: nav_adhesives_and_sealants_adhesives_and_sealants
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Adhesives & Sealants
        - Adhesives & Sealants
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 106d7c9ddc12afefa01bfb0b7e83b230f55346ac3c70ac1eef0a6faf3102ed35
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants
    relationshipId: rel-adhesives-and-sealants--adhesives-and-sealants-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/adhesives-and-sealants
    type: child_of
---
# Adhesives & Sealants (Adhesives & Sealants)

Adhesives & Sealants: 420 products across 7 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Adhesives & Sealants](../adhesives-and-sealants.md)
