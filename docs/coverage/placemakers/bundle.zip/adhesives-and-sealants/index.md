# adhesives-and-sealants

* [Adhesives & Sealants (Adhesives & Sealants)](adhesives-and-sealants.md) - Adhesives & Sealants: 420 products across 7 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Adhesives (Adhesives & Sealants)](adhesives.md) - Adhesives: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Caulks And Sealants (Adhesives & Sealants)](caulks-and-sealants.md) - Caulks And Sealants: 4 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Foam Products (Adhesives & Sealants)](foam-products.md) - Foam Products: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Repair Products (Adhesives & Sealants)](repair-products.md) - Repair Products: 3 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [adhesives-and-sealants](adhesives-and-sealants/) - Knowledge and references
