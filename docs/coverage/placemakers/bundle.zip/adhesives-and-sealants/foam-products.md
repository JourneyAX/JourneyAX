---
description: 'Foam Products: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Foam Products (Adhesives & Sealants)
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/adhesives-and-sealants/foam-products
  contentHash: d98cdc538754a77c1469bbca37dfc82e289b5dfdcb01a020352287cb0c936fe0
  customerPhrases: []
  description: 'Foam Products: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-61983c70ba3f
    - src-doc-3f94bf1950b7
    - src-doc-bc3a6f81991f
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Foam Products
          path:
            - Adhesives & Sealants
            - Foam Products
          products: 2
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Foam Products (Adhesives & Sealants)
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Adhesives & Sealants
        - Foam Products
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 55b68cdc4170a6d34f75cc9fe4ef1b8b9fcb40a83b881ba9739334338b186c39
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/adhesives-and-sealants/foam-products
    relationshipId: rel-adhesives-and-sealants--foam-products-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/adhesives-and-sealants
    type: child_of
---
# Foam Products (Adhesives & Sealants)

Foam Products: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Adhesives & Sealants](../adhesives-and-sealants.md)
