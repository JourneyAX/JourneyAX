---
description: 'Waterproofing: 26 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Waterproofing
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/waterproofing
  contentHash: 453ba7b5f54e7426982c4cf7144226e8cd4090f8c858d942b3411c873dbefa54
  customerPhrases:
    - bitumen paint
    - butyl rubber membrane
    - swelling tape
    - concrete primer
    - liquid rubber membrane
    - synthetic rubber sheet
    - waterstop strip
    - cement primer
  description: 'Waterproofing: 26 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-0111e8c8a8a2
    - src-doc-33461c9b6913
    - src-doc-3af65e15084f
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:02:22.319Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Waterproofing
          path:
            - Adhesives & Sealants
            - Adhesives & Sealants
            - Waterproofing
          products: 26
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Waterproofing
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Adhesives & Sealants
        - Adhesives & Sealants
        - Waterproofing
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - waterproofings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: d4e661ec20820520253c320e519cb49a1a6fa09c40be37e5ce26f35afd995ed6
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/waterproofing
    relationshipId: rel-adhesives-and-sealants--adhesives-and-sealants--waterproofing-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants
    type: child_of
x-journeyax-synonyms:
  - waterproofings
---
# Waterproofing

Waterproofing: 26 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Adhesives & Sealants (Adhesives & Sealants)](../adhesives-and-sealants.md)
