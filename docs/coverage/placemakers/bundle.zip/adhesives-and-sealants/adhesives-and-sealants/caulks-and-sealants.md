---
description: 'Caulks And Sealants: 130 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Caulks And Sealants (Adhesives & Sealants › Adhesives & Sealants)
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/caulks-and-sealants
  contentHash: b51b898f8026b4a668d8143b0f35fc04d60a7319486e4352c5cb3714496734e4
  customerPhrases:
    - silicone
    - silicon
    - gap filler
    - caulk
    - caulking
    - sealant
    - gutter sealant
    - bathroom sealant
    - mastic
  description: 'Caulks And Sealants: 130 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-619e187c3e84
    - src-doc-7cc66403c4f5
    - src-doc-dbb1cc335f2c
  extensions:
    x-journeyax-provenance:
      alias_silicone:
        detail:
          alias: silicone
          reason: Silicone and gap filler are what customers ask for.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Caulks And Sealants
          path:
            - Adhesives & Sealants
            - Adhesives & Sealants
            - Caulks And Sealants
          products: 130
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Caulks And Sealants (Adhesives & Sealants › Adhesives & Sealants)
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Adhesives & Sealants
        - Adhesives & Sealants
        - Caulks And Sealants
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 3884267ab6536af7a509d6cb7343266fefe2c096873a4b5cf321d5842847fab6
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/caulks-and-sealants
    relationshipId: rel-adhesives-and-sealants--adhesives-and-sealants--caulks-and-sealants-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants
    type: child_of
---
# Caulks And Sealants (Adhesives & Sealants › Adhesives & Sealants)

Caulks And Sealants: 130 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Adhesives & Sealants (Adhesives & Sealants)](../adhesives-and-sealants.md)
