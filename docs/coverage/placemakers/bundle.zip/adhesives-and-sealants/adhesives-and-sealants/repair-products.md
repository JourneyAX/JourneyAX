---
description: 'Repair Products: 68 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Repair Products (Adhesives & Sealants › Adhesives & Sealants)
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/repair-products
  contentHash: 8997a5959d5ba17e14b6ea002c7a1c03a24ddc62e9310db6b5e0578e455114e0
  customerPhrases:
    - epoxy
    - araldite
    - wood filler
    - builders bog
    - bog
    - repair putty
  description: 'Repair Products: 68 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-c0c065ec1dc2
    - src-doc-39d7c1b8c258
    - src-doc-d5a8b57bdfd6
  extensions:
    x-journeyax-provenance:
      alias_epoxy:
        detail:
          alias: epoxy
          reason: Araldite, wood filler and bog are the repair products customers name.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Repair Products
          path:
            - Adhesives & Sealants
            - Adhesives & Sealants
            - Repair Products
          products: 68
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Repair Products (Adhesives & Sealants › Adhesives & Sealants)
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Adhesives & Sealants
        - Adhesives & Sealants
        - Repair Products
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 169f979caecb9ca85ecfdef56e1e51e69be1ec6f7e92340edb568dd1e7198503
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/repair-products
    relationshipId: rel-adhesives-and-sealants--adhesives-and-sealants--repair-products-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants
    type: child_of
---
# Repair Products (Adhesives & Sealants › Adhesives & Sealants)

Repair Products: 68 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Adhesives & Sealants (Adhesives & Sealants)](../adhesives-and-sealants.md)
