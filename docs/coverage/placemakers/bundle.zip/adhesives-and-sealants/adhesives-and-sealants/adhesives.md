---
description: 'Adhesives: 94 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Adhesives (Adhesives & Sealants › Adhesives & Sealants)
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/adhesives
  contentHash: ef059058074eb0a14f57833f3ac91d9601bff0d7e1092007fd267baab5b55cb9
  customerPhrases:
    - liquid nails
    - no more nails
    - gorilla glue
    - super glue
    - superglue
    - pva
    - pva glue
    - wood glue
    - construction adhesive
    - contact adhesive
    - glue
  description: 'Adhesives: 94 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-0dc46e04e722
    - src-doc-77035ea96082
    - src-doc-ede9fb1d6276
  extensions:
    x-journeyax-provenance:
      alias_liquid_nails:
        detail:
          alias: liquid_nails
          reason: Liquid Nails, No More Nails and Gorilla Glue are brands customers use as the word for adhesive.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Adhesives
          path:
            - Adhesives & Sealants
            - Adhesives & Sealants
            - Adhesives
          products: 94
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Adhesives (Adhesives & Sealants › Adhesives & Sealants)
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Adhesives & Sealants
        - Adhesives & Sealants
        - Adhesives
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 20889031db47cd596a0e636f66c78b7d5a0bfcd8da5973f15059be73ccaa0f26
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/adhesives
    relationshipId: rel-adhesives-and-sealants--adhesives-and-sealants--adhesives-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants
    type: child_of
---
# Adhesives (Adhesives & Sealants › Adhesives & Sealants)

Adhesives: 94 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Adhesives & Sealants (Adhesives & Sealants)](../adhesives-and-sealants.md)
