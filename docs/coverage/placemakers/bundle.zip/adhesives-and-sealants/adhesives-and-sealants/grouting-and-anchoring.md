---
description: 'Grouting & Anchoring: 39 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Grouting & Anchoring
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/grouting-and-anchoring
  contentHash: 99ea8a315f42c8b830fa28b28a35ee1d85cc2cfe89527ca3994a862fd6c903f8
  customerPhrases:
    - cementitious grout
    - chemical anchor resin
    - cement grout
    - epoxy anchoring
    - non shrink grout
    - two part anchoring
    - post fix adhesive
    - machine base grout
    - grout
    - tile grout
    - anchoring grout
    - chemical anchor
    - chemical anchoring
  description: 'Grouting & Anchoring: 39 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-322fe08bc375
    - src-doc-d8cb78d5c072
    - src-doc-0baca499d8c1
  extensions:
    x-journeyax-provenance:
      alias_grout:
        detail:
          alias: grout
          reason: Customers ask for tile grout and chemical anchors.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:06.083Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Grouting & Anchoring
          path:
            - Adhesives & Sealants
            - Adhesives & Sealants
            - Grouting & Anchoring
          products: 39
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Grouting & Anchoring
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Adhesives & Sealants
        - Adhesives & Sealants
        - Grouting & Anchoring
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - anchoring
    - anchorings
    - grouting
    - groutings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 49ffb6e6023da7abc6d0feede60df287da1717cb8e19dbc53af6514054649ec2
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/grouting-and-anchoring
    relationshipId: rel-adhesives-and-sealants--adhesives-and-sealants--grouting-and-anchoring-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants
    type: child_of
x-journeyax-synonyms:
  - anchoring
  - anchorings
  - grouting
  - groutings
---
# Grouting & Anchoring

Grouting & Anchoring: 39 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Adhesives & Sealants (Adhesives & Sealants)](../adhesives-and-sealants.md)
