---
description: 'Solvents And Strippers: 8 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Solvents And Strippers
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/solvents-and-strippers
  contentHash: fa2422626768dfeb8c6a8984f0f04654c865350122b181963d814a1e91d04758
  customerPhrases:
    - uncured foam remover
    - neoprene adhesive thinner
    - adhesive remover solvent
    - silicone residue stripper
    - sealant primer
    - surface primer for sealants
    - ms polymer prep
    - joint primer
    - paint remover
    - turps
    - turpentine
    - acetone
    - methylated spirits
    - metho
    - meths
  description: 'Solvents And Strippers: 8 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-8b637c5fc8e1
    - src-doc-66639f172b1a
    - src-doc-fcc99e03ac1e
  extensions:
    x-journeyax-provenance:
      alias_paint_stripper:
        detail:
          alias: paint_stripper
          reason: Turps and metho are the New Zealand words for solvents.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:04:15.895Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Solvents And Strippers
          path:
            - Adhesives & Sealants
            - Adhesives & Sealants
            - Solvents And Strippers
          products: 8
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Solvents And Strippers
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Adhesives & Sealants
        - Adhesives & Sealants
        - Solvents And Strippers
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - solvents and stripper
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 0a4dce49b64f53b8c4d1a6ea377757dbdfdb513b58948558cc029bfc4b3f01aa
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants/solvents-and-strippers
    relationshipId: rel-adhesives-and-sealants--adhesives-and-sealants--solvents-and-strippers-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/adhesives-and-sealants/adhesives-and-sealants
    type: child_of
x-journeyax-synonyms:
  - solvents and stripper
---
# Solvents And Strippers

Solvents And Strippers: 8 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Adhesives & Sealants (Adhesives & Sealants)](../adhesives-and-sealants.md)
