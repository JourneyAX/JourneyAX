---
okf_version: "0.2"
---
# Knowledge

* [Adhesives & Sealants](adhesives-and-sealants.md) - Adhesives & Sealants: 430 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Bathrooms & Plumbing](bathrooms-and-plumbing.md) - Bathrooms & Plumbing: 15,256 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Building Products](building-products.md) - Building Products: 1,977 products across 17 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Cladding](cladding.md) - Cladding: 327 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Cleaning & Consumables](cleaning-and-consumables.md) - Cleaning & Consumables: 262 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Doors, Windows & Joinery Hardware](doors-windows-and-joinery-hardware.md) - Doors, Windows & Joinery Hardware: 1,458 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Electrical & Heating/Cooling](electrical-and-heating-cooling.md) - Electrical & Heating/Cooling: 1,130 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Fastenings & General Hardware](fastenings-and-general-hardware.md) - Fastenings & General Hardware: 3,122 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Kitchens & Laundry](kitchens-and-laundry.md) - Kitchens & Laundry: 1,567 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Other products](other-products.md) - Other products: 395 products across 14 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Outdoor & Landscaping](outdoor-and-landscaping.md) - Outdoor & Landscaping: 2,763 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Paint & Decorating](paint-and-decorating.md) - Paint & Decorating: 1,347 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Safety & Ladders](safety-and-ladders.md) - Safety & Ladders: 1,919 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Sheds & Buildings](sheds-and-buildings.md) - Sheds & Buildings: 571 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Timber & Plywood](timber-and-plywood.md) - Timber & Plywood: 1,550 products across 11 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Tools](tools.md) - Tools: 8,089 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Wardrobes, Storage & Flooring](wardrobes-storage-and-flooring.md) - Wardrobes, Storage & Flooring: 253 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [adhesives-and-sealants](adhesives-and-sealants/) - Knowledge and references
* [bathrooms-and-plumbing](bathrooms-and-plumbing/) - Knowledge and references
* [building-products](building-products/) - Knowledge and references
* [care](care/) - Knowledge and references
* [cladding](cladding/) - Knowledge and references
* [cleaning-and-consumables](cleaning-and-consumables/) - Knowledge and references
* [doors-windows-and-joinery-hardware](doors-windows-and-joinery-hardware/) - Knowledge and references
* [electrical-and-heating-cooling](electrical-and-heating-cooling/) - Knowledge and references
* [families](families/) - Knowledge and references
* [fastenings-and-general-hardware](fastenings-and-general-hardware/) - Knowledge and references
* [kitchens-and-laundry](kitchens-and-laundry/) - Knowledge and references
* [log.md](log.md) - Knowledge artifact
* [other-products](other-products/) - Knowledge and references
* [outdoor-and-landscaping](outdoor-and-landscaping/) - Knowledge and references
* [paint-and-decorating](paint-and-decorating/) - Knowledge and references
* [problems](problems/) - Knowledge and references
* [projects](projects/) - Knowledge and references
* [references](references/) - Knowledge and references
* [safety-and-ladders](safety-and-ladders/) - Knowledge and references
* [sheds-and-buildings](sheds-and-buildings/) - Knowledge and references
* [specials](specials.md) - specials: 20 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [timber-and-plywood](timber-and-plywood/) - Knowledge and references
* [tools](tools/) - Knowledge and references
* [wardrobes-storage-and-flooring](wardrobes-storage-and-flooring/) - Knowledge and references
