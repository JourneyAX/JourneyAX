---
description: 'Fastenings & General Hardware: 3,122 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Fastenings & General Hardware
type: department
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/fastenings-and-general-hardware/fastenings
      - concept://placemakers/fastenings-and-general-hardware/hardware
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_fastenings_and_general_hardware
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/fastenings-and-general-hardware
  contentHash: cc1ea9f1db4d13f8d62a5532e0e4a098beb8cf814baee98fc076d47627411434
  customerPhrases:
    - plastic shims
    - construction shims
    - shim pack
    - thin shims
    - stackable shims
  description: 'Fastenings & General Hardware: 3,122 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_fastenings_and_general_hardware
      questionRef: q.nav_fastenings_and_general_hardware
      valueMap:
        fastenings: concept://placemakers/fastenings-and-general-hardware/fastenings
        hardware: concept://placemakers/fastenings-and-general-hardware/hardware
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-010a0c7530a0
    - src-doc-4f3f3f0a14e6
    - src-doc-dabc92877e3f
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Fastenings & General Hardware
          path:
            - Fastenings & General Hardware
          products: 3122
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Fastenings & General Hardware
  requiredFacts:
    - factKey: nav_fastenings_and_general_hardware
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Fastenings & General Hardware
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - fastening
    - general hardwares
  tenantId: placemakers
  type: department
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - fastening
  - general hardwares
---
# Fastenings & General Hardware

Fastenings & General Hardware: 3,122 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
