---
description: 'Kitchens & Laundry: 1,567 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Kitchens & Laundry
type: department
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/kitchens-and-laundry/kitchens
      - concept://placemakers/kitchens-and-laundry/laundry
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_kitchens_and_laundry
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/kitchens-and-laundry
  contentHash: b6819c75e1e63eeeebb762cdd57d786ce930e80b2976a5d9f527b00efb1c6e14
  customerPhrases: []
  description: 'Kitchens & Laundry: 1,567 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_kitchens_and_laundry
      questionRef: q.nav_kitchens_and_laundry
      valueMap:
        kitchens: concept://placemakers/kitchens-and-laundry/kitchens
        laundry: concept://placemakers/kitchens-and-laundry/laundry
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-d6a7fca9a4a7
    - src-doc-9fc484a5e984
    - src-doc-c89a24837ca3
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Kitchens & Laundry
          path:
            - Kitchens & Laundry
          products: 1567
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Kitchens & Laundry
  requiredFacts:
    - factKey: nav_kitchens_and_laundry
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Kitchens & Laundry
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - appliance
    - appliances
    - kitchen
    - laundries
  tenantId: placemakers
  type: department
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - appliance
  - appliances
  - kitchen
  - laundries
---
# Kitchens & Laundry

Kitchens & Laundry: 1,567 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
