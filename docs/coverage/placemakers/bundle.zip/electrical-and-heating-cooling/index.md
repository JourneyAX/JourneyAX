# electrical-and-heating-cooling

* [Electrical](electrical.md) - Electrical: 343 products across 10 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Heating, Ventilation & Cooling](heating-ventilation-and-cooling.md) - Heating, Ventilation & Cooling: 787 products across 7 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [electrical](electrical/) - Knowledge and references
* [heating-ventilation-and-cooling](heating-ventilation-and-cooling/) - Knowledge and references
