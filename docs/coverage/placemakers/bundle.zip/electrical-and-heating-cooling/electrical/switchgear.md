---
description: 'Switchgear: 75 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Switchgear
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: requires_professional_confirmation
  compatibilitySensitive: false
  conceptId: concept://placemakers/electrical-and-heating-cooling/electrical/switchgear
  contentHash: 2fa4039679df7e132efbc8cb68714ddd1c53b6f5964259cef1dd4ae012eb51eb
  customerPhrases:
    - double powerpoint
    - light switch plate
    - faceplate
    - bayonet lampholder
    - rocker switch
    - site powerboard
    - mcb 6 amp
    - extension socket
  description: 'Switchgear: 75 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-3bb0e2892298
    - src-doc-540e9f683740
    - src-doc-b9ac0f34982d
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:37.333Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      policy_confirm_with_a_qualified_person:
        detail:
          overlay: confirm_with_a_qualified_person
          reason: 'Proposed: a qualified person confirms the selection before checkout for products that are normally installed by a licensed trade. PlaceMakers to approve the list.'
          section: overlays
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Switchgear
          path:
            - Electrical & Heating/Cooling
            - Electrical
            - Switchgear
          products: 75
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Switchgear
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Electrical & Heating/Cooling
        - Electrical
        - Switchgear
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - switchgears
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: c66118e8d4e31158c52cc50b9ae56587260a54d03aabd3e79f5e8c0e58a965b3
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/electrical-and-heating-cooling/electrical/switchgear
    relationshipId: rel-electrical-and-heating-cooling--electrical--switchgear-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/electrical-and-heating-cooling/electrical
    type: child_of
x-journeyax-synonyms:
  - switchgears
---
# Switchgear

Switchgear: 75 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Electrical](../electrical.md)
