---
description: 'Security: 25 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Security
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/electrical-and-heating-cooling/electrical/security
  contentHash: 03036e0e436e389b564938d42027ef4ff85dd67dfa473bb9a3fa2ae9e85565a6
  customerPhrases:
    - wireless security camera
    - doorbell push button
    - wireless alarm siren
    - battery operated camera
    - wired doorbell
    - home alarm siren
    - wifi camera
    - wireless chime
  description: 'Security: 25 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-c1269d7abacb
    - src-doc-a45c7e711676
    - src-doc-02287b12a2ff
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:02:52.696Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Security
          path:
            - Electrical & Heating/Cooling
            - Electrical
            - Security
          products: 25
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Security
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Electrical & Heating/Cooling
        - Electrical
        - Security
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - securities
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: f33688f8c4ccde9dbe607d60c2ec9879e030abb1003e47fce4dbe353ca70f30f
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/electrical-and-heating-cooling/electrical/security
    relationshipId: rel-electrical-and-heating-cooling--electrical--security-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/electrical-and-heating-cooling/electrical
    type: child_of
x-journeyax-synonyms:
  - securities
---
# Security

Security: 25 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Electrical](../electrical.md)
