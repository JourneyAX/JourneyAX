# electrical-and-heating-cooling/electrical

* [Cable & Data](cable-and-data.md) - Cable & Data: 18 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Electrical Consumables](electrical-consumables.md) - Electrical Consumables: 67 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Extension Leads](extension-leads.md) - Extension Leads: 20 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Light Bulbs](light-bulbs.md) - Light Bulbs: 14 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Lighting](lighting.md) - Lighting: 21 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Phone Accessories](phone-accessories.md) - Phone Accessories: 9 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Portable Lighting](portable-lighting.md) - Portable Lighting: 57 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Security](security.md) - Security: 25 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Smoke Alarms](smoke-alarms.md) - Smoke Alarms: 37 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Switchgear](switchgear.md) - Switchgear: 75 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
