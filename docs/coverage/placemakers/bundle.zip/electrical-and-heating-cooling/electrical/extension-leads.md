---
description: 'Extension Leads: 20 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Extension Leads
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/electrical-and-heating-cooling/electrical/extension-leads
  contentHash: 4dcafeaa871a94155f0042be0359e232e5a194b0e6575735192a4167cff429e5
  customerPhrases:
    - trade lead
    - rcd extension lead
    - heavy duty extension lead
    - site lead
    - multi plug extension
    - in line rcd lead
    - extra heavy duty lead
    - worksite extension
    - extension cord
    - extension cords
    - power board
    - powerboard
    - power boards
    - powerboards
    - multi box
    - multibox
    - double adaptor
    - surge protector
  description: 'Extension Leads: 20 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_powerboard:
        detail:
          alias: powerboard
          reason: Powerboard and extension cord are extension leads.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:03:57.048Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Extension Leads
          path:
            - Electrical & Heating/Cooling
            - Electrical
            - Extension Leads
          products: 20
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Extension Leads
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Electrical & Heating/Cooling
        - Electrical
        - Extension Leads
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - extension lead
    - lead
    - leads
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 320cdecaf1716c4c0a6399b6cc9be71ac73507b8429d28c1072378da9ee3efb2
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/electrical-and-heating-cooling/electrical/extension-leads
    relationshipId: rel-electrical-and-heating-cooling--electrical--extension-leads-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/electrical-and-heating-cooling/electrical
    type: child_of
x-journeyax-synonyms:
  - extension lead
  - lead
  - leads
---
# Extension Leads

Extension Leads: 20 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Electrical](../electrical.md)
