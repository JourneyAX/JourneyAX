---
description: 'Cable & Data: 18 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Cable & Data
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: requires_professional_confirmation
  compatibilitySensitive: false
  conceptId: concept://placemakers/electrical-and-heating-cooling/electrical/cable-and-data
  contentHash: da9e6753557e70ac2628493fdb86a256dbda7cf0ca706acfe64d252bf8de3ad2
  customerPhrases:
    - twin and earth
    - cat6 wall plate
    - conduit pipe
    - t e cable
    - data faceplate
    - pvc conduit
    - tps cable
    - network socket
  description: 'Cable & Data: 18 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:03:02.319Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      policy_confirm_with_a_qualified_person:
        detail:
          overlay: confirm_with_a_qualified_person
          reason: 'Proposed: a qualified person confirms the selection before checkout for products that are normally installed by a licensed trade. PlaceMakers to approve the list.'
          section: overlays
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Cable & Data
          path:
            - Electrical & Heating/Cooling
            - Electrical
            - Cable & Data
          products: 18
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Cable & Data
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Electrical & Heating/Cooling
        - Electrical
        - Cable & Data
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - cable
    - cables
    - data
    - datas
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: add4fb4ffc7827eb89c64d3f28120334c3e2b400a7250591aa9b4359bd85b52c
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/electrical-and-heating-cooling/electrical/cable-and-data
    relationshipId: rel-electrical-and-heating-cooling--electrical--cable-and-data-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/electrical-and-heating-cooling/electrical
    type: child_of
x-journeyax-synonyms:
  - cable
  - cables
  - data
  - datas
---
# Cable & Data

Cable & Data: 18 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Electrical](../electrical.md)
