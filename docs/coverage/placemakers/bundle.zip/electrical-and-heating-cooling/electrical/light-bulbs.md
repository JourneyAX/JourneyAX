---
description: 'Light Bulbs: 14 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Light Bulbs
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/electrical-and-heating-cooling/electrical/light-bulbs
  contentHash: 5928e37d0354acc56597a847ac500512183cb298c0e9a913d3e9bb06333375c9
  customerPhrases:
    - r7s linear lamp
    - infrared heat lamp
    - starter switch
    - linear halogen bulb
    - 275 watt heat globe
    - fluoro starter
    - r7s 118mm
    - e27 heat bulb
    - globe
    - globes
    - light globe
    - light globes
    - bulb
    - bulbs
    - led globe
    - led globes
    - led bulb
    - led bulbs
  description: 'Light Bulbs: 14 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-7f6c37aae213
  extensions:
    x-journeyax-provenance:
      alias_globes:
        detail:
          alias: globes
          reason: Globe is the New Zealand word for a light bulb.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:05:50.675Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Light Bulbs
          path:
            - Electrical & Heating/Cooling
            - Electrical
            - Light Bulbs
          products: 14
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Light Bulbs
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Electrical & Heating/Cooling
        - Electrical
        - Light Bulbs
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - bulb
    - bulbs
    - light bulb
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 275937fc45650fcb20898d2e95a214cdb3bd9d282230d31de13e9df6a737b369
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/electrical-and-heating-cooling/electrical/light-bulbs
    relationshipId: rel-electrical-and-heating-cooling--electrical--light-bulbs-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/electrical-and-heating-cooling/electrical
    type: child_of
x-journeyax-synonyms:
  - bulb
  - bulbs
  - light bulb
---
# Light Bulbs

Light Bulbs: 14 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Electrical](../electrical.md)
