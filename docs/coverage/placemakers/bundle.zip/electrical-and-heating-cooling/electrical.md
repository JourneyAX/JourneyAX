---
description: 'Electrical: 343 products across 10 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Electrical
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/electrical-and-heating-cooling/electrical/switchgear
      - concept://placemakers/electrical-and-heating-cooling/electrical/electrical-consumables
      - concept://placemakers/electrical-and-heating-cooling/electrical/portable-lighting
      - concept://placemakers/electrical-and-heating-cooling/electrical/smoke-alarms
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_electrical_and_heating_cooling_electrical
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/electrical-and-heating-cooling/electrical
  contentHash: e9ba880edfd4f832581ed6d4b9fcefdcd45eb831afe3e14eb6bb812a533c4cb5
  customerPhrases: []
  description: 'Electrical: 343 products across 10 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_electrical_and_heating_cooling_electrical
      questionRef: q.nav_electrical_and_heating_cooling_electrical
      valueMap:
        cable-and-data: concept://placemakers/electrical-and-heating-cooling/electrical/cable-and-data
        electrical-consumables: concept://placemakers/electrical-and-heating-cooling/electrical/electrical-consumables
        extension-leads: concept://placemakers/electrical-and-heating-cooling/electrical/extension-leads
        light-bulbs: concept://placemakers/electrical-and-heating-cooling/electrical/light-bulbs
        lighting: concept://placemakers/electrical-and-heating-cooling/electrical/lighting
        phone-accessories: concept://placemakers/electrical-and-heating-cooling/electrical/phone-accessories
        portable-lighting: concept://placemakers/electrical-and-heating-cooling/electrical/portable-lighting
        security: concept://placemakers/electrical-and-heating-cooling/electrical/security
        smoke-alarms: concept://placemakers/electrical-and-heating-cooling/electrical/smoke-alarms
        switchgear: concept://placemakers/electrical-and-heating-cooling/electrical/switchgear
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-94525bc438e0
    - src-doc-ae244e09b852
    - src-doc-ebd6282957df
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Electrical
          path:
            - Electrical & Heating/Cooling
            - Electrical
          products: 343
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Electrical
  requiredFacts:
    - factKey: nav_electrical_and_heating_cooling_electrical
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Electrical & Heating/Cooling
        - Electrical
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - lightings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: da1185efa0f619628e21287267f2ede98f933961c057e6c3d1a6c1b30c9682d5
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/electrical-and-heating-cooling/electrical
    relationshipId: rel-electrical-and-heating-cooling--electrical-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/electrical-and-heating-cooling
    type: child_of
x-journeyax-synonyms:
  - lightings
---
# Electrical

Electrical: 343 products across 10 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Electrical & Heating/Cooling](../electrical-and-heating-cooling.md)
