---
description: 'Ventilation: 227 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Ventilation
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling/ventilation
  contentHash: 97039f983dfb3e98d8312e1dc4aacfb62d6deebf45fa9226dcdfbb9fccaec92e
  customerPhrases:
    - wall vent
    - heat light combo
    - air vent grille
    - inline duct fan
    - flexible ducting
    - tempering element
    - heat re distribution kit
    - tankless dehumidifier
  description: 'Ventilation: 227 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-7a3580a31b1d
    - src-doc-4aaff96000bb
    - src-doc-3f131e576f3b
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:54.262Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Ventilation
          path:
            - Electrical & Heating/Cooling
            - Heating, Ventilation & Cooling
            - Ventilation
          products: 227
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Ventilation
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Electrical & Heating/Cooling
        - Heating, Ventilation & Cooling
        - Ventilation
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: a5d20db0bc69ad95828ad77d825f0a45c482e67b2c8fcc00021f2e3df0cc106b
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling/ventilation
    relationshipId: rel-electrical-and-heating-cooling--heating-ventilation-and-cooling--ventilation-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling
    type: child_of
---
# Ventilation

Ventilation: 227 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Heating, Ventilation & Cooling](../heating-ventilation-and-cooling.md)
