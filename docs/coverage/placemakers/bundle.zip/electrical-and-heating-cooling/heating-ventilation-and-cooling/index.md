# electrical-and-heating-cooling/heating-ventilation-and-cooling

* [Central Heating](central-heating.md) - Central Heating: 65 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Electric Heating](electric-heating.md) - Electric Heating: 121 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Gas Heating](gas-heating.md) - Gas Heating: 59 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Heat Pumps](heat-pumps.md) - Heat Pumps: 69 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Outdoor Heating](outdoor-heating.md) - Outdoor Heating: 31 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Solid Fuel](solid-fuel.md) - Solid Fuel: 215 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Ventilation](ventilation.md) - Ventilation: 227 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
