---
description: 'Solid Fuel: 215 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Solid Fuel
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: requires_professional_confirmation
  compatibilitySensitive: false
  conceptId: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling/solid-fuel
  contentHash: 6c630c84563e40e7df63a80b5d00da654907ae2618584b61ec98eac609c6f987
  customerPhrases:
    - wood burner
    - hearth extension
    - ash hearth
    - stove flue liner
    - multifuel stove
    - outdoor wood fire
    - wood pellets
    - log burner
    - log burners
    - woodburner
    - wood fire
    - fireplace
    - pellet fire
    - wood heater
  description: 'Solid Fuel: 215 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-7bf6465b5c47
    - src-doc-666e53667e4b
    - src-doc-9abb3ce9a235
  extensions:
    x-journeyax-provenance:
      alias_log_burner:
        detail:
          alias: log_burner
          reason: Log burner and woodburner are solid fuel heaters.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:25.294Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      policy_confirm_with_a_qualified_person:
        detail:
          overlay: confirm_with_a_qualified_person
          reason: 'Proposed: a qualified person confirms the selection before checkout for products that are normally installed by a licensed trade. PlaceMakers to approve the list.'
          section: overlays
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Solid Fuel
          path:
            - Electrical & Heating/Cooling
            - Heating, Ventilation & Cooling
            - Solid Fuel
          products: 215
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Solid Fuel
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Electrical & Heating/Cooling
        - Heating, Ventilation & Cooling
        - Solid Fuel
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - fuel
    - fuels
    - solid fuels
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 51a51acd3fceeb83ae6da4bed1aad8c4656cecac63662e51dbd1958d5a5f6033
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling/solid-fuel
    relationshipId: rel-electrical-and-heating-cooling--heating-ventilation-and-cooling--solid-fuel-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling
    type: child_of
x-journeyax-synonyms:
  - fuel
  - fuels
  - solid fuels
---
# Solid Fuel

Solid Fuel: 215 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Heating, Ventilation & Cooling](../heating-ventilation-and-cooling.md)
