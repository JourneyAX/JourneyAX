---
description: 'Heat Pumps: 69 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Heat Pumps
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: requires_professional_confirmation
  compatibilitySensitive: false
  conceptId: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling/heat-pumps
  contentHash: 1df4f376e13f7b8f3e35b01aa0c9c5b684e1a5354e558cd6ebb59167825cb5e1
  customerPhrases:
    - ductless aircon
    - heatpump accessories
    - hi wall unit
    - outdoor unit mat
    - water heater heat pump
    - ceiling cassette ac
    - condensing unit pad
    - hydro heat pump
  description: 'Heat Pumps: 69 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-2e82b483f86a
    - src-doc-8d515fcbcbcb
    - src-doc-8cd71eb5d806
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:13.271Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      policy_confirm_with_a_qualified_person:
        detail:
          overlay: confirm_with_a_qualified_person
          reason: 'Proposed: a qualified person confirms the selection before checkout for products that are normally installed by a licensed trade. PlaceMakers to approve the list.'
          section: overlays
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Heat Pumps
          path:
            - Electrical & Heating/Cooling
            - Heating, Ventilation & Cooling
            - Heat Pumps
          products: 69
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Heat Pumps
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Electrical & Heating/Cooling
        - Heating, Ventilation & Cooling
        - Heat Pumps
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - heat pump
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 00812b268546699b4691006d5302ba2b10fb5978078154b5e3424ade1be0647b
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling/heat-pumps
    relationshipId: rel-electrical-and-heating-cooling--heating-ventilation-and-cooling--heat-pumps-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling
    type: child_of
x-journeyax-synonyms:
  - heat pump
---
# Heat Pumps

Heat Pumps: 69 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Heating, Ventilation & Cooling](../heating-ventilation-and-cooling.md)
