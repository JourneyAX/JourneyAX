---
description: 'Gas Heating: 59 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Gas Heating
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: requires_professional_confirmation
  compatibilitySensitive: false
  conceptId: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling/gas-heating
  contentHash: 1e895b80d89aa92d14217fc683f8970e2009cc52ccac1497d0a9740ce0f9c595
  customerPhrases:
    - gas fireplace
    - fireplace trim
    - flued gas heater
    - power flue fireplace
    - cylinder plinth
    - gas heater insert
    - gas fire fascia
    - powerflued heater
  description: 'Gas Heating: 59 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-3565520a2ef4
    - src-doc-bcc15794580b
    - src-doc-bfcb9f346c10
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:00.092Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      policy_confirm_with_a_qualified_person:
        detail:
          overlay: confirm_with_a_qualified_person
          reason: 'Proposed: a qualified person confirms the selection before checkout for products that are normally installed by a licensed trade. PlaceMakers to approve the list.'
          section: overlays
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Gas Heating
          path:
            - Electrical & Heating/Cooling
            - Heating, Ventilation & Cooling
            - Gas Heating
          products: 59
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Gas Heating
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Electrical & Heating/Cooling
        - Heating, Ventilation & Cooling
        - Gas Heating
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - gas heatings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 675cb5e7bb72fa8b378f57a1ddeb8fd608151d836dfc60731f30baad22e051a4
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling/gas-heating
    relationshipId: rel-electrical-and-heating-cooling--heating-ventilation-and-cooling--gas-heating-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling
    type: child_of
x-journeyax-synonyms:
  - gas heatings
---
# Gas Heating

Gas Heating: 59 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Heating, Ventilation & Cooling](../heating-ventilation-and-cooling.md)
