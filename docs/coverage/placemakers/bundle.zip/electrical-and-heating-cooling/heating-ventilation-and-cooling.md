---
description: 'Heating, Ventilation & Cooling: 787 products across 7 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Heating, Ventilation & Cooling
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling/ventilation
      - concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling/solid-fuel
      - concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling/electric-heating
      - concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling/heat-pumps
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_electrical_and_heating_cooling_heating_ventilation_and_cooling
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling
  contentHash: 882478680790f9f19f9650567c3455e3967c63188ec10a690f71cf946de6627e
  customerPhrases:
    - ducted bathroom fan
    - timer heater
    - hot water heat pump
  description: 'Heating, Ventilation & Cooling: 787 products across 7 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_electrical_and_heating_cooling_heating_ventilation_and_cooling
      questionRef: q.nav_electrical_and_heating_cooling_heating_ventilation_and_cooling
      valueMap:
        central-heating: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling/central-heating
        electric-heating: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling/electric-heating
        gas-heating: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling/gas-heating
        heat-pumps: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling/heat-pumps
        outdoor-heating: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling/outdoor-heating
        solid-fuel: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling/solid-fuel
        ventilation: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling/ventilation
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-7a3580a31b1d
    - src-doc-7bf6465b5c47
    - src-doc-99db5ac5deae
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Heating, Ventilation & Cooling
          path:
            - Electrical & Heating/Cooling
            - Heating, Ventilation & Cooling
          products: 787
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Heating, Ventilation & Cooling
  requiredFacts:
    - factKey: nav_electrical_and_heating_cooling_heating_ventilation_and_cooling
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Electrical & Heating/Cooling
        - Heating, Ventilation & Cooling
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - ventilations
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 685e157567764c017fe4bff0e7c338515e333c30b083fde93195f937eac779a7
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/electrical-and-heating-cooling/heating-ventilation-and-cooling
    relationshipId: rel-electrical-and-heating-cooling--heating-ventilation-and-cooling-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/electrical-and-heating-cooling
    type: child_of
x-journeyax-synonyms:
  - ventilations
---
# Heating, Ventilation & Cooling

Heating, Ventilation & Cooling: 787 products across 7 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Electrical & Heating/Cooling](../electrical-and-heating-cooling.md)
