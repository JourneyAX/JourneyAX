---
description: 'Doors, Windows & Joinery Hardware: 1,458 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Doors, Windows & Joinery Hardware
type: department
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware
      - concept://placemakers/doors-windows-and-joinery-hardware/doors
      - concept://placemakers/doors-windows-and-joinery-hardware/window-furnishings-and-hardware
      - concept://placemakers/doors-windows-and-joinery-hardware/windows
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_doors_windows_and_joinery_hardware
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/doors-windows-and-joinery-hardware
  contentHash: d26ad8fcf7ccd01bacc36508edff6e2823fb9ca4d4f12d0ec608249e4210a29b
  customerPhrases:
    - pocket door hardware
  description: 'Doors, Windows & Joinery Hardware: 1,458 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_doors_windows_and_joinery_hardware
      questionRef: q.nav_doors_windows_and_joinery_hardware
      valueMap:
        doors: concept://placemakers/doors-windows-and-joinery-hardware/doors
        joinery-hardware: concept://placemakers/doors-windows-and-joinery-hardware/joinery-hardware
        window-furnishings-and-hardware: concept://placemakers/doors-windows-and-joinery-hardware/window-furnishings-and-hardware
        windows: concept://placemakers/doors-windows-and-joinery-hardware/windows
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-b6c73ac8da88
    - src-doc-5d65512f79d1
    - src-doc-8cbdaa7f185b
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Doors, Windows & Joinery Hardware
          path:
            - Doors, Windows & Joinery Hardware
          products: 1458
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Doors, Windows & Joinery Hardware
  requiredFacts:
    - factKey: nav_doors_windows_and_joinery_hardware
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Doors, Windows & Joinery Hardware
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - door
    - joinery hardwares
    - track
    - tracks
    - window
  tenantId: placemakers
  type: department
  version: 1
x-journeyax-relationships: []
x-journeyax-synonyms:
  - door
  - joinery hardwares
  - track
  - tracks
  - window
---
# Doors, Windows & Joinery Hardware

Doors, Windows & Joinery Hardware: 1,458 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
