# timber-and-plywood/poles-posts-and-piles

* [House Piles](house-piles.md) - House Piles: 13 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
