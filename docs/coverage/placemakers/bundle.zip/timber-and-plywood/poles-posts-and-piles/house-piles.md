---
description: 'House Piles: 13 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: House Piles
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/poles-posts-and-piles/house-piles
  contentHash: 6cb45f4a213a2ff598cbb74be8340430d0b8b4e945593e664a19808d5193535f
  customerPhrases:
    - anchor pile
    - treated timber pile
    - round pile
    - square pile
    - round post
    - h5 treated timber
    - ground contact pile
    - treated pile
  description: 'House Piles: 13 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:04:12.174Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - House Piles
          path:
            - Timber & Plywood
            - Poles, Posts & Piles
            - House Piles
          products: 13
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: House Piles
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Poles, Posts & Piles
        - House Piles
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - house pile
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 8ac369a864185d5b92d24b1419356ac5a5137a48e003c094511fc2efb6794ced
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/poles-posts-and-piles/house-piles
    relationshipId: rel-timber-and-plywood--poles-posts-and-piles--house-piles-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/poles-posts-and-piles
    type: child_of
x-journeyax-synonyms:
  - house pile
---
# House Piles

House Piles: 13 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Poles, Posts & Piles](../poles-posts-and-piles.md)
