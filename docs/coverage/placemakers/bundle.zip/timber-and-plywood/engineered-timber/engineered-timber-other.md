---
description: 'Engineered Timber Other: 48 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Engineered Timber Other
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/engineered-timber/engineered-timber-other
  contentHash: c7b42401060cc64cb21c087cdff0a6c19917d952e186c64c15f91df073d9e74d
  customerPhrases:
    - strandboard panel
    - 3 layer panel
    - triboard alternative
    - mdf faced board
    - paint grade panel
    - timber portal frame
    - bracing portal
    - timber bracing frame
  description: 'Engineered Timber Other: 48 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-430b9e6f8582
    - src-doc-5c6175a808c1
    - src-doc-efb6bc2301b6
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:21.897Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Engineered Timber Other
          path:
            - Timber & Plywood
            - Engineered Timber
            - Engineered Timber Other
          products: 48
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Engineered Timber Other
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Engineered Timber
        - Engineered Timber Other
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - engineered timber others
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 4070a86141e44e5fa330430871d5f44d025d809b7ebfcd8951df706f5cf4ee9f
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/engineered-timber/engineered-timber-other
    relationshipId: rel-timber-and-plywood--engineered-timber--engineered-timber-other-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/engineered-timber
    type: child_of
x-journeyax-synonyms:
  - engineered timber others
---
# Engineered Timber Other

Engineered Timber Other: 48 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Engineered Timber](../engineered-timber.md)
