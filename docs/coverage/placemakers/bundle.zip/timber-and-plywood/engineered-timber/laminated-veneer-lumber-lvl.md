---
description: 'Laminated Veneer Lumber (LVL): 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Laminated Veneer Lumber (LVL)
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/engineered-timber/laminated-veneer-lumber-lvl
  contentHash: e105d70072957785ee821dde156775602e4e30f096d40169df278f19ff6ea2e0
  customerPhrases: []
  description: 'Laminated Veneer Lumber (LVL): 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Laminated Veneer Lumber (LVL)
          path:
            - Timber & Plywood
            - Engineered Timber
            - Laminated Veneer Lumber (LVL)
          products: 1
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Laminated Veneer Lumber (LVL)
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Engineered Timber
        - Laminated Veneer Lumber (LVL)
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - laminated veneer lumber lvls
    - lvl
    - lvls
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: c759f52bd43ebdf8dc769fd11058bc633973bbbf789a5c67db7e5bc2027de1f2
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/engineered-timber/laminated-veneer-lumber-lvl
    relationshipId: rel-timber-and-plywood--engineered-timber--laminated-veneer-lumber-lvl-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/engineered-timber
    type: child_of
x-journeyax-synonyms:
  - laminated veneer lumber lvls
  - lvl
  - lvls
---
# Laminated Veneer Lumber (LVL)

Laminated Veneer Lumber (LVL): 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Engineered Timber](../engineered-timber.md)
