# timber-and-plywood/engineered-timber

* [Engineered Timber Other](engineered-timber-other.md) - Engineered Timber Other: 48 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Laminated Posts And Beams (Gluelam)](laminated-posts-and-beams-gluelam.md) - Laminated Posts And Beams (Gluelam): 307 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Laminated Veneer Lumber (LVL)](laminated-veneer-lumber-lvl.md) - Laminated Veneer Lumber (LVL): 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
