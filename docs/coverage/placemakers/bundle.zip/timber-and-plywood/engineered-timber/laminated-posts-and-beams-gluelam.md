---
description: 'Laminated Posts And Beams (Gluelam): 307 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Laminated Posts And Beams (Gluelam)
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/engineered-timber/laminated-posts-and-beams-gluelam
  contentHash: a13f0ff3a01548633818991e9052ec8d4f06eeb3879fc622a3bfa3636d888365
  customerPhrases:
    - glulam beam
    - glulam post
    - laminated timber beam
    - laminated post
    - glue laminated timber
    - glu lam timber
    - structural laminated beam
    - structural timber post
  description: 'Laminated Posts And Beams (Gluelam): 307 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-4046586ec77d
    - src-doc-a2b936992c9a
    - src-doc-c78c73be12c5
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:20.011Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Laminated Posts And Beams (Gluelam)
          path:
            - Timber & Plywood
            - Engineered Timber
            - Laminated Posts And Beams (Gluelam)
          products: 307
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Laminated Posts And Beams (Gluelam)
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Engineered Timber
        - Laminated Posts And Beams (Gluelam)
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - gluelam
    - gluelams
    - laminated posts and beams gluelams
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 8642afc878ccf97868d82fcd17bcd912c6005ef76645d7d98d703eaa05473ced
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/engineered-timber/laminated-posts-and-beams-gluelam
    relationshipId: rel-timber-and-plywood--engineered-timber--laminated-posts-and-beams-gluelam-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/engineered-timber
    type: child_of
x-journeyax-synonyms:
  - gluelam
  - gluelams
  - laminated posts and beams gluelams
---
# Laminated Posts And Beams (Gluelam)

Laminated Posts And Beams (Gluelam): 307 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Engineered Timber](../engineered-timber.md)
