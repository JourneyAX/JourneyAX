---
description: 'Mouldings Clear: 12 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Mouldings Clear
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/mouldings-clear
  contentHash: 2bb1a411fd7cc8e9551ee3261c4b06d849e2ee096b7f18c6ef82bd9f5b109e3a
  customerPhrases:
    - architrave timber
    - architrave trim
    - clear grade moulding
    - quadrant moulding
    - fillet moulding
    - 4s moulding
    - finger jointed trim
    - no 24 profile
  description: 'Mouldings Clear: 12 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-c42d461e60b9
    - src-doc-ede80c7c4396
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:04:26.439Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Mouldings Clear
          path:
            - Timber & Plywood
            - Square Dressed Boards & Mouldings
            - Mouldings Clear
          products: 12
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Mouldings Clear
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Square Dressed Boards & Mouldings
        - Mouldings Clear
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - mouldings clears
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: a79a3da31237b3f90d1b320c02eeede555500aeed5b09c75053d53559efecea7
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/mouldings-clear
    relationshipId: rel-timber-and-plywood--square-dressed-boards-and-mouldings--mouldings-clear-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings
    type: child_of
x-journeyax-synonyms:
  - mouldings clears
---
# Mouldings Clear

Mouldings Clear: 12 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Square Dressed Boards & Mouldings](../square-dressed-boards-and-mouldings.md)
