---
description: 'Mouldings Finger Joint: 81 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Mouldings Finger Joint
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/mouldings-finger-joint
  contentHash: 27a6f97ed7da31d295e32d88bd1e8d1d5160ad2735f51cddb6a634223074cc78
  customerPhrases:
    - finger joint mouldings
    - fingerjoint moulding
    - architrave moulding
    - finger joint trim
    - fj mouldings
    - fj architrave
    - finger joint architrave
    - fj moulding
  description: 'Mouldings Finger Joint: 81 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-0c626cfa5b69
    - src-doc-34849276ef8d
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:58.041Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Mouldings Finger Joint
          path:
            - Timber & Plywood
            - Square Dressed Boards & Mouldings
            - Mouldings Finger Joint
          products: 81
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Mouldings Finger Joint
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Square Dressed Boards & Mouldings
        - Mouldings Finger Joint
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - joint
    - joints
    - mouldings finger joints
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 862fed050648be3cd4478264ac9e2d24714d2698072a9c763d1a9d81d83d234f
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/mouldings-finger-joint
    relationshipId: rel-timber-and-plywood--square-dressed-boards-and-mouldings--mouldings-finger-joint-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings
    type: child_of
x-journeyax-synonyms:
  - joint
  - joints
  - mouldings finger joints
---
# Mouldings Finger Joint

Mouldings Finger Joint: 81 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Square Dressed Boards & Mouldings](../square-dressed-boards-and-mouldings.md)
