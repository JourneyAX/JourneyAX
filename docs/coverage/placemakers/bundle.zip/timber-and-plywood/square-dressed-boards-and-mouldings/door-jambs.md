---
description: 'Door Jambs: 8 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Door Jambs
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/door-jambs
  contentHash: 138c8e4bc334629da8c3d8c0ea649c26a8ccfea6a653799164f8fddf1fd569ff
  customerPhrases:
    - door frame jamb
    - timber door lining
    - radiata pine jamb
    - pre primed jamb
    - dressed jamb
    - grooved door jamb
    - door lining stock
    - internal door jamb
  description: 'Door Jambs: 8 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-a0bdffa15911
    - src-doc-ffa6c2f51919
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:04:12.683Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Door Jambs
          path:
            - Timber & Plywood
            - Square Dressed Boards & Mouldings
            - Door Jambs
          products: 8
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Door Jambs
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Square Dressed Boards & Mouldings
        - Door Jambs
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - door jamb
    - jamb
    - jambs
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: d7a63f21d9e141731e497d96ea78de405df51f34b75c2a0d8b45a7aeaa11f738
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/door-jambs
    relationshipId: rel-timber-and-plywood--square-dressed-boards-and-mouldings--door-jambs-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings
    type: child_of
x-journeyax-synonyms:
  - door jamb
  - jamb
  - jambs
---
# Door Jambs

Door Jambs: 8 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Square Dressed Boards & Mouldings](../square-dressed-boards-and-mouldings.md)
