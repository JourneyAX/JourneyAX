---
description: 'Mouldings Mdf: 44 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Mouldings Mdf
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/mouldings-mdf
  contentHash: 369b421f811ec5b76900b5d866ad6d866f76d5529713a625fbe1cad47826cf53
  customerPhrases:
    - preprimed mdf trim
    - architrave mdf
    - primed skirting
    - moulding strip
    - prepainted architrave
    - door surround
    - moisture resistant mdf moulding
    - window trim
  description: 'Mouldings Mdf: 44 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:38.852Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Mouldings Mdf
          path:
            - Timber & Plywood
            - Square Dressed Boards & Mouldings
            - Mouldings Mdf
          products: 44
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Mouldings Mdf
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Square Dressed Boards & Mouldings
        - Mouldings Mdf
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - mouldings mdfs
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 43e7fd9bf89547537071fca0472ab5d0692cfa4c9aedfcfd9f05f99a0878f60c
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/mouldings-mdf
    relationshipId: rel-timber-and-plywood--square-dressed-boards-and-mouldings--mouldings-mdf-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings
    type: child_of
x-journeyax-synonyms:
  - mouldings mdfs
---
# Mouldings Mdf

Mouldings Mdf: 44 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Square Dressed Boards & Mouldings](../square-dressed-boards-and-mouldings.md)
