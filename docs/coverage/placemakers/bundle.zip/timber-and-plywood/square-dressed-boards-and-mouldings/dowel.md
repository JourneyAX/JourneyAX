---
description: 'Dowel: 14 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Dowel
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/dowel
  contentHash: c9d535968a3e2902b4ff6849886c81b31afd361b35d5a09fbe43fec30a9772f0
  customerPhrases:
    - wooden dowel
    - timber dowel rod
    - round dowel
    - handrail dowel
    - dowel rod 1 8m
    - dowel rod 4 8m
    - pine dowel
    - roundwood
  description: 'Dowel: 14 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:04:00.533Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Dowel
          path:
            - Timber & Plywood
            - Square Dressed Boards & Mouldings
            - Dowel
          products: 14
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Dowel
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Square Dressed Boards & Mouldings
        - Dowel
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - dowels
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: b0cdf99359274251ba6fc0773a4f1936d5f531bc7d9effb2bc71c23e9b99065c
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/dowel
    relationshipId: rel-timber-and-plywood--square-dressed-boards-and-mouldings--dowel-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings
    type: child_of
x-journeyax-synonyms:
  - dowels
---
# Dowel

Dowel: 14 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Square Dressed Boards & Mouldings](../square-dressed-boards-and-mouldings.md)
