---
description: 'Structural Grade Timber Wet: 23 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Structural Grade Timber Wet
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/structural-grade-timber-wet
  contentHash: 2d0195d88dcee7c132f516bfe4739ed21486ca154a2fd254263223aac8fc524e
  customerPhrases: []
  description: 'Structural Grade Timber Wet: 23 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Structural Grade Timber Wet
          path:
            - Timber & Plywood
            - Structural Grade Timber Wet
          products: 23
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Structural Grade Timber Wet
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Structural Grade Timber Wet
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - structural grade timber wets
    - wet
    - wets
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 69798175ee5f91e6f3d771805ba476b5db77b1354a30945f1eb25a1cb4a4335a
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/structural-grade-timber-wet
    relationshipId: rel-timber-and-plywood--structural-grade-timber-wet-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood
    type: child_of
x-journeyax-synonyms:
  - structural grade timber wets
  - wet
  - wets
---
# Structural Grade Timber Wet

Structural Grade Timber Wet: 23 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Timber & Plywood](../timber-and-plywood.md)
