---
description: 'NST Treated: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: NST Treated
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/non-structural-timber-all-grades/nst-treated
  contentHash: 90a77e6bb6d1fc594c509cef9f338f1e85d2606907f53b173ab0ae1aaf8687e7
  customerPhrases:
    - treated paling
    - h3 2 posts
    - garden timber
    - treated framing
    - radiata pine rail
    - exterior timber
    - kiln dried treated
    - no2 treated timber
  description: 'NST Treated: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:07:13.947Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - NST Treated
          path:
            - Timber & Plywood
            - Non Structural Timber - All Grades
            - NST Treated
          products: 2
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: NST Treated
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Non Structural Timber - All Grades
        - NST Treated
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - nst treateds
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: d6005c8cc114624488898a508ee7725b6b35547202be1d55a9b25a378cf496b4
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/non-structural-timber-all-grades/nst-treated
    relationshipId: rel-timber-and-plywood--non-structural-timber-all-grades--nst-treated-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/non-structural-timber-all-grades
    type: child_of
x-journeyax-synonyms:
  - nst treateds
---
# NST Treated

NST Treated: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Non Structural Timber - All Grades](../non-structural-timber-all-grades.md)
