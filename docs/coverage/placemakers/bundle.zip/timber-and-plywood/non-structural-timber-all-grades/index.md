# timber-and-plywood/non-structural-timber-all-grades

* [NST Merch, Boxing & Battens](nst-merch-boxing-and-battens.md) - NST Merch, Boxing & Battens: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [NST Treated](nst-treated.md) - NST Treated: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Non-Structural Grades Other](non-structural-grades-other.md) - Non-Structural Grades Other: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Timber Battens](timber-battens.md) - Timber Battens: 20 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
