---
description: 'NST Merch, Boxing & Battens: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: NST Merch, Boxing & Battens
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/non-structural-timber-all-grades/nst-merch-boxing-and-battens
  contentHash: 1e6beaccadd3a0500d0fff3245b061266682a7bb54da9e7a1ff3e5c9b9132691
  customerPhrases: []
  description: 'NST Merch, Boxing & Battens: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - NST Merch, Boxing & Battens
          path:
            - Timber & Plywood
            - Non Structural Timber - All Grades
            - NST Merch, Boxing & Battens
          products: 2
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: NST Merch, Boxing & Battens
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Non Structural Timber - All Grades
        - NST Merch, Boxing & Battens
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - boxing
    - boxings
    - merch
    - merches
    - nst merch
    - nst merches
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: c5ce4f81ac2c4e73c304383137d921a9b57fedfcb412c2123ae5dba3c0f3fbd7
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/non-structural-timber-all-grades/nst-merch-boxing-and-battens
    relationshipId: rel-timber-and-plywood--non-structural-timber-all-grades--nst-merch-boxing-and-battens-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/non-structural-timber-all-grades
    type: child_of
x-journeyax-synonyms:
  - boxing
  - boxings
  - merch
  - merches
  - nst merch
  - nst merches
---
# NST Merch, Boxing & Battens

NST Merch, Boxing & Battens: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Non Structural Timber - All Grades](../non-structural-timber-all-grades.md)
