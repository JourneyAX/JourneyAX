---
description: 'Non-Structural Grades Other: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Non-Structural Grades Other
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/non-structural-timber-all-grades/non-structural-grades-other
  contentHash: 707647dc048d71b72968d8b2cd418af5d49ff18ce043e6d482ca02a4d5cf2f3f
  customerPhrases:
    - radiata pine timber
    - treated timber 50x50
    - cca treated posts
    - split gauged timber
    - wet treated timber
    - non structural outdoor timber
    - balustrade timber
    - pergola timber
  description: 'Non-Structural Grades Other: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:07:18.359Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Non-Structural Grades Other
          path:
            - Timber & Plywood
            - Non Structural Timber - All Grades
            - Non-Structural Grades Other
          products: 1
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Non-Structural Grades Other
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Non Structural Timber - All Grades
        - Non-Structural Grades Other
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - non structural grades others
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: a1354996243f77b8c71a6b0d47f23e4d5d34baac6f8f33cd620d9c7e7a79a439
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/non-structural-timber-all-grades/non-structural-grades-other
    relationshipId: rel-timber-and-plywood--non-structural-timber-all-grades--non-structural-grades-other-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/non-structural-timber-all-grades
    type: child_of
x-journeyax-synonyms:
  - non structural grades others
---
# Non-Structural Grades Other

Non-Structural Grades Other: 1 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Non Structural Timber - All Grades](../non-structural-timber-all-grades.md)
