---
description: 'Timber Battens: 20 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Timber Battens
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/non-structural-timber-all-grades/timber-battens
  contentHash: 1ae3b12dfba3d3749c251431c2872cc7f5559b1164af068a182db54c67bafb01
  customerPhrases:
    - lining battens
    - ceiling furring batten
    - roof battens
    - cladding batten
    - plier batten
    - tile battens
    - air gap batten
    - roofing battens timber
  description: 'Timber Battens: 20 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-4769e6c0453b
    - src-doc-947da435cda7
    - src-doc-91e63b8ed7ec
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:02:16.934Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Timber Battens
          path:
            - Timber & Plywood
            - Non Structural Timber - All Grades
            - Timber Battens
          products: 20
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Timber Battens
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Non Structural Timber - All Grades
        - Timber Battens
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - timber batten
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: f1bea90955108e413f278bb05157377a596da8c42e4145b6bb8d6c5a42441c09
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/non-structural-timber-all-grades/timber-battens
    relationshipId: rel-timber-and-plywood--non-structural-timber-all-grades--timber-battens-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/non-structural-timber-all-grades
    type: child_of
x-journeyax-synonyms:
  - timber batten
---
# Timber Battens

Timber Battens: 20 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Non Structural Timber - All Grades](../non-structural-timber-all-grades.md)
