---
description: 'Engineered Timber: 356 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Engineered Timber
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/timber-and-plywood/engineered-timber/laminated-posts-and-beams-gluelam
      - concept://placemakers/timber-and-plywood/engineered-timber/engineered-timber-other
      - concept://placemakers/timber-and-plywood/engineered-timber/laminated-veneer-lumber-lvl
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_timber_and_plywood_engineered_timber
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/engineered-timber
  contentHash: 9ed5dccd9e764f829c35c5da59cf11fe8a3693848853e0d27dc08ebed728aae9
  customerPhrases: []
  description: 'Engineered Timber: 356 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_timber_and_plywood_engineered_timber
      questionRef: q.nav_timber_and_plywood_engineered_timber
      valueMap:
        engineered-timber-other: concept://placemakers/timber-and-plywood/engineered-timber/engineered-timber-other
        laminated-posts-and-beams-gluelam: concept://placemakers/timber-and-plywood/engineered-timber/laminated-posts-and-beams-gluelam
        laminated-veneer-lumber-lvl: concept://placemakers/timber-and-plywood/engineered-timber/laminated-veneer-lumber-lvl
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-4046586ec77d
    - src-doc-a2b936992c9a
    - src-doc-c78c73be12c5
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Engineered Timber
          path:
            - Timber & Plywood
            - Engineered Timber
          products: 356
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Engineered Timber
  requiredFacts:
    - factKey: nav_timber_and_plywood_engineered_timber
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Engineered Timber
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - engineered timbers
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: eaff4e4d8da13c529ed86189d3da8e489445ffc2a2a4674395f8e852880855f5
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/engineered-timber
    relationshipId: rel-timber-and-plywood--engineered-timber-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood
    type: child_of
x-journeyax-synonyms:
  - engineered timbers
---
# Engineered Timber

Engineered Timber: 356 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Timber & Plywood](../timber-and-plywood.md)
