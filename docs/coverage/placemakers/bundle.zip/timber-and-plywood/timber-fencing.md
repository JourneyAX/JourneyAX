---
description: 'Timber Fencing: 345 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Timber Fencing
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/timber-and-plywood/timber-fencing/fence-accessories
      - concept://placemakers/timber-and-plywood/timber-fencing/fence-trellis-and-panels
      - concept://placemakers/timber-and-plywood/timber-fencing/fence-palings
      - concept://placemakers/timber-and-plywood/timber-fencing/fence-posts
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_timber_and_plywood_timber_fencing
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/timber-fencing
  contentHash: 11c0969c4ed81fc055512d195c04094d18587736cfd2b396caf848d64156c277
  customerPhrases: []
  description: 'Timber Fencing: 345 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_timber_and_plywood_timber_fencing
      questionRef: q.nav_timber_and_plywood_timber_fencing
      valueMap:
        fence-accessories: concept://placemakers/timber-and-plywood/timber-fencing/fence-accessories
        fence-palings: concept://placemakers/timber-and-plywood/timber-fencing/fence-palings
        fence-posts: concept://placemakers/timber-and-plywood/timber-fencing/fence-posts
        fence-rails: concept://placemakers/timber-and-plywood/timber-fencing/fence-rails
        fence-trellis-and-panels: concept://placemakers/timber-and-plywood/timber-fencing/fence-trellis-and-panels
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Timber Fencing
          path:
            - Timber & Plywood
            - Timber Fencing
          products: 345
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Timber Fencing
  requiredFacts:
    - factKey: nav_timber_and_plywood_timber_fencing
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Timber Fencing
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - timber fencings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 74a1af1b0438872b54d3c9a2a8fac40794669343f7e5e7bb30c2dc5d61f1739d
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/timber-fencing
    relationshipId: rel-timber-and-plywood--timber-fencing-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood
    type: child_of
x-journeyax-synonyms:
  - timber fencings
---
# Timber Fencing

Timber Fencing: 345 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Timber & Plywood](../timber-and-plywood.md)
