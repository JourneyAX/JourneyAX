---
description: 'Square Dressed Boards & Mouldings: 167 products across 6 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Square Dressed Boards & Mouldings
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/mouldings-finger-joint
      - concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/mouldings-mdf
      - concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/dowel
      - concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/mouldings-clear
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_timber_and_plywood_square_dressed_boards_and_mouldings
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings
  contentHash: a0c00484ad03eff629c0d67b01aa668ae86ef7d0f91f57f4ff876c0c33f58a2d
  customerPhrases:
    - skirting and architrave
    - internal trim
    - radiata moulding
    - dressed all round
    - h3 treated moulding
    - skirting
    - skirting board
    - skirting boards
    - architrave
    - architraves
    - scotia
  description: 'Square Dressed Boards & Mouldings: 167 products across 6 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_timber_and_plywood_square_dressed_boards_and_mouldings
      questionRef: q.nav_timber_and_plywood_square_dressed_boards_and_mouldings
      valueMap:
        d4s-clear: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/d4s-clear
        door-jambs: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/door-jambs
        dowel: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/dowel
        mouldings-clear: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/mouldings-clear
        mouldings-finger-joint: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/mouldings-finger-joint
        mouldings-mdf: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings/mouldings-mdf
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-0c626cfa5b69
    - src-doc-a0bdffa15911
    - src-doc-34849276ef8d
  extensions:
    x-journeyax-provenance:
      alias_skirting:
        detail:
          alias: skirting
          reason: Skirting, architrave and scotia are the trade names for the mouldings.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Square Dressed Boards & Mouldings
          path:
            - Timber & Plywood
            - Square Dressed Boards & Mouldings
          products: 167
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Square Dressed Boards & Mouldings
  requiredFacts:
    - factKey: nav_timber_and_plywood_square_dressed_boards_and_mouldings
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Square Dressed Boards & Mouldings
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - board
    - boards
    - clear
    - clears
    - moulding
    - mouldings
    - square dressed board
    - square dressed boards
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 6529decafcc96f5585c2b21d6c70d984d89e9e69d73b6f8953a9354143222297
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/square-dressed-boards-and-mouldings
    relationshipId: rel-timber-and-plywood--square-dressed-boards-and-mouldings-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood
    type: child_of
x-journeyax-synonyms:
  - board
  - boards
  - clear
  - clears
  - moulding
  - mouldings
  - square dressed board
  - square dressed boards
---
# Square Dressed Boards & Mouldings

Square Dressed Boards & Mouldings: 167 products across 6 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Timber & Plywood](../timber-and-plywood.md)
