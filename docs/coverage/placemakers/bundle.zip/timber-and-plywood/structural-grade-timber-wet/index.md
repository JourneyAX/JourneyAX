# timber-and-plywood/structural-grade-timber-wet

* [SG H3.2 Radiata Wet](sg-h3-2-radiata-wet.md) - SG H3.2 Radiata Wet: 23 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
