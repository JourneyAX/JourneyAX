---
description: 'SG H3.2 Radiata Wet: 23 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: SG H3.2 Radiata Wet
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/structural-grade-timber-wet/sg-h3-2-radiata-wet
  contentHash: 6dbbb660879670393e1b6dfa7b63fce2acf6eba88fca3234d228ac253e76dc1d
  customerPhrases:
    - treated pine
    - decking joist timber
    - exterior framing timber
    - structural pine
    - wet grade timber
    - h3 treated timber
    - cca timber
    - planer gauged pine
  description: 'SG H3.2 Radiata Wet: 23 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:45.312Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - SG H3.2 Radiata Wet
          path:
            - Timber & Plywood
            - Structural Grade Timber Wet
            - SG H3.2 Radiata Wet
          products: 23
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: SG H3.2 Radiata Wet
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Structural Grade Timber Wet
        - SG H3.2 Radiata Wet
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - sg h3 2 radiata wets
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 640cb6191746f127959e20014bce7f92598e55a6ac2eeb2b7316aaad053318cc
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/structural-grade-timber-wet/sg-h3-2-radiata-wet
    relationshipId: rel-timber-and-plywood--structural-grade-timber-wet--sg-h3-2-radiata-wet-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/structural-grade-timber-wet
    type: child_of
x-journeyax-synonyms:
  - sg h3 2 radiata wets
---
# SG H3.2 Radiata Wet

SG H3.2 Radiata Wet: 23 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Structural Grade Timber Wet](../structural-grade-timber-wet.md)
