---
description: 'Structural Grade Timber Kiln Dried: 107 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Structural Grade Timber Kiln Dried
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/timber-and-plywood/structural-grade-timber-kiln-dried/sg-h1-2-radiata-kd
      - concept://placemakers/timber-and-plywood/structural-grade-timber-kiln-dried/sg-h3-2-radiata-kd
      - concept://placemakers/timber-and-plywood/structural-grade-timber-kiln-dried/sg-h1-2-douglas-fir-kd
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_timber_and_plywood_structural_grade_timber_kiln_dried
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/structural-grade-timber-kiln-dried
  contentHash: 0c586587058021d55c04bd3d9dfd8a5148898959197cf89f1968d922429cdf14
  customerPhrases:
    - sg8 timber
    - framing timber
    - boron treated timber
    - structural framing timber
    - kd timber
    - planer gauged timber
    - planed all round
    - kiln dried radiata
    - dwang
    - dwangs
    - noggin
    - noggins
    - nog
    - nogs
    - 4x2
    - 2x4
    - 4 by 2
    - 90x45
    - 100x50
  description: 'Structural Grade Timber Kiln Dried: 107 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_timber_and_plywood_structural_grade_timber_kiln_dried
      questionRef: q.nav_timber_and_plywood_structural_grade_timber_kiln_dried
      valueMap:
        sg-h1-2-douglas-fir-kd: concept://placemakers/timber-and-plywood/structural-grade-timber-kiln-dried/sg-h1-2-douglas-fir-kd
        sg-h1-2-radiata-kd: concept://placemakers/timber-and-plywood/structural-grade-timber-kiln-dried/sg-h1-2-radiata-kd
        sg-h3-2-radiata-kd: concept://placemakers/timber-and-plywood/structural-grade-timber-kiln-dried/sg-h3-2-radiata-kd
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_framing_timber:
        detail:
          alias: framing_timber
          reason: Customers ask for framing by its size and by the trade words dwang and noggin.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Structural Grade Timber Kiln Dried
          path:
            - Timber & Plywood
            - Structural Grade Timber Kiln Dried
          products: 107
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Structural Grade Timber Kiln Dried
  requiredFacts:
    - factKey: nav_timber_and_plywood_structural_grade_timber_kiln_dried
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Structural Grade Timber Kiln Dried
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - dried
    - drieds
    - kds
    - structural grade timber kiln drieds
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: a3f2c4d436e9e833e9b60c228c3de43acd133dcc1261a156ecefe01d5996446e
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/structural-grade-timber-kiln-dried
    relationshipId: rel-timber-and-plywood--structural-grade-timber-kiln-dried-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood
    type: child_of
x-journeyax-synonyms:
  - dried
  - drieds
  - kds
  - structural grade timber kiln drieds
---
# Structural Grade Timber Kiln Dried

Structural Grade Timber Kiln Dried: 107 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Timber & Plywood](../timber-and-plywood.md)
