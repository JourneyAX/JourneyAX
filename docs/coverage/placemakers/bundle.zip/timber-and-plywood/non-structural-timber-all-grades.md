---
description: 'Non Structural Timber - All Grades: 25 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Non Structural Timber - All Grades
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/timber-and-plywood/non-structural-timber-all-grades/timber-battens
      - concept://placemakers/timber-and-plywood/non-structural-timber-all-grades/nst-merch-boxing-and-battens
      - concept://placemakers/timber-and-plywood/non-structural-timber-all-grades/nst-treated
      - concept://placemakers/timber-and-plywood/non-structural-timber-all-grades/non-structural-grades-other
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_timber_and_plywood_non_structural_timber_all_grades
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/non-structural-timber-all-grades
  contentHash: 09140e947b0a2b698da5b87ba66a48be1d14ebd6ec9fb3c1c20e3a3a567dc1e3
  customerPhrases: []
  description: 'Non Structural Timber - All Grades: 25 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_timber_and_plywood_non_structural_timber_all_grades
      questionRef: q.nav_timber_and_plywood_non_structural_timber_all_grades
      valueMap:
        non-structural-grades-other: concept://placemakers/timber-and-plywood/non-structural-timber-all-grades/non-structural-grades-other
        nst-merch-boxing-and-battens: concept://placemakers/timber-and-plywood/non-structural-timber-all-grades/nst-merch-boxing-and-battens
        nst-treated: concept://placemakers/timber-and-plywood/non-structural-timber-all-grades/nst-treated
        timber-battens: concept://placemakers/timber-and-plywood/non-structural-timber-all-grades/timber-battens
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-4769e6c0453b
    - src-doc-947da435cda7
    - src-doc-91e63b8ed7ec
  extensions:
    x-journeyax-provenance:
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Non Structural Timber - All Grades
          path:
            - Timber & Plywood
            - Non Structural Timber - All Grades
          products: 25
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Non Structural Timber - All Grades
  requiredFacts:
    - factKey: nav_timber_and_plywood_non_structural_timber_all_grades
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Non Structural Timber - All Grades
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - batten
    - battens
    - grade
    - grades
    - non structural timber all grade
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: de8e16a3fb480192bd8a8a09ad9a30a0134b9f1ed0cbbf03e0e9a805b89fd5b5
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/non-structural-timber-all-grades
    relationshipId: rel-timber-and-plywood--non-structural-timber-all-grades-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood
    type: child_of
x-journeyax-synonyms:
  - batten
  - battens
  - grade
  - grades
  - non structural timber all grade
---
# Non Structural Timber - All Grades

Non Structural Timber - All Grades: 25 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Timber & Plywood](../timber-and-plywood.md)
