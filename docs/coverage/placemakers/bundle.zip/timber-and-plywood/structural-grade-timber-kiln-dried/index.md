# timber-and-plywood/structural-grade-timber-kiln-dried

* [SG H1.2 Douglas Fir KD](sg-h1-2-douglas-fir-kd.md) - SG H1.2 Douglas Fir KD: 8 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [SG H1.2 Radiata KD](sg-h1-2-radiata-kd.md) - SG H1.2 Radiata KD: 61 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [SG H3.2 Radiata KD](sg-h3-2-radiata-kd.md) - SG H3.2 Radiata KD: 38 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
