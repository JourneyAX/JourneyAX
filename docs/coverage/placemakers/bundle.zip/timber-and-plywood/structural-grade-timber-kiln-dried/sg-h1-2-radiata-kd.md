---
description: 'SG H1.2 Radiata KD: 61 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: SG H1.2 Radiata KD
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/structural-grade-timber-kiln-dried/sg-h1-2-radiata-kd
  contentHash: 0d9e9b9501afb41cf009d2ab075ed00e30cb9d29b346260dbc968a3bf7290180
  customerPhrases:
    - sg10 timber
    - structural radiata
    - treated framing timber
    - planed timber
    - planed all four sides
    - planer gauged beams
    - kiln dried framing timber
    - planer gauged framing
  description: 'SG H1.2 Radiata KD: 61 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:19.333Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - SG H1.2 Radiata KD
          path:
            - Timber & Plywood
            - Structural Grade Timber Kiln Dried
            - SG H1.2 Radiata KD
          products: 61
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: SG H1.2 Radiata KD
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Structural Grade Timber Kiln Dried
        - SG H1.2 Radiata KD
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - sg h1 2 radiata kds
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: c1fcdc2a9fd8a733457034f91b1d28a9321a644777dccfeca31fcab3696231d5
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/structural-grade-timber-kiln-dried/sg-h1-2-radiata-kd
    relationshipId: rel-timber-and-plywood--structural-grade-timber-kiln-dried--sg-h1-2-radiata-kd-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/structural-grade-timber-kiln-dried
    type: child_of
x-journeyax-synonyms:
  - sg h1 2 radiata kds
---
# SG H1.2 Radiata KD

SG H1.2 Radiata KD: 61 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Structural Grade Timber Kiln Dried](../structural-grade-timber-kiln-dried.md)
