---
description: 'SG H3.2 Radiata KD: 38 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: SG H3.2 Radiata KD
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/structural-grade-timber-kiln-dried/sg-h3-2-radiata-kd
  contentHash: 66bf864ed0771ed74a9c6f3a42c4acce5e35c1bc8f3dcc748f196787b86a7483
  customerPhrases:
    - cca treated framing
    - bearers and joists timber
    - packhouse timber sizes
    - timber for trusses
    - 190x45 equivalent
    - 150x35 timber
    - exposed above ground timber
    - radiata framing timber
  description: 'SG H3.2 Radiata KD: 38 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:32.140Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - SG H3.2 Radiata KD
          path:
            - Timber & Plywood
            - Structural Grade Timber Kiln Dried
            - SG H3.2 Radiata KD
          products: 38
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: SG H3.2 Radiata KD
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Structural Grade Timber Kiln Dried
        - SG H3.2 Radiata KD
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - sg h3 2 radiata kds
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 9d19d72726c844cef39742aa5915ad7eee153831e90f8b7c0c4b295ce1922d77
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/structural-grade-timber-kiln-dried/sg-h3-2-radiata-kd
    relationshipId: rel-timber-and-plywood--structural-grade-timber-kiln-dried--sg-h3-2-radiata-kd-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/structural-grade-timber-kiln-dried
    type: child_of
x-journeyax-synonyms:
  - sg h3 2 radiata kds
---
# SG H3.2 Radiata KD

SG H3.2 Radiata KD: 38 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Structural Grade Timber Kiln Dried](../structural-grade-timber-kiln-dried.md)
