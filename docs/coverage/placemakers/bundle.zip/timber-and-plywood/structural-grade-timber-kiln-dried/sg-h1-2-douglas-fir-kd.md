---
description: 'SG H1.2 Douglas Fir KD: 8 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: SG H1.2 Douglas Fir KD
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/structural-grade-timber-kiln-dried/sg-h1-2-douglas-fir-kd
  contentHash: ec8fb85f46814207078babe789f4dc12657b4a11872533384956021ec6996873
  customerPhrases:
    - packhouse framing
    - 90x45 stud
    - structural studs
    - machine gauged
    - construction framing
  description: 'SG H1.2 Douglas Fir KD: 8 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:04:13.971Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - SG H1.2 Douglas Fir KD
          path:
            - Timber & Plywood
            - Structural Grade Timber Kiln Dried
            - SG H1.2 Douglas Fir KD
          products: 8
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: SG H1.2 Douglas Fir KD
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Structural Grade Timber Kiln Dried
        - SG H1.2 Douglas Fir KD
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - sg h1 2 douglas fir kds
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 285dc264d2d1d2564e9a5a3542b760505cafb8ba07b887ffdfa0b229729e5168
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/structural-grade-timber-kiln-dried/sg-h1-2-douglas-fir-kd
    relationshipId: rel-timber-and-plywood--structural-grade-timber-kiln-dried--sg-h1-2-douglas-fir-kd-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/structural-grade-timber-kiln-dried
    type: child_of
x-journeyax-synonyms:
  - sg h1 2 douglas fir kds
---
# SG H1.2 Douglas Fir KD

SG H1.2 Douglas Fir KD: 8 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Structural Grade Timber Kiln Dried](../structural-grade-timber-kiln-dried.md)
