# timber-and-plywood

* [Decking](decking.md) - Decking: 82 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Engineered Timber](engineered-timber.md) - Engineered Timber: 356 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Non Structural Timber - All Grades](non-structural-timber-all-grades.md) - Non Structural Timber - All Grades: 25 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Panels (Timber & Plywood)](panels.md) - Panels: 2 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Plywood](plywood.md) - Plywood: 404 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Poles, Posts & Piles](poles-posts-and-piles.md) - Poles, Posts & Piles: 13 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Square Dressed Boards & Mouldings](square-dressed-boards-and-mouldings.md) - Square Dressed Boards & Mouldings: 167 products across 6 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Structural Grade Timber Kiln Dried](structural-grade-timber-kiln-dried.md) - Structural Grade Timber Kiln Dried: 107 products across 3 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Structural Grade Timber Wet](structural-grade-timber-wet.md) - Structural Grade Timber Wet: 23 products across 1 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Timber Fencing](timber-fencing.md) - Timber Fencing: 345 products across 5 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Timber Retaining](timber-retaining.md) - Timber Retaining: 26 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [decking](decking/) - Knowledge and references
* [engineered-timber](engineered-timber/) - Knowledge and references
* [non-structural-timber-all-grades](non-structural-timber-all-grades/) - Knowledge and references
* [panels](panels/) - Knowledge and references
* [plywood](plywood/) - Knowledge and references
* [poles-posts-and-piles](poles-posts-and-piles/) - Knowledge and references
* [square-dressed-boards-and-mouldings](square-dressed-boards-and-mouldings/) - Knowledge and references
* [structural-grade-timber-kiln-dried](structural-grade-timber-kiln-dried/) - Knowledge and references
* [structural-grade-timber-wet](structural-grade-timber-wet/) - Knowledge and references
* [timber-fencing](timber-fencing/) - Knowledge and references
* [timber-retaining](timber-retaining/) - Knowledge and references
