---
description: 'Retaining Timber Radiata: 16 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Retaining Timber Radiata
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/timber-retaining/retaining-timber-radiata
  contentHash: b5bda5a71d5934e36481ba3d6ae53004c6b60467f429393455fe36d87b284c01
  customerPhrases:
    - landscape edging timber
    - landscape timber
    - tongue and groove sleepers
    - retaining posts
    - tg retaining timber
    - interlocking retaining boards
    - railway sleeper style
    - treated landscape timber
  description: 'Retaining Timber Radiata: 16 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:03:10.499Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Retaining Timber Radiata
          path:
            - Timber & Plywood
            - Timber Retaining
            - Retaining Timber Radiata
          products: 16
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Retaining Timber Radiata
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Timber Retaining
        - Retaining Timber Radiata
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - retaining timber radiatas
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 8ff28ef65b2b5b7ee2e297919c1f5293aede7a7f11961836b82e00802990e418
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/timber-retaining/retaining-timber-radiata
    relationshipId: rel-timber-and-plywood--timber-retaining--retaining-timber-radiata-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/timber-retaining
    type: child_of
x-journeyax-synonyms:
  - retaining timber radiatas
---
# Retaining Timber Radiata

Retaining Timber Radiata: 16 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Timber Retaining](../timber-retaining.md)
