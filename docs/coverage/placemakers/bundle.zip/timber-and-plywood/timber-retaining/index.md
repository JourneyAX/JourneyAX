# timber-and-plywood/timber-retaining

* [Retaining Timber Radiata](retaining-timber-radiata.md) - Retaining Timber Radiata: 16 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Sleepers](sleepers.md) - Sleepers: 10 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
