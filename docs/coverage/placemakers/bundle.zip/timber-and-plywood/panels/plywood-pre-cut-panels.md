---
description: 'Plywood Pre-Cut Panels: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Plywood Pre-Cut Panels
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/panels/plywood-pre-cut-panels
  contentHash: 5a0c2ca81184dd173dbeade3b7779008a611154f02f5db0760372d9b35f9c445
  customerPhrases:
    - decorative ply panels
    - garden screening panels
    - screening ply
    - landscape panels
    - fence infill panels
    - laser cut ply panels
    - patterned plywood panels
    - garden screen sheets
  description: 'Plywood Pre-Cut Panels: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:06:38.677Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Plywood Pre-Cut Panels
          path:
            - Timber & Plywood
            - Panels
            - Plywood Pre-Cut Panels
          products: 2
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Plywood Pre-Cut Panels
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Panels
        - Plywood Pre-Cut Panels
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - plywood pre cut panel
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 495eb4c4cb341626f6ee00b7f1c6790741a5a34d0602a8b94c68eaeab55380ce
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/panels/plywood-pre-cut-panels
    relationshipId: rel-timber-and-plywood--panels--plywood-pre-cut-panels-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/panels
    type: child_of
x-journeyax-synonyms:
  - plywood pre cut panel
---
# Plywood Pre-Cut Panels

Plywood Pre-Cut Panels: 2 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Panels (Timber & Plywood)](../panels.md)
