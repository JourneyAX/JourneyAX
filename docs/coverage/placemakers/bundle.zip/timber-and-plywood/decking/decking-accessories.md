---
description: 'Decking Accessories: 11 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Decking Accessories
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/decking/decking-accessories
  contentHash: 2a73884d6d6f10780ad35402f7bfcda5b073570bc1ed674e111a143833a6e1da
  customerPhrases:
    - balusters
    - stair treads external
    - handrail timber
    - balustrade spindles
    - grip stair nosing
    - stair handrail
    - stair spindles
    - treated stair timber
  description: 'Decking Accessories: 11 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:04:47.776Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Decking Accessories
          path:
            - Timber & Plywood
            - Decking
            - Decking Accessories
          products: 11
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Decking Accessories
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Decking
        - Decking Accessories
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - decking accessory
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 14a63aad467c6c453e06902c9e9a9728797f0c18f0e25a29b50412271414874e
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/decking/decking-accessories
    relationshipId: rel-timber-and-plywood--decking--decking-accessories-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/decking
    type: child_of
x-journeyax-synonyms:
  - decking accessory
---
# Decking Accessories

Decking Accessories: 11 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Decking](../decking.md)
