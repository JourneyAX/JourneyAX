---
description: 'Composite Decking: 41 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Composite Decking
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/decking/composite-decking
  contentHash: dfe0635d6fafdbb621396b3144f791a22d5ff5505d588b2307d2607153ecf78c
  customerPhrases:
    - composite boards
    - recycled plastic decking
    - timber plastic composite
    - wpc decking
    - low maintenance decking
    - no rot decking
    - plastic wood deck boards
    - hidden clip decking
  description: 'Composite Decking: 41 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:47.860Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Composite Decking
          path:
            - Timber & Plywood
            - Decking
            - Composite Decking
          products: 41
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Composite Decking
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Decking
        - Composite Decking
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - composite deckings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: acf2f8641f052fbad3b82ad5fda8e5a6b4e67dfdd9959bddcd8ceb0b38c311c7
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/decking/composite-decking
    relationshipId: rel-timber-and-plywood--decking--composite-decking-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/decking
    type: child_of
  - claimClasses: []
    confidence: low
    contentHash: db1ef161a37602059b56c4d29b4cabadc98c1ea9c6fa6592a6745afd98d09b22
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/decking/composite-decking
    relationshipId: rel-xs-composite_decking_extras-1
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/timber-and-plywood/decking/decking-accessories
    type: cross_sell
x-journeyax-synonyms:
  - composite deckings
---
# Composite Decking

Composite Decking: 41 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Decking](../decking.md)
* cross sell: [Decking Accessories](decking-accessories.md)
