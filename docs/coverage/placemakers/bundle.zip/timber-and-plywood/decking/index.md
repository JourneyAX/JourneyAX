# timber-and-plywood/decking

* [Composite Decking](composite-decking.md) - Composite Decking: 41 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Decking Accessories](decking-accessories.md) - Decking Accessories: 11 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Hardwood Decking](hardwood-decking.md) - Hardwood Decking: 13 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
* [Radiata Decking](radiata-decking.md) - Radiata Decking: 17 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.
