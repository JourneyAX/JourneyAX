---
description: 'Hardwood Decking: 13 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Hardwood Decking
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/decking/hardwood-decking
  contentHash: 99fdf45ab7a61e90cc30587c90ad060b4ab2c14f0fa98456e1792e672869afde
  customerPhrases:
    - vitex decking
    - kwila decking
    - garapa decking
    - purpleheart decking
    - olive grey hardwood
    - merbau decking
    - garapa boards
    - purple heart timber
    - kwila
    - merbau
    - vitex
    - hardwood deck
  description: 'Hardwood Decking: 13 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      alias_kwila:
        detail:
          alias: kwila
          reason: Kwila and merbau are the hardwood decking timbers customers name.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:05:45.038Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Hardwood Decking
            - Timber & Plywood > Decking > Hardwood Decking
          path:
            - Timber & Plywood
            - Decking
            - Hardwood Decking
          products: 13
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Hardwood Decking
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Decking
        - Hardwood Decking
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - hardwood deckings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 1313a1798c325614771cfe0d0e606c85719d068dc1a76c2b71b0677ce2fd2a3b
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/decking/hardwood-decking
    relationshipId: rel-timber-and-plywood--decking--hardwood-decking-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/decking
    type: child_of
  - claimClasses: []
    confidence: low
    contentHash: 0acd6a5cc10faa87dfa066ba6046fe7f0cd5f13694df96ebe99c346d50159c79
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/decking/hardwood-decking
    relationshipId: rel-xs-hardwood_decking_finish-1
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/paint-and-decorating/paint/woodcare
    type: cross_sell
x-journeyax-synonyms:
  - hardwood deckings
---
# Hardwood Decking

Hardwood Decking: 13 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Decking](../decking.md)
* cross sell: [Woodcare](../../paint-and-decorating/paint/woodcare.md)
