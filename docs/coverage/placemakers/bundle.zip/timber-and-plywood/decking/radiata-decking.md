---
description: 'Radiata Decking: 17 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Radiata Decking
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/decking/radiata-decking
  contentHash: cf91568c50080d2adbf0e3ed5164fca38fe097ea1aec506b303c3160d44fb941
  customerPhrases:
    - radiata pine decking
    - pine decking
    - treated pine decking
    - thermally modified decking
    - cca treated decking
    - quarter sawn decking
    - h3 2 decking
    - merch grade decking
  description: 'Radiata Decking: 17 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:03:56.648Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Radiata Decking
          path:
            - Timber & Plywood
            - Decking
            - Radiata Decking
          products: 17
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Radiata Decking
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Decking
        - Radiata Decking
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - radiata deckings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 42d2db8cb1de0ac03b2d47bc6cac97ed4bd1d13892650479951050f160d0c294
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/decking/radiata-decking
    relationshipId: rel-timber-and-plywood--decking--radiata-decking-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/decking
    type: child_of
  - claimClasses: []
    confidence: low
    contentHash: ed159920c0581512d720e3681a6b84f181c7b3880afc9a409b0d6b06756c8966
    extensions:
      x-journeyax-provenance:
        structure:
          detail:
            section: suggestions
          generator: okf-taxonomy-ingest/1
          kind: authored_proposal
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/decking/radiata-decking
    relationshipId: rel-xs-timber_decking_finish-1
    scope: category
    sourceRefs:
      - src-authoring-proposal
    strength: optional
    to: concept://placemakers/paint-and-decorating/paint/woodcare
    type: cross_sell
x-journeyax-synonyms:
  - radiata deckings
---
# Radiata Decking

Radiata Decking: 17 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Decking](../decking.md)
* cross sell: [Woodcare](../../paint-and-decorating/paint/woodcare.md)
