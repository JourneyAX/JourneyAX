---
description: 'Timber Retaining: 26 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Timber Retaining
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/timber-and-plywood/timber-retaining/retaining-timber-radiata
      - concept://placemakers/timber-and-plywood/timber-retaining/sleepers
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_timber_and_plywood_timber_retaining
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/timber-retaining
  contentHash: 393a8f1c5c56700bc4bb647e586ba07bfb9e2bd899391fe2dafd236bd42f955d
  customerPhrases:
    - garden sleepers
  description: 'Timber Retaining: 26 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_timber_and_plywood_timber_retaining
      questionRef: q.nav_timber_and_plywood_timber_retaining
      valueMap:
        retaining-timber-radiata: concept://placemakers/timber-and-plywood/timber-retaining/retaining-timber-radiata
        sleepers: concept://placemakers/timber-and-plywood/timber-retaining/sleepers
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Timber Retaining
          path:
            - Timber & Plywood
            - Timber Retaining
          products: 26
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Timber Retaining
  requiredFacts:
    - factKey: nav_timber_and_plywood_timber_retaining
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Timber Retaining
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - retaining
    - retainings
    - timber retainings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 9866127a768d31bfaf21b75c6b13ca033a2753746645434eb2c7dbcfa9051022
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/timber-retaining
    relationshipId: rel-timber-and-plywood--timber-retaining-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood
    type: child_of
x-journeyax-synonyms:
  - retaining
  - retainings
  - timber retainings
---
# Timber Retaining

Timber Retaining: 26 products across 2 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Timber & Plywood](../timber-and-plywood.md)
