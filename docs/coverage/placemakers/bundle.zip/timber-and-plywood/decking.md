---
description: 'Decking: 82 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Decking
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/timber-and-plywood/decking/composite-decking
      - concept://placemakers/timber-and-plywood/decking/radiata-decking
      - concept://placemakers/timber-and-plywood/decking/hardwood-decking
      - concept://placemakers/timber-and-plywood/decking/decking-accessories
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_timber_and_plywood_decking
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/decking
  contentHash: ebecd6b77968e168d5dca688e2e3446043c592099431ba68a52cc6f19ead4872
  customerPhrases: []
  description: 'Decking: 82 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_timber_and_plywood_decking
      questionRef: q.nav_timber_and_plywood_decking
      valueMap:
        composite-decking: concept://placemakers/timber-and-plywood/decking/composite-decking
        decking-accessories: concept://placemakers/timber-and-plywood/decking/decking-accessories
        hardwood-decking: concept://placemakers/timber-and-plywood/decking/hardwood-decking
        radiata-decking: concept://placemakers/timber-and-plywood/decking/radiata-decking
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      structure:
        detail:
          identifiers:
            - Decking
          path:
            - Timber & Plywood
            - Decking
          products: 82
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Decking
  requiredFacts:
    - factKey: nav_timber_and_plywood_decking
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Decking
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - deckings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 474b823e97da4b3af204d4d3ba22e6ce6cf9123ae0755f795440c28277895854
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/decking
    relationshipId: rel-timber-and-plywood--decking-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood
    type: child_of
x-journeyax-synonyms:
  - deckings
---
# Decking

Decking: 82 products across 4 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Timber & Plywood](../timber-and-plywood.md)
