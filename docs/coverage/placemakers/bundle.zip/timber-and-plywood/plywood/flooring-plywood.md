---
description: 'Flooring Plywood: 53 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Flooring Plywood
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/plywood/flooring-plywood
  contentHash: a63e6385f8a3dc0ed331a6d71e9f7c94db7a2720143867a902e9c5ca1fc0cb5c
  customerPhrases:
    - flooring ply
    - treated flooring ply
    - floor ply
    - subfloor plywood
    - 13mm 15mm 17mm plywood
    - floor sheathing ply
    - sheet flooring
    - 2400x1200 plywood
  description: 'Flooring Plywood: 53 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-2b62eed55fc3
    - src-doc-de0716d1eab3
    - src-doc-bc563f1e83c5
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:22.725Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Flooring Plywood
          path:
            - Timber & Plywood
            - Plywood
            - Flooring Plywood
          products: 53
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Flooring Plywood
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Plywood
        - Flooring Plywood
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - flooring plywoods
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 28a2dfbe071bfa348ebf9b42245261063ff4d8cd75f2029fab5a06b97897f3f5
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/plywood/flooring-plywood
    relationshipId: rel-timber-and-plywood--plywood--flooring-plywood-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/plywood
    type: child_of
x-journeyax-synonyms:
  - flooring plywoods
---
# Flooring Plywood

Flooring Plywood: 53 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Plywood](../plywood.md)
