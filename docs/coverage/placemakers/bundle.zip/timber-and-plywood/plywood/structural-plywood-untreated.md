---
description: 'Structural Plywood Untreated: 107 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Structural Plywood Untreated
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/plywood/structural-plywood-untreated
  contentHash: 9d24a822f53fb728d1ec983700d1242bba6a42ef380d179caf4277fc344c1a75
  customerPhrases:
    - structural panel
    - bracing plywood
    - fg8 plywood
    - dd grade plywood
    - ply sheets 2400x1200
    - flooring ply substrate
    - timber ply sheet
    - load bearing plywood
  description: 'Structural Plywood Untreated: 107 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-4e1f78037857
    - src-doc-20fe73c0eb64
    - src-doc-9bc586348f96
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:32.449Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Structural Plywood Untreated
          path:
            - Timber & Plywood
            - Plywood
            - Structural Plywood Untreated
          products: 107
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Structural Plywood Untreated
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Plywood
        - Structural Plywood Untreated
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - structural plywood untreateds
    - untreated
    - untreateds
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 3ea7127c99a6ae9c5cc984fab26154c26fd21accacedffd00b507bf68e19fdad
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/plywood/structural-plywood-untreated
    relationshipId: rel-timber-and-plywood--plywood--structural-plywood-untreated-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/plywood
    type: child_of
x-journeyax-synonyms:
  - structural plywood untreateds
  - untreated
  - untreateds
---
# Structural Plywood Untreated

Structural Plywood Untreated: 107 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Plywood](../plywood.md)
