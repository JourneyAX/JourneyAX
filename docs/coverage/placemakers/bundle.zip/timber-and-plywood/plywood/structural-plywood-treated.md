---
description: 'Structural Plywood Treated: 108 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Structural Plywood Treated
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/plywood/structural-plywood-treated
  contentHash: f3ab3cbec82c9a4a3b4acd948eb73aba22a9c330af7626146050c68c00f4f563
  customerPhrases:
    - structural ply treated
    - treated ply
    - h3 2 ply
    - structural plywood sheet
    - treated plywood
    - radiata structural ply
    - losp treated ply
    - losp ply
  description: 'Structural Plywood Treated: 108 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-1e61d18a53a2
    - src-doc-9d9c46fce991
    - src-doc-f7c4d331ccb3
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:19.571Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Structural Plywood Treated
          path:
            - Timber & Plywood
            - Plywood
            - Structural Plywood Treated
          products: 108
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Structural Plywood Treated
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Plywood
        - Structural Plywood Treated
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - structural plywood treateds
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 2c993b9e0fc62992b8acdf12e7ba5579f49f44a50f18a1a22669f7e005f2dbda
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/plywood/structural-plywood-treated
    relationshipId: rel-timber-and-plywood--plywood--structural-plywood-treated-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/plywood
    type: child_of
x-journeyax-synonyms:
  - structural plywood treateds
---
# Structural Plywood Treated

Structural Plywood Treated: 108 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Plywood](../plywood.md)
