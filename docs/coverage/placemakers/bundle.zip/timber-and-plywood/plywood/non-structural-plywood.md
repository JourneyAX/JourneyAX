---
description: 'Non Structural Plywood: 61 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Non Structural Plywood
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/plywood/non-structural-plywood
  contentHash: 9ee65b3a63a191fd2c9ec1a7c4999a0ac4f01c7257c1324d613451445e998e9f
  customerPhrases:
    - interior ply
    - shop lining ply
    - shelving ply
    - non load bearing ply
    - cabinet ply
    - external use ply
    - flatpack plywood
    - decorative plywood base
  description: 'Non Structural Plywood: 61 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-86800faa395e
    - src-doc-5f905fc8c9f3
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:02.061Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Non Structural Plywood
          path:
            - Timber & Plywood
            - Plywood
            - Non Structural Plywood
          products: 61
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Non Structural Plywood
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Plywood
        - Non Structural Plywood
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - non structural plywoods
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 8ea963a948c40c3ecfd73835cf06c754f3eed97b5779f35aa2db5097d89b2856
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/plywood/non-structural-plywood
    relationshipId: rel-timber-and-plywood--plywood--non-structural-plywood-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/plywood
    type: child_of
x-journeyax-synonyms:
  - non structural plywoods
---
# Non Structural Plywood

Non Structural Plywood: 61 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Plywood](../plywood.md)
