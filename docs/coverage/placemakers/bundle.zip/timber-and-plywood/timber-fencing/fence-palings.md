---
description: 'Fence Palings: 38 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Fence Palings
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/timber-fencing/fence-palings
  contentHash: 6bf0f52ccb9053d901b8c642ee8f37fa650be39322a44304c43c72e51341eb5a
  customerPhrases:
    - picket fence slats
    - paling pickets
    - screening palings
    - radiata pine paling
    - fence pales
    - rough cut palings
    - finger joint palings
    - dressed paling
  description: 'Fence Palings: 38 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:01:49.408Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Fence Palings
          path:
            - Timber & Plywood
            - Timber Fencing
            - Fence Palings
          products: 38
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Fence Palings
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Timber Fencing
        - Fence Palings
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - fence paling
    - paling
    - palings
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: b86eee282408ed284c24bae3888c5157d0aee3cc2091a8858c2e91cdcf9556da
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/timber-fencing/fence-palings
    relationshipId: rel-timber-and-plywood--timber-fencing--fence-palings-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/timber-fencing
    type: child_of
x-journeyax-synonyms:
  - fence paling
  - paling
  - palings
---
# Fence Palings

Fence Palings: 38 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Timber Fencing](../timber-fencing.md)
