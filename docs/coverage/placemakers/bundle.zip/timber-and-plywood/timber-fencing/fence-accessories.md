---
description: 'Fence Accessories: 224 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Fence Accessories
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/timber-fencing/fence-accessories
  contentHash: 279808ff2a59dd9d29a05b40074bc575edcbafe42f2c9230f73088e315be3285
  customerPhrases:
    - garden pegs
    - garden stakes
    - timber gate
    - post top
    - tree stakes
    - wooden garden gate
    - cap for fence post
    - plant supports
  description: 'Fence Accessories: 224 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T00:59:21.528Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Fence Accessories
          path:
            - Timber & Plywood
            - Timber Fencing
            - Fence Accessories
          products: 224
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Fence Accessories
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Timber Fencing
        - Fence Accessories
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - fence accessory
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 6278ceb6d9b3b3bf9468487044e02588dbf94f17fd4ed40ea2e098f6372e403b
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/timber-fencing/fence-accessories
    relationshipId: rel-timber-and-plywood--timber-fencing--fence-accessories-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/timber-fencing
    type: child_of
x-journeyax-synonyms:
  - fence accessory
---
# Fence Accessories

Fence Accessories: 224 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Timber Fencing](../timber-fencing.md)
