---
description: 'Fence Trellis & Panels: 56 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Fence Trellis & Panels
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/timber-fencing/fence-trellis-and-panels
  contentHash: 80f3e3636ae24ebe6d2f9cad6ca6ebb54716e3536d9235ef7f07e1be9a599dc2
  customerPhrases:
    - lattice panels
    - privacy screen
    - trellis panels
    - garden screen
    - privacy lattice
    - fence topper
    - louvre screening
    - fencetop trellis
  description: 'Fence Trellis & Panels: 56 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:00:17.030Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Fence Trellis & Panels
          path:
            - Timber & Plywood
            - Timber Fencing
            - Fence Trellis & Panels
          products: 56
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Fence Trellis & Panels
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Timber Fencing
        - Fence Trellis & Panels
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - fence trellis
    - fence trellises
    - trellis
    - trellises
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 0cc4658276389914ee78fedfccc0bc352e1f0c54e9df4303942967e08daf7d62
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/timber-fencing/fence-trellis-and-panels
    relationshipId: rel-timber-and-plywood--timber-fencing--fence-trellis-and-panels-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/timber-fencing
    type: child_of
x-journeyax-synonyms:
  - fence trellis
  - fence trellises
  - trellis
  - trellises
---
# Fence Trellis & Panels

Fence Trellis & Panels: 56 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Timber Fencing](../timber-fencing.md)
