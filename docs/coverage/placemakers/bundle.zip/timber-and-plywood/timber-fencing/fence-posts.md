---
description: 'Fence Posts: 15 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Fence Posts
type: product category
x-journeyax-concept:
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/timber-fencing/fence-posts
  contentHash: b587f3b77d3abd1d2997dffc4c34f47c74cfd70e1d02aba4b5bfebd5d0924791
  customerPhrases:
    - treated fence post
    - rough sawn post
    - radiata post
    - post 100x75
    - post 100x100
    - timber fence posts
    - fence timber post
    - post 1 8m 2 1m 2 4m
  description: 'Fence Posts: 15 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators: []
  evidenceRefs:
    - src-catalogue-taxonomy
  extensions:
    x-journeyax-provenance:
      customerPhrases:
        detail:
          generatedAt: '2026-08-26T01:02:25.642Z'
          model: gpt-5-mini
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Fence Posts
          path:
            - Timber & Plywood
            - Timber Fencing
            - Fence Posts
          products: 15
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      synonyms:
        detail:
          derivedFrom: category name
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Fence Posts
  requiredFacts: []
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Timber Fencing
        - Fence Posts
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms:
    - fence post
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 4324fd0defb5ceee37309466a4e2818d2977cb15f419a18bfd9a90bade1058ae
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/timber-fencing/fence-posts
    relationshipId: rel-timber-and-plywood--timber-fencing--fence-posts-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood/timber-fencing
    type: child_of
x-journeyax-synonyms:
  - fence post
---
# Fence Posts

Fence Posts: 15 products in the catalogue. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Timber Fencing](../timber-fencing.md)
