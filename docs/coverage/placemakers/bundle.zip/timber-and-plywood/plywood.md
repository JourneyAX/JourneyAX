---
description: 'Plywood: 404 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
generated:
  at: '2026-10-13T02:03:32.198Z'
  by: process:okf-taxonomy-ingest
status: draft
tags: []
title: Plywood
type: product category
x-journeyax-concept:
  broadQueryPolicy:
    groupConceptIds:
      - concept://placemakers/timber-and-plywood/plywood/structural-plywood-treated
      - concept://placemakers/timber-and-plywood/plywood/structural-plywood-untreated
      - concept://placemakers/timber-and-plywood/plywood/non-structural-plywood
      - concept://placemakers/timber-and-plywood/plywood/flooring-plywood
    maxItemsPerGroup: 2
    productRetrievalAllowed: true
    questionRef: q.nav_timber_and_plywood_plywood
  commercePolicy:
    addToCart: allowed
    checkout: allowed
  compatibilitySensitive: false
  conceptId: concept://placemakers/timber-and-plywood/plywood
  contentHash: 2a20d7391f18de930786f2af5fb45e4d1981c7a93f82850b28387c11b349e6f7
  customerPhrases:
    - structural ply
    - h3 2 treated plywood
    - cca treated plywood
    - f8 plywood
    - hoop pine ply
    - radiata plywood
    - radiata ply
    - bracing ply
    - ply
    - ply sheets
    - plywood sheets
  description: 'Plywood: 404 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.'
  discriminators:
    - clarifyFirst: false
      factKey: nav_timber_and_plywood_plywood
      questionRef: q.nav_timber_and_plywood_plywood
      valueMap:
        flooring-plywood: concept://placemakers/timber-and-plywood/plywood/flooring-plywood
        formply: concept://placemakers/timber-and-plywood/plywood/formply
        lining-plywood-interior: concept://placemakers/timber-and-plywood/plywood/lining-plywood-interior
        non-structural-plywood: concept://placemakers/timber-and-plywood/plywood/non-structural-plywood
        plywood-other: concept://placemakers/timber-and-plywood/plywood/plywood-other
        roofing-plywood: concept://placemakers/timber-and-plywood/plywood/roofing-plywood
        structural-plywood-treated: concept://placemakers/timber-and-plywood/plywood/structural-plywood-treated
        structural-plywood-untreated: concept://placemakers/timber-and-plywood/plywood/structural-plywood-untreated
  evidenceRefs:
    - src-catalogue-taxonomy
    - src-doc-4e1f78037857
    - src-doc-20fe73c0eb64
    - src-doc-2b62eed55fc3
  extensions:
    x-journeyax-provenance:
      alias_ply:
        detail:
          alias: ply
          reason: Customers shorten plywood to ply.
          section: aliases
        generator: okf-taxonomy-ingest/1
        kind: authored_proposal
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      customerPhrases:
        detail: {}
        generator: okf-taxonomy-ingest/1
        kind: model_generated_keywords
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      evidenceRefs:
        detail:
          note: Candidate documents; not verified and not evidence for any claim until a qualified person confirms applicability.
        generator: okf-taxonomy-ingest/1
        kind: crawl_document_candidate
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
      structure:
        detail:
          identifiers:
            - Plywood
          path:
            - Timber & Plywood
            - Plywood
          products: 404
          scopedBy: path
        generator: okf-taxonomy-ingest/1
        kind: catalogue_taxonomy
        snapshotAt: '2026-10-13T02:03:32.198Z'
        verified: false
  lens: product
  lifecycle:
    status: active_draft
  name: Plywood
  requiredFacts:
    - factKey: nav_timber_and_plywood_plywood
      importance: medium
  riskClass: standard
  safety:
    blocksProducts: false
    stepRefs: []
  searchScope:
    catalogCategoryIds: []
    catalogCategoryPaths:
      - - Timber & Plywood
        - Plywood
    enrichmentFacets: []
    excludeCategoryIds: []
  synonyms: []
  tenantId: placemakers
  type: product_category
  version: 1
x-journeyax-relationships:
  - claimClasses: []
    confidence: high
    contentHash: 0fe4f2ce13bf530c345c9480fb408ac43732d1b7c2107bd371a12295121f90c8
    extensions:
      x-journeyax-provenance:
        structure:
          generator: okf-taxonomy-ingest/1
          kind: catalogue_taxonomy
          snapshotAt: '2026-10-13T02:03:32.198Z'
          verified: false
    from: concept://placemakers/timber-and-plywood/plywood
    relationshipId: rel-timber-and-plywood--plywood-child-of
    scope: category
    sourceRefs:
      - src-catalogue-taxonomy
    strength: required
    to: concept://placemakers/timber-and-plywood
    type: child_of
---
# Plywood

Plywood: 404 products across 8 areas. Derived from the catalogue taxonomy (2026-10-13); not merchant-verified.

## Related concepts

* child of: [Timber & Plywood](../timber-and-plywood.md)
